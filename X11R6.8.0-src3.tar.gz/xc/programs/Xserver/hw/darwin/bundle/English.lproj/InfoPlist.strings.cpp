/* English versions of the Info.plist keys; used by most localizations. */
/* Most of these are set in the target application settings. */
/* $XFree86: xc/programs/Xserver/hw/darwin/bundle/English.lproj/InfoPlist.strings.cpp,v 1.3 2002/07/17 01:24:55 torrey Exp $ */

NSHumanReadableCopyright = __quote__ X_VENDOR_NAME X_VERSION __quote__;
