/* $XFree86$ */

#ifndef _CFBTAB_H_
#define _CFBTAB_H_

/* prototypes */
extern int starttab[32], endtab[32];
extern unsigned int partmasks[32][32];

#endif /* _CFBTAB_H_ */
