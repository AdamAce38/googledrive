char VERSION[] = "asclock-xlib 2.0 beta 11";

