#ifndef FALSE
# define FALSE 0
#endif
#ifndef TRUE
# define TRUE 1
#endif

#define PLAY 0
#define PAUSE 1
#define STOP 2
#define UPTRACK 3
#define DNTRACK 4
#define CUE 5
#define REV 6
#define FIRST 7
#define LAST 8
#define LOOP 9
#define DIRECTACCESS 10
#define INTROSCAN 11
#define INTRONEXT 12
#define LOCACCESS 13
#define DIRECTTRACK 14
#define GLOBALACCESS 15

/* CLOSETRAY added 990417 */
#define CLOSETRAY 16

/* new modes added in GMan experimentation. They're
   also used in AScd >= 0.11 */
#define STOPONLY 20
#define EJECT 21
