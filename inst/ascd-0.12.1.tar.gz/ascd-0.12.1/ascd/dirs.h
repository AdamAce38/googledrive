#define CBINDIR /usr/local/bin
#define CMANDIR /usr/local/man/man1
#define CTHDIR /usr/local/share/AScd
