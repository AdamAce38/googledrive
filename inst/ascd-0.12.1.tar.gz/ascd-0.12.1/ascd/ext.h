#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <X11/Xlib.h>

#include <X11/xpm.h>
#include <X11/extensions/shape.h>

#include <errno.h>
#include <unistd.h>
#include <grp.h>
#include <pwd.h>

#include "config.h"

#include "ascd.h"
#include <workman/workman.h>

#ifdef MIXER
# if defined (__FreeBSD__)
#  include <machine/soundcard.h>
# else
#  include <sys/mount.h>
#  include <linux/soundcard.h>
# endif
#endif

extern open();

/* added this for this lib: */
extern unsigned int info_modified;

extern int wanted_track;
extern unsigned int do_autorepeat;

extern int anomalie;

/* xfascd vars */

extern unsigned int wanna_play;

#ifdef XFASCD
extern unsigned int update_xpm;
#endif
extern unsigned int blind_mode;
extern unsigned int loop_mode, intro_mode;
extern unsigned int datatrack, cue_time;
extern unsigned int loop_start_track, loop_end_track;
extern unsigned int loop_1;
extern unsigned int loop_2;
extern unsigned int direct_access, direct_track;
extern unsigned int ignore_avoid;


/* XPM stuff */

typedef struct _XpmIcon {
    Pixmap pixmap;
    Pixmap mask;
    XpmAttributes attributes;
} XpmIcon;

XpmIcon alphaXPM;
XpmIcon backXPM;
XpmIcon barXPM;
XpmIcon ejectXPM;
XpmIcon fwdXPM;
XpmIcon ledXPM;
XpmIcon pauseXPM;
XpmIcon playXPM;
XpmIcon rewXPM;
XpmIcon stopXPM;

extern int lasttime;

extern Display *Disp;
extern Window Root;
extern Window Iconwin;
extern Window Win;
extern char *Geometry;
extern char device[128];
extern int withdrawn;
extern GC WinGC;
extern int CarrierOn;


extern char led_color[60];
extern char led_bgcolor[60];
extern char led_mcolor[60];
extern char led_mbgcolor[60];
extern char led_text[8];
extern char skin[40];

extern unsigned int text_timeout;
extern long text_start;
extern int redraw;
extern int mixer_changed;

extern unsigned int autorepeat;
extern unsigned int autoplay;
extern unsigned int time_mode;
extern unsigned int global_mode;

extern unsigned int volume;
extern  unsigned int muted_volume;
extern unsigned int muted;

/* The WorkMan stuff: */

extern char *cd_device;

/* from/for WorkMan database code: */

extern int mark_a;
extern int mark_b;
extern int cur_stopmode;
extern int cur_playnew;

#ifdef MIXER
extern char mixer_device[128];
extern int mixer_ok;
extern int mixer_control;
extern int mixer_vol;
extern int mixer_but;
extern int mixer_old;
#endif

extern time();
extern open();
/*extern cd_control(int);*/

#define RDTIME   500000L /* 500ms */
#define RDTIME2 1000000L /* 1sec */
#define MAX_VOL 100
