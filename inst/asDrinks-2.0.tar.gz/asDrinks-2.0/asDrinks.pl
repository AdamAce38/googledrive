#!/usr/bin/perl
# asDrinks 
# charlie schmidt - ishamael@themes.org
# this is ugly, live with it.
# variables
$version = "2.0";
%config;
%list;
$config = "$ENV{HOME}/.asDrinksrc";
$list = "$ENV{HOME}/.asDrinkslist";
$tempfile = "$ENV{HOME}/.asDrinkstemp";
$verbose = 1;

# read config file
# store info in %config hash, put into real variables later

open(CONFIG, $config);
while (<CONFIG>) {
        chomp;
        next if /^\s*\#/;
        next unless /=/;
        my ($key, $value) = split(/=/, $_, 2);
        $value =~ s/(\$(\w+))/$config{$2}/g;

        $config{$key} = $value;
}

$viewer = $config{viewer};
$netscape = $config{netscape};
$lynx = $config{lynx};
$startdir = $config{start_directory};
$drinksdir = $config{asDrinks_directory};
$ufieimage = $config{ufie_image};
$bindir = $config{bin_directory};
$update = $config{update};
$uf = $config{userfriendly};
$headlines = $config{headlines};
$dir = "$startdir"."$drinksdir";

# read list of NAMES and URLS 
# since this doesnt need any order
# store in an array [also makes it easier later]
# yeah yeah, i know this sucks

open(LISTFILE, $list);
$i = 0;
while (<LISTFILE>) {
	chomp;
	next if /^\s*\#/;
	next unless /=/;
	my ($key, $value) = split(/=/, $_, 2);
	$value =~ s/(\$(\w+))/$list{$2}/g;
	$urls[$i] = ($value);
	$names[$i] = ($key);
	$i++;
}

$number = scalar @urls;


# subs for start of program
# getting args, print usage, etc

sub print_usage {
	warn "asDrinks $version. Usage:\n
	--headlines		Get headlines.
	--uf			Get User Friendly Comic.
	--noupdate		Don't update the startmenu when done.
	--quiet			Don't output information.
	--help			Display this help.
	--version		Version information.\n";
	exit;
}	

sub print_version {
	warn "asDrinks $version.\nWritten Jan 2, 2000 by Charlie Schmidt ishamael\@themes.org.\n";
	exit;
}

if (scalar(@ARGV > 3)) {
	warn "Incorrect number of arguments $ARGV\n";
	print_usage();
}
$i = 0;

# read args, store for use

while (scalar(@ARGV) >= 1) {
        $argument = shift(@ARGV);
        if ($argument eq '--help') {
                print_usage();
	} elsif ($argument eq '--version') {
		print_version();
	} elsif ($argument eq ' --noupdate') {
		$update = 0;
	} elsif ($argument eq '--quiet') {
		$verbose = 0;
	} elsif ($argument eq '--headlines') {
		$headlines = 1;
		$uf = 0;
	} elsif ($argument eq '--uf') {
		$uf = 1;
		$headlines = 0;
	} else {
		print_usage();
	}
}

if ($headlines == 1) {
	headlines();
}
if ($uf == 1) {
	userfriendly();
}
if ($update == 1) {
	update();
}

# do the stuff

sub headlines {	
	for ($i = 0; $i < $number; $i++) {
		$url = $urls[$i];
		$name = $names[$i];
		if ($verbose == 1) {
			print "Getting $name headlines using $url.\n";
		}
		$k = 0;
		$item  = 0;
		$title = 0;
		
		open(INFILE, "lynx -source $url|");
		while (<INFILE>) {
			next if $temp;
			if (/.*(\<item\>).*/) {
				$item = 1;
				next;
			}
			if ( (/.*(\<title\>.+\<\/title\>).*/) && ($item == 1) ) {
				$title_text = $1;
				$title_text =~ s/\<title\>//;
				$title_text =~ s/\<\/title\>//;
				strip();
			 	$item = 0;
				$title = 1;
				next;
			}
			if ( (/.*(\<link\>.+\<\/link\>).*/) && ($title == 1) ) {
				$link_text = $1;
				$link_text =~ s/\<link\>//;
				$link_text =~ s/\<\/link\>//;
				$title = 0;
				menufy();
				next;
			}
			$temp;
		}	
	}
}

sub userfriendly {
	if ($verbose == 1) {
		print "Getting UserFriendly comic.\n";
	}
	$imagetag = 0;
	open(INFILE, "$lynx -source http://www.userfriendly.org/static/|");
	while (<INFILE>) {
		next if $image;
		if (/.*(IMG ALT\=\"Latest Strip\" width\=576 BORDER\=0 SRC\=\"http:\/\/www.userfriendly.org\/cartoons\/archives\/.+<\/A>).*/) {
			$imagetag = $1;
			if ($imagetag =~ /.* ALT\s*=\s*"Latest Strip" .*/i) {
				if ($imagetag =~ /.*(\/cartoons\/archives\/.+f).*/i) {
					$image = $1;
					$image =~ s/xuf/uf/;
					`$lynx -source http://www.userfriendly.org$image > $ufieimage.gif`;
					# i like jpgs, deal.
					#`convert $ufieimage.gif $ufieimage.jpg`;
					#`rm $ufieimage.gif`;
				}
			}
		}
	}
	open (OUTFILE, ">$dir/zzuf");
	print OUTFILE "Exec \"Latest U.F.\" exec $viewer $ufieimage.gif &\n";
}

sub update {
	`$bindir/afterstep --version > $tempfile`;
 	open(FILE, "<$tempfile");
        while(defined($temp = <FILE>)) {
               	$as_version = $temp;
        }
	$asv1 = $as_version;
	$asv2 = $as_version;
	substr($asv1, 0, 20) = "";
	substr($asv1, 1, length($asv1)-2) = "";
	chomp($asv1);
	substr($asv2, 0, 22) = "";
	chomp($asv2);
	if ($asv1 >= 7 && $asv2 >= 55) {
		if ($verbose == 1) {
 			print "Updating Startmenu with AfterStep version 1.$asv1.$asv2\n";
	}
		`$bindir/ascommand.pl \'QuickRestart \"\" startmenu\'`;
	}
	unlink($tempfile);
}

sub strip {
	# if anyone notices im missing something, please tell me!
  	$title_text =~ s/\"/\'/gi;
      	$title_text =~ s/\<cite\>/\'/g;
        $title_text =~ s/\<\/cite\>/\'/g;
        $title_text =~ s/\&amp\;/and/g;
	$title_text =~ s/\&apos\;/\'/g;
}

sub menufy {
	$k++;
	# i can see this causing problems already....
	`mkdir -p "$dir/$name" > /dev/null 2>&1`;
	open(MENUFILE, ">$dir/$name/$k");
	print MENUFILE "Exec \"$title_text\" exec $netscape -remote 'openURL($link_text)' &\n";
}

