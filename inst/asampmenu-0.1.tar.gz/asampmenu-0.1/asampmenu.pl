#!/usr/bin/perl
@letters = qw(a b c d e f g h i j k l m n o p q r s t u v w x y z);
$i = 1;
$playlist = @ARGV[0];
$_ = $playlist;
($title)=(m/([^\/]+)$/);
$title =~ s/\.m3u//;
`mkdir ~/GNUstep/Library/AfterStep/start/mp3/$title`;
if (! -r $playlist) {
	print STDERR "$playlist is not readable. Ignoring.\n";
    } else {
	open (PLAYLIST, $playlist) || next;
	while ($song = <PLAYLIST>) {
	    chomp $song;
	    if (! -r $song) {
		die "$song not playable. Ignoring.";
	    } else {
	    	$name = $song;
		$song = Securesong ($song);
		$name = Securename ($name);
		$a = $letters[$i];
		`echo "Exec \\\"$name\\\" exec xmms -p $song" > ~/GNUstep/Library/AfterStep/start/mp3/$title/$a`;
		$i++;
	    }
	}
	

}
`echo "Exec \\\"$title\\\" exec xmms $playlist" > ~/GNUstep/Library/AfterStep/start/mp3/$title/a`;
		 


sub Securesong {
    $song = shift;
    $song =~ s/\'/\\\'/g; 
    $song =~ s/\(/\\\(/g; 
    $song =~ s/\)/\\\)/g; 
    $song =~ s/\ /\\\ /g; 
    $song =~ s/\&/\\\&/g;
    $song =~ s/\>/\\\>/g; 
    $song =~ s/\</\\\</g; 
    $song =~ s/\]/\\\]/g; 
    $song =~ s/\[/\\\[/g; 
    $song =~ s/\/\//\//g;
    return $song;
}
sub Securename {
    $name = shift;
    $name =~ s/\'/\\\'/g; 
    $name =~ s/\(/\\\(/g; 
    $name =~ s/\)/\\\)/g; 
    $name =~ s/\ /\\\ /g; 
    $name =~ s/\&/\\\&/g; 
    $name =~ s/\>/\\\>/g; 
    $name =~ s/\</\\\</g; 
    $name =~ s/\]/\\\]/g; 
    $name =~ s/\[/\\\[/g;
    $name =~ s/\/\//\//g;
    $_ = $name;
    ($name)=(m/([^\/]+)$/);
    return $name;
}
