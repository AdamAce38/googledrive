/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef X11AMPCTRL_H
#define X11AMPCTRL_H

#include <glib.h>

gint x11amp_connect_to_session(gint session); /* Do NOT use this! This is only for control socket initialization now. */
void x11amp_remote_playlist(gint session,gchar **list,gint num,gboolean enqueue);
gint x11amp_remote_get_version(gint session);
void x11amp_remote_playlist_add(gint session,GList *list);
void x11amp_remote_play(gint session);
void x11amp_remote_pause(gint session);
void x11amp_remote_stop(gint session);
gboolean x11amp_remote_is_playing(gint session);
gboolean x11amp_remote_is_paused(gint session);
gint x11amp_remote_get_playlist_pos(gint session);
void x11amp_remote_set_playlist_pos(gint session,gint pos);
gint x11amp_remote_get_playlist_length(gint session);
void x11amp_remote_playlist_clear(gint session);
gint x11amp_remote_get_output_time(gint session);
void x11amp_remote_jump_to_time(gint session,gint pos);
void x11amp_remote_get_volume(gint session,gint *vl,gint *vr);
void x11amp_remote_set_volume(gint session,gint vl,gint vr);
gchar *x11amp_remote_get_skin(gint session);
void x11amp_remote_set_skin(gint session,gchar *skinfile);
gchar *x11amp_remote_get_playlist_file(gint session,gint pos);
gchar *x11amp_remote_get_playlist_title(gint session,gint pos);
gint x11amp_remote_get_playlist_time(gint session,gint pos);
void x11amp_remote_get_info(gint session,gint *rate,gint *freq,gint *nch);
void x11amp_remote_pl_win_toggle(gint session,gboolean show);
void x11amp_remote_eq_win_toggle(gint session,gboolean show);
void x11amp_remote_show_prefs_box(gint session);
void x11amp_remote_toggle_aot(gint session,gboolean ontop);
void x11amp_remote_eject(gint session);
void x11amp_remote_playlist_prev(gint session);
void x11amp_remote_playlist_next(gint session);

/* Deprecated APIs */
void x11amp_remote_play_files(gint session,GList *list);
#define x11amp_remote_add_files(session,list) \
	x11amp_remote_playlist_add(session,list)

#endif
