/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include <glib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include "x11ampctrl.h"
#include "../x11amp/controlsocket.h"

gint x11amp_connect_to_session(gint session)
{
	gint fd;
	struct sockaddr_un saddr;
	
	if((fd=socket(AF_UNIX,SOCK_STREAM,0))!=-1)
	{
		saddr.sun_family=AF_UNIX;
	    	sprintf(saddr.sun_path,"%s/.x11amp/x11amp_ctrl.%d",g_get_home_dir(),session);
		if(connect(fd,(struct sockaddr*)&saddr,sizeof(saddr))!=-1)
			return fd;
	}
	return 0;
}

void x11amp_remote_playlist(gint session,gchar **list,gint num,gboolean enqueue)
{
	gint cmd=CMD_PLAYLIST_ADD,i,len,fd,dummy;

	if(!enqueue) x11amp_remote_playlist_clear(session);

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	for(i=0;i<num;i++)
	{
		len=strlen(list[i]);
		write(fd,&len,sizeof(gint));
		write(fd,list[i],len);
		read(fd,&dummy,sizeof(gint));
	}
	len=0;
	write(fd,&len,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);

	if(!enqueue) x11amp_remote_play(session);
}

static void remote_cmd(gint session,gint cmd)
{
	gint fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

static gboolean remote_get_gboolean(gint session,gint cmd)
{
	gboolean ret;
	gint fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,&ret,sizeof(gboolean));
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return ret;
}

static gint remote_get_gint(gint session,gint cmd)
{
	gint ret,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,&ret,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return ret;
}


gint x11amp_remote_getVersion(gint session)
{
	return remote_get_gint(session,CMD_GET_VERSION);
}

void x11amp_remote_play_files(gint session,GList *list)
{
	x11amp_remote_playlist_clear(session);
	x11amp_remote_add_files(session,list);
	x11amp_remote_play(session);
}

void x11amp_remote_playlist_add(gint session,GList *list)
{
	gint len,fd,dummy,cmd=CMD_PLAYLIST_ADD;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	
	while(list)
	{
		len=strlen((gchar *)list->data);
		write(fd,&len,sizeof(gint));
		write(fd,(gchar *)list->data,len);
		read(fd,&dummy,sizeof(gint));
		list=list->next;
	}
	len=0;
	write(fd,&len,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_play(gint session)
{
	remote_cmd(session,CMD_PLAY);
}

void x11amp_remote_pause(gint session)
{
	remote_cmd(session,CMD_PAUSE);
}

void x11amp_remote_stop(gint session)
{
	remote_cmd(session,CMD_STOP);
}

gboolean x11amp_remote_is_playing(gint session)
{
	return remote_get_gboolean(session,CMD_IS_PLAYING);
}

gboolean x11amp_remote_is_paused(gint session)
{
	return remote_get_gboolean(session,CMD_IS_PAUSED);
}

gint x11amp_remote_get_playlist_pos(gint session)
{
	return remote_get_gint(session,CMD_GET_PLAYLIST_POS);
}

void x11amp_remote_set_playlist_pos(gint session,gint pos)
{
	gint cmd=CMD_SET_PLAYLIST_POS,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&pos,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

gint x11amp_remote_get_playlist_length(gint session)
{
	return remote_get_gint(session,CMD_GET_PLAYLIST_LENGTH);
}

void x11amp_remote_playlist_clear(gint session)
{
	remote_cmd(session,CMD_PLAYLIST_CLEAR);
}

gint x11amp_remote_get_output_time(gint session)
{
	return remote_get_gint(session,CMD_GET_OUTPUT_TIME);
}

void x11amp_remote_jump_to_time(gint session,gint pos)
{
	gint cmd=CMD_JUMP_TO_TIME,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&pos,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_get_volume(gint session,gint *vl,gint *vr)
{
	gint cmd=CMD_GET_VOLUME,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,vl,sizeof(gint));
	read(fd,vr,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_set_volume(gint session,gint vl,gint vr)
{
	gint cmd=CMD_SET_VOLUME,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&vl,sizeof(gint));
	write(fd,&vr,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

gchar *x11amp_remote_get_skin(gint session)
{
	gint cmd=CMD_GET_SKIN,len,fd;
	gchar *filename=NULL;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,&len,sizeof(gint));
	if(len)
	{
		filename=g_malloc(len+1);
		read(fd,filename,len);
		*(filename+len)='\0';
	}
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return filename;
}

void x11amp_remote_set_skin(gint session,gchar *skinfile)
{
	gint cmd=CMD_SET_SKIN,len,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	len=(skinfile?strlen(skinfile):0);
	write(fd,&len,sizeof(gint));
	if(skinfile)
		write(fd,skinfile,len);
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

gchar *x11amp_remote_get_playlist_file(gint session,gint pos)
{
	gint cmd=CMD_GET_PLAYLIST_FILE,len,fd;
	gchar *filename;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&pos,sizeof(gint));
	read(fd,&len,sizeof(gint));
	filename=g_malloc(len+1);
	read(fd,filename,len);
	*(filename+len)='\0';
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return filename;
}

gchar *x11amp_remote_get_playlist_title(gint session,gint pos)
{
	gint cmd=CMD_GET_PLAYLIST_TITLE,len,fd;
	gchar *title;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&pos,sizeof(gint));
	read(fd,&len,sizeof(gint));
	title=g_malloc(len+1);
	read(fd,title,len);
	*(title+len)='\0';
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return title;
}

gint x11amp_remote_get_playlist_time(gint session,gint pos)
{
	gint cmd=CMD_GET_PLAYLIST_TIME,len,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&pos,sizeof(gint));
	read(fd,&len,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
	return len;
}

void x11amp_remote_get_info(gint session,gint *rate,gint *freq,gint *nch)
{
	gint cmd=CMD_GET_INFO,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	read(fd,rate,sizeof(gint));
	read(fd,freq,sizeof(gint));
	read(fd,nch,sizeof(gint));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_get_eq_data(gint session)
{
	/* write me! */
}

void x11amp_remote_set_eq_data(gint session)
{
	/* write me! */
}

void x11amp_remote_pl_win_toggle(gint session,gboolean show)
{
	gint cmd=CMD_PL_WIN_TOGGLE,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&show,sizeof(gboolean));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_eq_win_toggle(gint session,gboolean show)
{
	gint cmd=CMD_PL_WIN_TOGGLE,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&show,sizeof(gboolean));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_show_prefs_box(gint session)
{
	remote_cmd(session,CMD_SHOW_PREFS_BOX);
}

void x11amp_remote_toggle_aot(gint session,gboolean ontop)
{
	gint cmd=CMD_TOGGLE_AOT,fd;

	if(!(fd=x11amp_connect_to_session(session))) return;
	write(fd,&cmd,sizeof(gint));
	write(fd,&ontop,sizeof(gboolean));
	read(fd,&cmd,sizeof(gint));
	close(fd);
}

void x11amp_remote_show_about_box(gint session)
{
	remote_cmd(session,CMD_SHOW_ABOUT_BOX);
}

void x11amp_remote_eject(gint session)
{
	remote_cmd(session,CMD_EJECT);
}

void x11amp_remote_playlist_prev(gint session)
{
	remote_cmd(session,CMD_PLAYLIST_PREV);
}

void x11amp_remote_playlist_next(gint session)
{
	remote_cmd(session,CMD_PLAYLIST_NEXT);
}

