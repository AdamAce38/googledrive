#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

#include "x11amp/plugin.h"
#include "libx11amp/x11ampctrl.h"
#include "x11amp-dock-master.xpm"

typedef struct
{
	gint		x,y,width,height,pressed_x,pressed_y,normal_x,normal_y;
	gboolean	focus,pressed;
	void		(*callback)(void);
} Button;

static void action_play(void);
static void action_pause(void);
static void action_eject(void);
static void action_prev(void);
static void action_next(void);
static void action_stop(void);

Button buttons[] =
{
	21,28,9,11,20,64,0,64,FALSE,FALSE,action_play,	/* PLAY */
	33,28,9,11,30,64,10,64,FALSE,FALSE,action_pause,	/* PAUSE */
	45,28,9,11,20,75,0,75,FALSE,FALSE,action_eject,	/* EJECT */
	21,42,9,11,20,86,0,86,FALSE,FALSE,action_prev,	/* PREV */
	33,42,9,11,30,86,10,86,FALSE,FALSE,action_next,	/* NEXT */
	45,42,9,11,30,75,10,75,FALSE,FALSE,action_stop,	/* STOP */
};

#define NUM_BUTTONS 6
	
GList *button_list;

#define VOLSLIDER_X		11
#define VOLSLIDER_Y		12
#define	VOLSLIDER_WIDTH		6
#define	VOLSLIDER_HEIGHT	40

#define SEEKSLIDER_X		21
#define SEEKSLIDER_Y		16
#define SEEKSLIDER_WIDTH	30
#define SEEKSLIDER_HEIGHT	7
#define SEEKSLIDER_KNOB_WIDTH	3
#define SEEKSLIDER_MAX		(SEEKSLIDER_WIDTH - SEEKSLIDER_KNOB_WIDTH)


static gboolean	volslider_dragging = FALSE;
static gint	volslider_pos = 0;
static gboolean	seekslider_visible = FALSE,seekslider_dragging = FALSE;
static gint	seekslider_pos = -1, seekslider_drag_offset = 0;
static gint	timeout_tag = 0;

static void init(void);
static void cleanup(void);

static GeneralPlugin gp = {
	NULL,	/* handle */
	NULL,	/* filename */
	-1,	/* x11amp_session */
	"Window Maker dock applet",
	init,
	NULL,	/* about */
	NULL,   /* configure */
	cleanup
};

static GtkWidget *window,*icon_win;
static GdkPixmap *pixmap;
static GdkBitmap *mask;
static GdkGC *dock_gc;
	
GeneralPlugin* get_gplugin_info(void)
{
	return &gp;
}

static void action_play(void)
{
	x11amp_remote_play(gp.x11amp_session);
}

static void action_pause(void)
{
	x11amp_remote_pause(gp.x11amp_session);
}

static void action_eject(void)
{
	x11amp_remote_eject(gp.x11amp_session);
}

static void action_prev(void)
{
	x11amp_remote_playlist_prev(gp.x11amp_session);
}

static void action_next(void)
{
	x11amp_remote_playlist_next(gp.x11amp_session);
}

static void action_stop(void)
{
	x11amp_remote_stop(gp.x11amp_session);
}

static gboolean inside_region(gint mx,gint my,gint x,gint y,gint w,gint h)
{
	if((mx >= x && mx < x + w) && (my >= y && my < y + h))
		return TRUE;
	return FALSE;
}

/* AUTOFLUSH added this callback function so that we can kill x11amp
             by killing the dock window */
void delete_event( GtkWidget *widget,
                   GdkEvent  *event,
                   gpointer   data )
{
  gtk_main_quit ();
}
/* end of AUTOFLUSH 's stuff */



static void draw_button(GdkWindow *w,Button *button)
{

	if(button->pressed)
		gdk_draw_pixmap(w,dock_gc,pixmap,button->pressed_x,button->pressed_y,button->x,button->y,button->width,button->height);
	else
		gdk_draw_pixmap(w,dock_gc,pixmap,button->normal_x,button->normal_y,button->x,button->y,button->width,button->height);
}
				
static void draw_buttons(GdkWindow *w,GList *list)
{
	for(; list; list = g_list_next(list))
		draw_button(w,list->data);	
}

static void draw_volslider(GdkWindow *w)
{
	gdk_draw_pixmap(w,dock_gc,pixmap,48,65,VOLSLIDER_X,VOLSLIDER_Y,VOLSLIDER_WIDTH,VOLSLIDER_HEIGHT);
	gdk_draw_pixmap(w,dock_gc,pixmap,42,65+VOLSLIDER_HEIGHT-volslider_pos,VOLSLIDER_X,VOLSLIDER_Y+VOLSLIDER_HEIGHT-volslider_pos,VOLSLIDER_WIDTH,volslider_pos);
}

static void draw_seekslider(GdkWindow *w)
{
	gint slider_x;
	if(seekslider_visible)
	{
		gdk_draw_pixmap(w,dock_gc,pixmap,2,114,19,12,35,14);
		if(seekslider_pos < SEEKSLIDER_MAX / 3)
			slider_x = 44;
		else if(seekslider_pos < (SEEKSLIDER_MAX * 2) / 3)
			slider_x = 47;
		else
			slider_x = 50;
		gdk_draw_pixmap(w,dock_gc,pixmap,slider_x,112,SEEKSLIDER_X+seekslider_pos,SEEKSLIDER_Y,3,SEEKSLIDER_HEIGHT);
	}
	else
		gdk_draw_pixmap(w,dock_gc,pixmap,2,100,19,12,35,14);
}

static void expose_cb(GtkWidget *w,GdkEventExpose *event,gpointer data)
{
	gdk_draw_pixmap(w->window,dock_gc,pixmap,0,0,0,0,64,64);
	draw_buttons(w->window,button_list);
	draw_volslider(w->window);
}

static void button_press_cb(GtkWidget *w,GdkEventButton *event,gpointer data)
{
	GList *node;
	Button *btn;
	gint pos;
	
	if(event->button != 1)
		return;
	
	for(node = button_list; node; node = g_list_next(node))
	{
		btn = node->data;
		if(inside_region(event->x,event->y,btn->x,btn->y,btn->width,btn->height))
		{
			btn->focus = TRUE;
			btn->pressed = TRUE;
			draw_button(w->window,btn);
		}
	}
	if(inside_region(event->x,event->y,VOLSLIDER_X,VOLSLIDER_Y,VOLSLIDER_WIDTH,VOLSLIDER_HEIGHT))
	{
		volslider_pos = VOLSLIDER_HEIGHT - (event->y - VOLSLIDER_Y);
		x11amp_remote_set_volume(gp.x11amp_session,(volslider_pos*100)/VOLSLIDER_HEIGHT,(volslider_pos*100)/VOLSLIDER_HEIGHT);
		draw_volslider(w->window);
		volslider_dragging = TRUE;
	}
	if(inside_region(event->x,event->y,SEEKSLIDER_X,SEEKSLIDER_Y,SEEKSLIDER_WIDTH,SEEKSLIDER_HEIGHT) && seekslider_visible)
	{
		pos = event->x - SEEKSLIDER_X;
		
		if(pos >= seekslider_pos && pos < seekslider_pos + SEEKSLIDER_KNOB_WIDTH)
			seekslider_drag_offset = pos - seekslider_pos;
		else
		{
			seekslider_drag_offset = 1;
			seekslider_pos = pos - seekslider_drag_offset;
			if(seekslider_pos < 0)
				seekslider_pos = 0;
			if(seekslider_pos > SEEKSLIDER_MAX)
				seekslider_pos = SEEKSLIDER_MAX;
		}
		draw_seekslider(w->window);
		seekslider_dragging = TRUE;
	}
}

static void button_release_cb(GtkWidget *w,GdkEventButton *event,gpointer data)
{
	GList *node;
	Button *btn;
	gint len;
	
	if(event->button != 1)
		return;
	
	for(node = button_list; node; node = g_list_next(node))
	{
		btn = node->data;
		if(btn->pressed)
		{
			btn->focus = FALSE;
			btn->pressed = FALSE;
			draw_button(w->window,btn);
			if(btn->callback)
				btn->callback();
		}
	}
	volslider_dragging = FALSE;
	if(seekslider_dragging)
	{
		len = x11amp_remote_get_playlist_time(gp.x11amp_session,x11amp_remote_get_playlist_pos(gp.x11amp_session));
		x11amp_remote_jump_to_time(gp.x11amp_session,((seekslider_pos * len) / SEEKSLIDER_MAX));
		seekslider_dragging = FALSE;
	}

}

static void motion_notify_cb(GtkWidget *w,GdkEventMotion *event,gpointer data)
{
	GList *node;
	Button *btn;
	gboolean inside;
	
	for(node = button_list; node; node = g_list_next(node))
	{
		btn = node->data;
		if(btn->focus)
		{
			inside = inside_region(event->x,event->y,btn->x,btn->y,btn->width,btn->height);
			if((inside && !btn->pressed) || (!inside && btn->pressed))
			{
				btn->pressed = inside;
				draw_button(w->window,btn);
			}
		}
	}
	if(volslider_dragging)
	{
		volslider_pos = VOLSLIDER_HEIGHT - (event->y - VOLSLIDER_Y);
		if(volslider_pos < 0)
			volslider_pos = 0;
		if(volslider_pos > VOLSLIDER_HEIGHT)
			volslider_pos = VOLSLIDER_HEIGHT;
		x11amp_remote_set_volume(gp.x11amp_session,(volslider_pos*100)/VOLSLIDER_HEIGHT,(volslider_pos*100)/VOLSLIDER_HEIGHT);
		draw_volslider(w->window);
	}
	if(seekslider_dragging)
	{
		seekslider_pos = (event->x - SEEKSLIDER_X) - seekslider_drag_offset;
		if(seekslider_pos < 0)
			seekslider_pos = 0;
		if(seekslider_pos > SEEKSLIDER_MAX)
			seekslider_pos = SEEKSLIDER_MAX;
		draw_seekslider(w->window);
	}

}


static gint timeout_func(gpointer data)
{
	gint vl,vr,new_pos,pos,len;
	gboolean playing;
	
	if(!volslider_dragging)
	{
		x11amp_remote_get_volume(gp.x11amp_session,&vl,&vr);

		new_pos = ((vl > vr ? vl : vr) * 40) / 100;

		if(new_pos < 0)
			new_pos = 0;
		if(new_pos > VOLSLIDER_HEIGHT)
			new_pos = VOLSLIDER_HEIGHT;
		
		if(volslider_pos != new_pos)
		{
			volslider_pos = new_pos;
			draw_volslider(icon_win->window);
		}
	}
	
	playing = x11amp_remote_is_playing(gp.x11amp_session);
	if(!playing && seekslider_visible)
	{
		seekslider_visible = FALSE;
		seekslider_dragging = FALSE;
		seekslider_pos = -1;
		draw_seekslider(icon_win->window);
	}
	else if(playing)
	{
		seekslider_visible = TRUE;
		len = x11amp_remote_get_playlist_time(gp.x11amp_session,x11amp_remote_get_playlist_pos(gp.x11amp_session));
		if(len == -1 && seekslider_visible)
		{
			seekslider_visible = FALSE;
			seekslider_dragging = FALSE;
			seekslider_pos = -1;
			draw_seekslider(icon_win->window);
		}
		else if(!seekslider_dragging)
		{
			pos = x11amp_remote_get_output_time(gp.x11amp_session);
			new_pos = (pos * SEEKSLIDER_MAX) / len;
			if(new_pos < 0)
				new_pos = 0;
			if(new_pos > SEEKSLIDER_MAX)
				new_pos = SEEKSLIDER_MAX;
			if(seekslider_pos != new_pos)
			{
				seekslider_pos = new_pos;
				draw_seekslider(icon_win->window);
			}
		}
	}
	
	return TRUE;
}

static void init(void)
{
	Window xwin;
	XWMHints hints;
	GdkAtom wm_client_leader_atom;
	GdkColor bg_color;
	gint i;
	
	volslider_dragging = FALSE;
	volslider_pos = 0;
	
	seekslider_visible = FALSE;
	seekslider_dragging = FALSE;
	seekslider_pos = -1;
	seekslider_drag_offset = 0;
	
	for(i = 0; i < NUM_BUTTONS; i++)
		button_list = g_list_append(button_list,&buttons[i]);
	
	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_realize(window);
	
	xwin = GDK_WINDOW_XWINDOW(window->window);

	hints.window_group = xwin;
	hints.initial_state = WithdrawnState;
	hints.flags = WindowGroupHint | StateHint;
	
	XSetWMHints(GDK_DISPLAY(),xwin,&hints);
	
	wm_client_leader_atom = gdk_atom_intern("WM_CLIENT_LEADER", FALSE);

        gdk_property_change(window->window,wm_client_leader_atom,XA_WINDOW,32,GDK_PROP_MODE_REPLACE,(guchar *)&xwin,1);

	
        /* AUTOFLUSH - changed this to top level so the window manager would
                       treat it normally and give it a name.
	icon_win = gtk_window_new(GTK_WINDOW_POPUP); 
         */
	icon_win = gtk_window_new(GTK_WINDOW_TOPLEVEL);

        gtk_window_set_title(GTK_WINDOW(icon_win),"asamp");
	gtk_widget_set_app_paintable(icon_win,TRUE);
	gtk_widget_set_uposition(icon_win,958,0);
	gtk_widget_set_usize(icon_win,64,64);
	gtk_widget_set_events (icon_win,GDK_BUTTON_MOTION_MASK|GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK|GDK_EXPOSURE_MASK);
	gtk_signal_connect(GTK_OBJECT(icon_win),"expose_event",GTK_SIGNAL_FUNC(expose_cb),NULL);
	gtk_signal_connect(GTK_OBJECT(icon_win),"button_press_event",GTK_SIGNAL_FUNC(button_press_cb),NULL);
	gtk_signal_connect(GTK_OBJECT(icon_win),"button_release_event",GTK_SIGNAL_FUNC(button_release_cb),NULL);
	gtk_signal_connect(GTK_OBJECT(icon_win),"motion_notify_event",GTK_SIGNAL_FUNC(motion_notify_cb),NULL);
        /* AUTOFLSH added delete_event so that we can kill x11amp
           by killing the icon_win (dock win) */
        gtk_signal_connect (GTK_OBJECT (icon_win), "delete_event",
                            GTK_SIGNAL_FUNC (delete_event), NULL);
        /* end of AUTOFLUSH's messing */
	gtk_widget_realize(icon_win);
	bg_color.red = 0;
	bg_color.green = 0;
	bg_color.blue = 0;
	gdk_colormap_alloc_color(gdk_colormap_get_system(),&bg_color,FALSE,TRUE);
	gdk_window_set_background(icon_win->window,&bg_color);
	gdk_window_clear(icon_win->window);
	
	pixmap = gdk_pixmap_create_from_xpm_d(icon_win->window,&mask,NULL,x11amp_dock_master_xpm);
	gtk_widget_shape_combine_mask(icon_win,mask,0,0);
	dock_gc = gdk_gc_new(icon_win->window);
	
	gdk_window_set_icon(window->window,icon_win->window,NULL,NULL);
        /* AUTOFLUSH - got rid of this so the useless gray window
                       would not show up
	gtk_widget_show(window);
        */
	gtk_widget_show(icon_win);
	timeout_tag = gtk_timeout_add(100,timeout_func,NULL);
	
}

static void cleanup(void)
{
	gtk_widget_destroy(icon_win);
	gtk_widget_destroy(window);
	gdk_pixmap_unref(pixmap);
	gdk_bitmap_unref(mask);
	gdk_gc_unref(dock_gc);
	g_list_free(button_list);
	button_list = NULL;
	
	if(timeout_tag)
		gtk_timeout_remove(timeout_tag);
	timeout_tag = 0;
}
