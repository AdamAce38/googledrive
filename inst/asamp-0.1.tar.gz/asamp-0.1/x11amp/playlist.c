/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

GList	*playlist=NULL,*playlist_get_info_pos=NULL;
GList	*shuffle_list=NULL;
PlaylistEntry	*playlist_position;

extern PlayList_List *playlistwin_list;

static GList *find_playlist_position_list(void)
{
	if(cfg.shuffle)
		return g_list_find(shuffle_list,playlist_position);
	return g_list_find(playlist,playlist_position);
}


void playlist_clear(void)
{
	GList *node;
	PlaylistEntry *entry;
	
	if(playlist)
	{
		if(get_input_playing()) input_stop();
		node=playlist;
		while(node)
		{
			entry=(PlaylistEntry *)node->data;
			if(entry->filename) g_free(entry->filename);
			if(entry->title) g_free(entry->title);
			g_free(entry);
			node=node->next;
		}
		g_list_free(playlist);
		playlist=NULL;
		playlist_position=NULL;
		playlist_get_info_pos=NULL;
		playlist_generate_shuffle_list();
	}
}

void playlist_delete(gboolean crop)
{
	gboolean restart_playing=FALSE,set_info_text=FALSE,regen_shuffle=FALSE;
	GList *node=playlist,*next;
	PlaylistEntry *entry;
	GList	*plist_pos_list;
	
	while(node)
	{
		entry=(PlaylistEntry *)node->data;
		next=g_list_next(node);
		if((entry->selected&&!crop)||(!entry->selected&&crop))
		{
			regen_shuffle=TRUE;
			/*
			 * We call g_list_find manually here because we don't want an item in the shuffle_list
			 */
			plist_pos_list=g_list_find(playlist,playlist_position);
			if(plist_pos_list==node)
			{
				set_info_text=TRUE;
				if(get_input_playing())
				{
					input_stop();
					restart_playing=TRUE;
				}
				if(g_list_next(plist_pos_list))
					playlist_position=g_list_next(plist_pos_list)->data;
				else if(g_list_previous(plist_pos_list))
					playlist_position=g_list_previous(plist_pos_list)->data;
				else if(node!=playlist)
					playlist_position=playlist->data;
				else
					playlist_position=NULL;
			}
			if(playlist_get_info_pos==node)
				playlist_get_info_pos=g_list_next(node);
			if(entry->filename)
				g_free(entry->filename);
			if(entry->title)
				g_free(entry->title);
			playlist=g_list_remove_link(playlist,node);
			g_free(entry);
			g_list_free_1(node);
		}
		node=next;
	}
	playlistwin_update_list();
	if(regen_shuffle)
		playlist_generate_shuffle_list();
	if(set_info_text)
		mainwin_set_info_text();
	if(restart_playing)
	{
		if(playlist_position)
			playlist_play();
		else
			mainwin_set_song_info(0,0,0);
	}
}

void playlist_select_all(void)
{
	GList *node;
	
	node=playlist;
	while(node)
	{
		((PlaylistEntry *)node->data)->selected=TRUE;
		node=node->next;
	}
	playlistwin_update_list();
}	
		
void playlist_select_none(void)
{
	GList *node;
	
	node=playlist;
	while(node)
	{
		((PlaylistEntry *)node->data)->selected=FALSE;
		node=node->next;
	}
	playlistwin_update_list();
}	

void playlist_inverse_selection(void)
{
	GList *node;
	
	node=playlist;
	while(node)
	{
		((PlaylistEntry *)node->data)->selected=!((PlaylistEntry *)node->data)->selected;
		node=node->next;
	}
	playlistwin_update_list();
}	

			
void playlist_add(gchar *filename)
{
	playlist_ins(filename,get_playlist_length());
}

void playlist_ins(gchar *filename,guint pos)
{
	PlaylistEntry *entry;
	gchar *ext;
	
	if(input_check_file(filename))
	{
		if(pos>get_playlist_length())
			pos=get_playlist_length();
		entry=g_malloc0(sizeof(PlaylistEntry));
		entry->filename=g_strdup(filename);
		entry->length=-1;
		playlist=g_list_insert(playlist,entry,pos);
		playlist_get_info_pos=playlist;
	}
}

void playlist_add_dir(gchar *path)
{
	playlist_ins_dir(path,get_playlist_length());
}

guint playlist_ins_dir(gchar *path,guint pos)
{
	DIR *dir;
	struct dirent *dirent;
	struct stat statbuf;
	gchar *filename,*temp;
	guint startpos=pos;
	GList *list,*node;
	
	if(pos>get_playlist_length())
		startpos=pos=get_playlist_length();

	
	if(path[strlen(path)-1]!='/')
		temp=g_strdup_printf("%s/",path);
	else
		temp=g_strdup(path);
	
	if(list=input_scan_dir(temp))
	{
		g_free(temp);
		node=list;
		while(node)
		{
			playlist_ins(node->data,pos++);
			g_free(node->data);
			node=g_list_next(node);
		}
		g_list_free(list);
		playlist_generate_shuffle_list();
		return;
	}
	g_free(temp);
	if(dir=opendir(path))
	{
		while(dirent=readdir(dir))
		{
			if(dirent->d_name[0]!='.')
			{
				filename=g_strconcat(path,"/",dirent->d_name,NULL);
				lstat(filename,&statbuf);
				if(S_ISDIR(statbuf.st_mode))
					pos+=playlist_ins_dir(filename,pos);
				else
					playlist_ins(filename,pos++);
				g_free(filename);
			}
		}
		playlist_generate_shuffle_list();
		closedir(dir);
	}
	return pos-startpos;
}

/*
 * I'm not sure if this is the correct way to do it but it seems to work fine
 */

void playlist_add_url_string(gchar *string)
{
	playlist_ins_url_string(string,get_playlist_length());
}

guint playlist_ins_url_string(gchar *string,guint pos)
{
	gint i=0,start;
	gchar *temp,*ext;
	struct stat statbuf;
	guint startpos=pos;
	
	if(pos>get_playlist_length())
		startpos=pos=get_playlist_length();
	while(*string)
	{
		temp=strchr(string,'\n');
		if(temp)
		{
			if(*(temp-1)=='\r')
				*(temp-1)='\0';
			*temp='\0';
		}
		if(!strncasecmp(string,"file:",5))
			string=string+5;

		stat(string,&statbuf);
		if(S_ISDIR(statbuf.st_mode))
			pos+=playlist_ins_dir(string,pos);
		else
		{
			ext=strrchr(string,'.');
			if(ext)
			{
				if(!strcasecmp(ext,".m3u")||!strcasecmp(ext,".pls"))
					pos+=playlist_load_ins(string,pos);
				else
					playlist_ins(string,pos++);
			}
			else
				playlist_ins(string,pos++);
		}
		if(!temp)
			break;
		string=temp+1;
	}
	playlist_generate_shuffle_list();

	return pos-startpos;	
}

void playlist_play(void)
{
	PlaylistEntry *entry;
	gchar *ptr;
	
	if(get_playlist_length()==0)
		return;
	entry=playlist_position;

	if(get_input_playing()) input_stop();
	
	input_play(entry->filename);
	
	if(input_get_time()!=-1)
	{
		equalizerwin_load_auto_preset(entry->filename);
		input_set_eq(cfg.equalizer_active,cfg.equalizer_preamp,cfg.equalizer_bands);
	}
	playlist_check_pos_current();
}

void playlist_set_info(gchar *title,gint length,gint rate,gint freq,gint nch)
{
	
	PlaylistEntry *entry;
	
	entry=playlist_position;
	
	if(!entry->title && title)
		entry->title=g_strdup(title);
	if(entry->length==-1)
		entry->length=length;
	mainwin_set_song_info(rate,freq,nch);
	mainwin_set_info_text();
	playlistwin_update_list();
}

void playlist_check_pos_current(void)
{
	guint pos=g_list_index(get_playlist(),playlist_position);

	if(playlistwin_list&&!playlistwin_item_visible(pos))
	{
		if(pos<playlistwin_list->pl_num_visible/2)
			playlistwin_set_toprow(0);
		else if(get_playlist_length()-pos<playlistwin_list->pl_num_visible/2)
			playlistwin_set_toprow(get_playlist_length()-playlistwin_list->pl_num_visible);
		else
			playlistwin_set_toprow(pos-(playlistwin_list->pl_num_visible/2));
	}
}

void playlist_next(void)
{
	GList *plist_pos_list;
	gint playing;
	
	if(!playlist) return;

	plist_pos_list=find_playlist_position_list();

	if(!cfg.repeat&&!g_list_next(plist_pos_list))
		return;

	playing=get_input_playing();
	if(playing)
		input_stop();
	if(g_list_next(plist_pos_list))
		playlist_position=g_list_next(plist_pos_list)->data;
	else if(cfg.repeat)
		if(cfg.shuffle)
			playlist_position=shuffle_list->data;
		else
			playlist_position=playlist->data;
	playlist_check_pos_current();
	if(playing)
	{
		playlist_play();
	}
	else
	{
		mainwin_set_info_text();
		playlistwin_update_list();
	}
}

void playlist_prev(void)
{
	GList *plist_pos_list;
	gint playing;

	if(!playlist) return;
	
	plist_pos_list=find_playlist_position_list();
	
	if(!cfg.repeat&&!g_list_previous(plist_pos_list))
		return;

	playing=get_input_playing();
	if(playing)
		input_stop();
	if(g_list_previous(plist_pos_list))
		playlist_position=g_list_previous(plist_pos_list)->data;
	playlist_check_pos_current();
	if(playing)
	{
		playlist_play();
	}
	else
	{
		mainwin_set_info_text();
		playlistwin_update_list();
	}
}

void playlist_set_position(gint pos)
{
	if(!playlist) return;
	
	playlist_position=g_list_nth(playlist,pos)->data;
	playlist_check_pos_current();
	if(get_input_playing())
	{
		input_stop();
		playlist_play();
	}
	else
	{
		mainwin_set_info_text();
		playlistwin_update_list();
	}
}

void playlist_eof_reached(void)
{
	GList *plist_pos_list;
	input_stop();
	
	plist_pos_list=find_playlist_position_list();

	if(cfg.no_playlist_advance)
	{
		mainwin_set_song_info(0,0,0);
		if(cfg.repeat) playlist_play();
		return;
	}
	if(!g_list_next(plist_pos_list))
	{
		if(cfg.shuffle)
			playlist_position=shuffle_list->data;
		else
			playlist_position=playlist->data;
		if(!cfg.repeat)
		{
			mainwin_set_song_info(0,0,0);
			mainwin_set_info_text();
			return;
		}
	}
	else
		playlist_position=g_list_next(plist_pos_list)->data;
	playlist_check_pos_current();
	playlist_play();
	mainwin_set_info_text();
	playlistwin_update_list();
}
	
gint get_playlist_length(void)
{
	if(!playlist)
		return 0;
	return g_list_length(playlist);
}

gchar *playlist_get_info_text(void)
{
	PlaylistEntry *entry;
	gchar *text=NULL,*title,*tmp,*tmp2;
	gint i;
	
	if(playlist)
	{
		entry=(PlaylistEntry *)playlist_position;
		if(entry->title)
			title=entry->title;
		else
		{
			title=strrchr(entry->filename,'/');
			if(!title)
				title=entry->filename;
			else
				title++;
		}
		text=g_malloc(strlen(title)+20);
		if(entry->length!=-1)
			sprintf(text,"%d. %s (%d:%-2.2d)",get_playlist_position()+1,title,entry->length/60000,(entry->length/1000)%60);
		else
			sprintf(text,"%d. %s",get_playlist_position()+1,title);
		if(cfg.convert_underscore)
			while(tmp=strchr(text,'_'))
				*tmp=' ';
		if(cfg.convert_twenty)
			while(tmp=strstr(text,"%20"))
			{
				tmp2=tmp+3;
				*(tmp++)=' ';
				while(*tmp2)
					*(tmp++)=*(tmp2++);
				*tmp='\0';
			}
					
		
			
	}
	return text;
}

int playlist_get_current_length(void)
{
	if(!playlist) return 0;
	

	return playlist_position->length;
}
	
gboolean playlist_save(gchar *filename)
{
	PlaylistEntry *entry;
	GList *node;
	FILE *file;
	gchar *ext;
	gboolean is_pls=FALSE;
	
	if(file=fopen(filename,"w"))
	{
		ext=strrchr(filename,'.');
		if(ext)
			if(!strcasecmp(ext,".pls"))
			{
				is_pls=TRUE;
				fprintf(file,"[playlist]\n");
				fprintf(file,"NumberOfEntries=%d\n",get_playlist_length());
			}
		node=playlist;
		while(node)
		{
			entry=(PlaylistEntry *)node->data;
			if(is_pls)
				fprintf(file,"File%d=%s\n",g_list_position(playlist,node)+1,entry->filename);
			else
				fprintf(file,"%s\n",entry->filename);
			node=node->next;
		}
		fclose(file);
		return TRUE;
	}
	return FALSE;
}

gboolean playlist_load(gchar *filename)
{
	return playlist_load_ins(filename,get_playlist_length());
}

guint playlist_load_ins(gchar *filename,guint pos)
{
	FILE *file;
	gchar *line,*ext,key[10];
	gint i,noe;
	guint startpos=pos;
	int linelen=1024;

	if(pos>get_playlist_length())
		startpos=pos=get_playlist_length();	

	ext=strrchr(filename,'.');
	if(!ext) ext=".m3u";
	if(!strcasecmp(ext,".pls"))
	{
		if(line=read_ini_string(filename,"playlist","NumberOfEntries"))
		{
			noe=atoi(line);
			g_free(line);
		}	
		else
			return FALSE;
		for(i=1;i<=noe;i++)
		{
			g_snprintf(key,10,"File%d",i);
			if(line=read_ini_string(filename,"playlist",key))
			{
				playlist_ins(line,pos++);
				g_free(line);
			}
		}
		playlist_generate_shuffle_list();
		return pos-startpos;
	}
	else
	{
		if(file=fopen(filename,"r"))
		{
			line=g_malloc(linelen);
			while(fgets(line,linelen,file))
			{
				while(strlen(line)==linelen-1&&line[strlen(line)-1]=='\n')
				{
					linelen+=1024;
					line=(gchar *)g_realloc(line,linelen);
					fgets(&line[strlen(line)],1024,file);
				}
				while(line[strlen(line)-1]=='\r'||line[strlen(line)-1]=='\n') line[strlen(line)-1]='\0';
				playlist_ins(line,pos++);
			}
			fclose(file);
			playlist_generate_shuffle_list();
			return pos-startpos;
		}
	}
	return FALSE;
}

GList *get_playlist(void)
{
	return playlist;
}

gint get_playlist_position(void)
{
	return g_list_index(playlist,playlist_position);
}

gint playlist_sort_by_title_cmpfunc(PlaylistEntry *a,PlaylistEntry *b)
{
	gchar *a_title=NULL,*b_title=NULL;
	if(a->title)
		a_title=a->title;
	else
	{
		if(a->filename[0]='/')
			a_title=strrchr(a->filename,'/')+1;
		if(!a_title)
			a_title=a->filename;
	}
		
	if(b->title)
		b_title=b->title;
	else
	{
		if(b->filename[0]='/')
			b_title=strrchr(b->filename,'/')+1;
		if(!b_title)
			b_title=b->filename;

		
	}
	return strcasecmp(a_title,b_title);
}
		

void playlist_sort_by_title(void)
{
	playlist=g_list_sort(playlist,(GCompareFunc)playlist_sort_by_title_cmpfunc);
}

gint playlist_sort_by_filename_cmpfunc(PlaylistEntry *a,PlaylistEntry *b)
{
	gchar *a_filename=NULL,*b_filename=NULL;
	if(a->filename[0]='/')
		a_filename=strrchr(a->filename,'/')+1;
	if(!a_filename)
		a_filename=a->filename;
	
	if(b->filename[0]='/')
		b_filename=strrchr(b->filename,'/')+1;
	if(!b_filename)
		b_filename=b->filename;
	
	return strcasecmp(a_filename,b_filename);
}
		

void playlist_sort_by_filename(void)
{
	playlist=g_list_sort(playlist,(GCompareFunc)playlist_sort_by_filename_cmpfunc);
}
		
gint playlist_sort_by_path_cmpfunc(PlaylistEntry *a,PlaylistEntry *b)
{
	return strcasecmp(a->filename,b->filename);
}
		

void playlist_sort_by_path(void)
{
	playlist=g_list_sort(playlist,(GCompareFunc)playlist_sort_by_path_cmpfunc);
}

void playlist_reverse(void)
{
	playlist=g_list_reverse(playlist);
}

void playlist_random(void)
{
	GList *new_list, *node, *prev;
	int numsongs = g_list_length(playlist) ;

	new_list = g_list_nth(playlist, rand() % numsongs--);
	playlist = g_list_remove_link (playlist, new_list);
	prev = new_list;

	while (numsongs) {
		node = g_list_nth(playlist, rand() % numsongs--);
		playlist = g_list_remove_link (playlist, node);
		prev->next = node;
		node->prev = prev;
		prev = node;
	}

	playlist = new_list;
}

void playlist_generate_shuffle_list(void)
{
	GList *new_list,*node=playlist,*prev;
	gint numsongs;
	
	if(shuffle_list)
	{
		g_list_free(shuffle_list);
		shuffle_list=NULL;
	}
	if(playlist)
	{
		while(node)
		{			
			shuffle_list=g_list_append(shuffle_list,node->data);
			node=g_list_next(node);
		}
		numsongs = g_list_length(shuffle_list) ;
		
		if(!numsongs)
			return;

		new_list = g_list_nth(shuffle_list, rand() % numsongs--);
		shuffle_list = g_list_remove_link (shuffle_list, new_list);
		prev = new_list;

		while (numsongs) {
			node = g_list_nth(shuffle_list, rand() % numsongs--);
			shuffle_list = g_list_remove_link (shuffle_list, node);
			prev->next = node;
			node->prev = prev;
			prev = node;
		}
		shuffle_list = new_list;
	}
	if(!playlist_position&&playlist)
	{
		if(cfg.shuffle)
			playlist_position=shuffle_list->data;
		else
			playlist_position=playlist->data;
		mainwin_set_info_text();
	}
			
}

void playlist_get_info_iteration(void)
{
	GList *node;
	PlaylistEntry *entry;

	for(node=playlist_get_info_pos;node;node=g_list_next(node))
	{
		entry=node->data;
		if(entry->title || entry->length != -1 ||
		   (!cfg.get_info_on_load && !playlistwin_item_visible(g_list_position(playlist,node))))
			continue;
		input_get_song_info(entry->filename,&entry->title,&entry->length);
		if(!entry->title && entry->length == -1)
			continue;
		if(cfg.get_info_on_load||(playlistwin_item_visible(g_list_position(playlist,node)) && (entry->title || entry->length != -1)))
			playlistwin_update_list();
		if(entry==(PlaylistEntry *)g_list_nth(get_playlist(),get_playlist_position())->data)
			mainwin_set_info_text();
		break;
	}
}
		
