/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"
#include <gdk/gdkx.h>
#include <X11/Xlib.h>
#include <getopt.h>
#include "libx11amp/configfile.h"
#include "libx11amp/x11ampctrl.h"

		
GtkWidget	*mainwin,*mainwin_filesel=NULL,*mainwin_url_window=NULL;
GtkWidget	*mainwin_jtt=NULL,*mainwin_jtf=NULL;
GtkItemFactory	*mainwin_options_menu,*mainwin_songname_menu,*mainwin_vis_menu;
GtkItemFactory	*mainwin_general_menu;
GdkPixmap	*mainwin_bg=NULL,*mainwin_bg_dblsize;
GdkGC		*mainwin_gc;
GdkWindow	*root_window;

GtkAccelGroup	*mainwin_accel;
GtkAccelGroup	*global_accel;

gboolean	mainwin_moving=FALSE,mainwin_focus=FALSE,mainwin_move_playlist=FALSE,mainwin_move_equalizer=FALSE;
gboolean	start_playing=FALSE,setting_volume=FALSE;
gint		mainwin_move_x,mainwin_move_y;
gint		mainwin_timeout_tag;

PButton		*mainwin_menubtn,*mainwin_minimize,*mainwin_shade,*mainwin_close;
PButton 	*mainwin_rew,*mainwin_play,*mainwin_pause,*mainwin_stop,*mainwin_fwd,*mainwin_eject;
SButton		*mainwin_srew,*mainwin_splay,*mainwin_spause,*mainwin_sstop,*mainwin_sfwd,*mainwin_seject;
TButton 	*mainwin_shuffle,*mainwin_repeat,*mainwin_eq,*mainwin_pl;
TextBox 	*mainwin_info,*mainwin_rate_text,*mainwin_freq_text,*mainwin_stime_min,*mainwin_stime_sec;
MenuRow		*mainwin_menurow;
HSlider 	*mainwin_volume,*mainwin_balance,*mainwin_position,*mainwin_sposition = NULL;
MonoStereo	*mainwin_monostereo;
PlayStatus	*mainwin_playstatus;
Number		*mainwin_minus_num,*mainwin_10min_num,*mainwin_min_num,*mainwin_10sec_num,*mainwin_sec_num;
Vis		*mainwin_vis;
SVis		*mainwin_svis;

GList		*mainwin_wlist=NULL;

GList		*disabled_iplugins=NULL;

gint		bitrate,frequency,numchannels;

Config cfg;

static gboolean mainwin_force_redraw=FALSE;
static gchar *mainwin_title_text=NULL;
static gboolean mainwin_info_text_locked=FALSE;

static GtkTargetEntry drop_types [] = {
	{ "text/plain", 0, 1 }
};

#define MAINWIN_OPTIONS_MENU_ENTRIES 15

void mainwin_options_menu_callback(gpointer cb_data,guint action,GtkWidget *w);

enum {MAINWIN_OPT_PREFS,MAINWIN_OPT_SKIN,MAINWIN_OPT_REPEAT,MAINWIN_OPT_SHUFFLE,
	MAINWIN_OPT_NPA,MAINWIN_OPT_TELAPSED,MAINWIN_OPT_TREMAINING,MAINWIN_OPT_ALWAYS,MAINWIN_OPT_WS,
	MAINWIN_OPT_PWS,MAINWIN_OPT_DOUBLESIZE,MAINWIN_OPT_EASY_MOVE};


GtkItemFactoryEntry	mainwin_options_menu_entries[]=
{
	"/Preferences",			"<control>P",mainwin_options_menu_callback,MAINWIN_OPT_PREFS,"<Item>",
	"/Skin Browser",		"<alt>S",mainwin_options_menu_callback,MAINWIN_OPT_SKIN,"<Item>",
	"/-",				NULL,NULL,0,"<Separator>",
	"/Repeat",			"R",mainwin_options_menu_callback,MAINWIN_OPT_REPEAT,"<ToggleItem>",
	"/Shuffle",			"S",mainwin_options_menu_callback,MAINWIN_OPT_SHUFFLE,"<ToggleItem>",
	"/No Playlist Advance",		NULL,mainwin_options_menu_callback,MAINWIN_OPT_NPA,"<ToggleItem>",
	"/-",				NULL,NULL,0,"<Separator>",
	"/Time Elapsed",		"<control>E",mainwin_options_menu_callback,MAINWIN_OPT_TELAPSED,"<RadioItem>",
	"/Time Remaining",		"<control>R",mainwin_options_menu_callback,MAINWIN_OPT_TREMAINING,"/Time Elapsed",
	"/-",				NULL,NULL,0,"<Separator>",
	"/Always On Top",		"<control>A",mainwin_options_menu_callback,MAINWIN_OPT_ALWAYS,"<ToggleItem>",
	"/WindowShade Mode",		"<control>W",mainwin_options_menu_callback,MAINWIN_OPT_WS,"<ToggleItem>",
	"/Playlist WindowShade Mode",	"<control><shift>W",mainwin_options_menu_callback,MAINWIN_OPT_PWS,"<ToggleItem>",
	"/DoubleSize",			"<control>D",mainwin_options_menu_callback,MAINWIN_OPT_DOUBLESIZE,"<ToggleItem>",
	"/Easy Move",			"<control>E",mainwin_options_menu_callback,MAINWIN_OPT_EASY_MOVE,"<ToggleItem>",
};

#define MAINWIN_SONGNAME_MENU_ENTRIES 4

void mainwin_songname_menu_callback(gpointer cb_data,guint action,GtkWidget *w);

enum {MAINWIN_SONGNAME_FILEINFO,MAINWIN_SONGNAME_JTF,MAINWIN_SONGNAME_JTT,MAINWIN_SONGNAME_SCROLL};

GtkItemFactoryEntry mainwin_songname_menu_entries[]=
{
	"/File Info",	"<alt>3",mainwin_songname_menu_callback,MAINWIN_SONGNAME_FILEINFO,"<Item>",
	"/Jump To File","J",mainwin_songname_menu_callback,MAINWIN_SONGNAME_JTF,"<Item>",
	"/Jump To Time","<control>J",mainwin_songname_menu_callback,MAINWIN_SONGNAME_JTT,"<Item>",
	"/Autoscroll Songname",NULL,mainwin_songname_menu_callback,MAINWIN_SONGNAME_SCROLL,"<ToggleItem>",
};
	
#define MAINWIN_VIS_MENU_ENTRIES 37

void mainwin_vis_menu_callback(gpointer cb_data,guint action,GtkWidget *w);	
		
enum
{
	MAINWIN_VIS_ANALYZER,MAINWIN_VIS_SCOPE,MAINWIN_VIS_OFF,
	MAINWIN_VIS_ANALYZER_NORMAL,MAINWIN_VIS_ANALYZER_FIRE,MAINWIN_VIS_ANALYZER_VLINES,
	MAINWIN_VIS_ANALYZER_LINES,MAINWIN_VIS_ANALYZER_BARS,MAINWIN_VIS_ANALYZER_PEAKS,
	MAINWIN_VIS_SCOPE_DOT,MAINWIN_VIS_SCOPE_LINE,MAINWIN_VIS_SCOPE_SOLID,
	MAINWIN_VIS_VU_NORMAL,MAINWIN_VIS_VU_SMOOTH,
	MAINWIN_VIS_REFRESH_FULL,MAINWIN_VIS_REFRESH_HALF,MAINWIN_VIS_REFRESH_QUARTER,MAINWIN_VIS_REFRESH_EIGTH,
	MAINWIN_VIS_AFALLOFF_SLOWEST,MAINWIN_VIS_AFALLOFF_SLOW,MAINWIN_VIS_AFALLOFF_MEDIUM,MAINWIN_VIS_AFALLOFF_FAST,MAINWIN_VIS_AFALLOFF_FASTEST,
	MAINWIN_VIS_PFALLOFF_SLOWEST,MAINWIN_VIS_PFALLOFF_SLOW,MAINWIN_VIS_PFALLOFF_MEDIUM,MAINWIN_VIS_PFALLOFF_FAST,MAINWIN_VIS_PFALLOFF_FASTEST		
};
			
	
GtkItemFactoryEntry mainwin_vis_menu_entries[]=
{
	"/Visualization Mode",NULL,NULL,0,"<Branch>",
	"/Visualization Mode/Analyzer",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER,"<RadioItem>",
	"/Visualization Mode/Scope",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_SCOPE,"/Visualization Mode/Analyzer",
	"/Visualization Mode/Off",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_OFF,"/Visualization Mode/Analyzer",
	"/Analyzer Mode",NULL,NULL,0,"<Branch>",
	"/Analyzer Mode/Normal",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_NORMAL,"<RadioItem>",
	"/Analyzer Mode/Fire",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_FIRE,"/Analyzer Mode/Normal",
	"/Analyzer Mode/Vertical Lines",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_VLINES,"/Analyzer Mode/Normal",
	"/Analyzer Mode/-",NULL,NULL,0,"<Separator>",
	"/Analyzer Mode/Lines",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_LINES,"<RadioItem>",
	"/Analyzer Mode/Bars",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_BARS,"/Analyzer Mode/Lines",
	"/Analyzer Mode/-",NULL,NULL,0,"<Separator>",
	"/Analyzer Mode/Peaks",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_ANALYZER_PEAKS,"<ToggleItem>",
	"/Scope Mode",NULL,NULL,0,"<Branch>",
	"/Scope Mode/Dot Scope",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_SCOPE_DOT,"<RadioItem>",
	"/Scope Mode/Line Scope",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_SCOPE_LINE,"/Scope Mode/Dot Scope",
	"/Scope Mode/Solid Scope",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_SCOPE_SOLID,"/Scope Mode/Dot Scope",
	"/WindowShade VU Mode",NULL,NULL,0,"<Branch>",
	"/WindowShade VU Mode/Normal",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_VU_NORMAL,"<RadioItem>",
	"/WindowShade VU Mode/Smooth",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_VU_SMOOTH,"/WindowShade VU Mode/Normal",
	"/Refresh Rate",NULL,NULL,0,"<Branch>",
	"/Refresh Rate/Full (~50 fps)",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_REFRESH_FULL,"<RadioItem>",
	"/Refresh Rate/Half (~25 fps)",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_REFRESH_HALF,"/Refresh Rate/Full (~50 fps)",
	"/Refresh Rate/Quarter (~13 fps)",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_REFRESH_QUARTER,"/Refresh Rate/Full (~50 fps)",
	"/Refresh Rate/Eigth (~6 fps)",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_REFRESH_EIGTH,"/Refresh Rate/Full (~50 fps)",
	"/Analyzer Falloff",NULL,NULL,0,"<Branch>",
	"/Analyzer Falloff/Slowest",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_AFALLOFF_SLOWEST,"<RadioItem>",
	"/Analyzer Falloff/Slow",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_AFALLOFF_SLOW,"/Analyzer Falloff/Slowest",
	"/Analyzer Falloff/Medium",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_AFALLOFF_MEDIUM,"/Analyzer Falloff/Slowest",
	"/Analyzer Falloff/Fast",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_AFALLOFF_FAST,"/Analyzer Falloff/Slowest",
	"/Analyzer Falloff/Fastest",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_AFALLOFF_FASTEST,"/Analyzer Falloff/Slowest",
	"/Peaks Falloff",NULL,NULL,0,"<Branch>",
	"/Peaks Falloff/Slowest",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_PFALLOFF_SLOWEST,"<RadioItem>",
	"/Peaks Falloff/Slow",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_PFALLOFF_SLOW,"/Peaks Falloff/Slowest",
	"/Peaks Falloff/Medium",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_PFALLOFF_MEDIUM,"/Peaks Falloff/Slowest",
	"/Peaks Falloff/Fast",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_PFALLOFF_FAST,"/Peaks Falloff/Slowest",
	"/Peaks Falloff/Fastest",NULL,mainwin_vis_menu_callback,MAINWIN_VIS_PFALLOFF_FASTEST,"/Peaks Falloff/Slowest"
};

/*
 * If you change the menu above change these defines also
 */

#define MAINWIN_VIS_MENU_VIS_MODE		1
#define MAINWIN_VIS_MENU_NUM_VIS_MODE		3
#define MAINWIN_VIS_MENU_ANALYZER_MODE		5
#define MAINWIN_VIS_MENU_NUM_ANALYZER_MODE	3
#define MAINWIN_VIS_MENU_ANALYZER_TYPE	    	9
#define MAINWIN_VIS_MENU_NUM_ANALYZER_TYPE  	2
#define MAINWIN_VIS_MENU_ANALYZER_PEAKS		12
#define MAINWIN_VIS_MENU_SCOPE_MODE		14
#define MAINWIN_VIS_MENU_NUM_SCOPE_MODE		3
#define MAINWIN_VIS_MENU_WSHADEVU_MODE		18
#define MAINWIN_VIS_MENU_NUM_WSHADEVU_MODE	2
#define MAINWIN_VIS_MENU_REFRESH_RATE		21
#define MAINWIN_VIS_MENU_NUM_REFRESH_RATE	4
#define MAINWIN_VIS_MENU_AFALLOFF		26
#define MAINWIN_VIS_MENU_NUM_AFALLOFF		5
#define MAINWIN_VIS_MENU_PFALLOFF		32
#define MAINWIN_VIS_MENU_NUM_PFALLOFF		5

enum {MAINWIN_GENERAL_ABOUT,MAINWIN_GENERAL_PLAYFILE,
	MAINWIN_GENERAL_PLAYLOCATION,MAINWIN_GENERAL_FILEINFO,
	MAINWIN_GENERAL_SHOWMWIN,MAINWIN_GENERAL_SHOWPLWIN,
	MAINWIN_GENERAL_SHOWEQWIN,MAINWIN_GENERAL_PREV,MAINWIN_GENERAL_PLAY,
	MAINWIN_GENERAL_PAUSE,MAINWIN_GENERAL_STOP,MAINWIN_GENERAL_NEXT,
	MAINWIN_GENERAL_STOPFADE,MAINWIN_GENERAL_BACK5SEC,
	MAINWIN_GENERAL_FWD5SEC,MAINWIN_GENERAL_START,MAINWIN_GENERAL_BACK10,
	MAINWIN_GENERAL_FWD10,MAINWIN_GENERAL_JTT,MAINWIN_GENERAL_JTF,
	MAINWIN_GENERAL_EXIT};

#define MAINWIN_GENERAL_MENU_ENTRIES 28

void mainwin_general_menu_callback(gpointer cb_data,guint action,GtkWidget *w);

GtkItemFactoryEntry mainwin_general_menu_entries[]=
{
	"/About X11Amp",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_ABOUT,"<Item>",
	"/-",NULL,NULL,0,"<Separator>",
	"/Play File","L",mainwin_general_menu_callback,MAINWIN_GENERAL_PLAYFILE,"<Item>",
	"/Play Location","<control>L",mainwin_general_menu_callback,MAINWIN_GENERAL_PLAYLOCATION,"<Item>",
	"/View File Info","<alt>3",mainwin_general_menu_callback,MAINWIN_GENERAL_FILEINFO,"<Item>",
	"/-",NULL,NULL,0,"<Separator>",
/*	"/Main Window","<alt>W",mainwin_general_menu_callback,MAINWIN_GENERAL_SHOWMWIN,"<ToggleItem>", */
	"/Playlist Editor","<alt>E",mainwin_general_menu_callback,MAINWIN_GENERAL_SHOWPLWIN,"<ToggleItem>",
	"/Graphical EQ","<alt>G",mainwin_general_menu_callback,MAINWIN_GENERAL_SHOWEQWIN,"<ToggleItem>",
	"/-",NULL,NULL,0,"<Separator>",
	"/Options",NULL,NULL,0,"<Item>",
	"/Playback",NULL,NULL,0,"<Branch>",
	"/Playback/Previous","Z",mainwin_general_menu_callback,MAINWIN_GENERAL_PREV,"<Item>",
	"/Playback/Play","X",mainwin_general_menu_callback,MAINWIN_GENERAL_PLAY,"<Item>",
	"/Playback/Pause","C",mainwin_general_menu_callback,MAINWIN_GENERAL_PAUSE,"<Item>",
	"/Playback/Stop","V",mainwin_general_menu_callback,MAINWIN_GENERAL_STOP,"<Item>",
	"/Playback/Next","B",mainwin_general_menu_callback,MAINWIN_GENERAL_NEXT,"<Item>",
	"/Playback/-",NULL,NULL,0,"<Separator>",
/*	"/Playback/Stop with Fadeout","<Shift>V",mainwin_general_menu_callback,MAINWIN_GENERAL_STOPFADE,"<Item>", */
	"/Playback/Back 5 Seconds",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_BACK5SEC,"<Item>",
	"/Playback/Fwd 5 Seconds",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_FWD5SEC,"<Item>",
	"/Playback/Start of List","<control>Z",mainwin_general_menu_callback,MAINWIN_GENERAL_START,"<Item>",
	"/Playback/10 Tracks Back",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_BACK10,"<Item>",
	"/Playback/10 Tracks Fwd",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_FWD10,"<Item>",
	"/Playback/-",NULL,NULL,0,"<Separator>",
	"/Playback/Jump to Time","<control>J",mainwin_general_menu_callback,MAINWIN_GENERAL_JTT,"<Item>",
	"/Playback/Jump to File","J",mainwin_general_menu_callback,MAINWIN_GENERAL_JTF,"<Item>",
	"/Visualization",NULL,NULL,0,"<Item>",
	"/-",NULL,NULL,0,"<Separator>",
	"/Exit",NULL,mainwin_general_menu_callback,MAINWIN_GENERAL_EXIT,"<Item>"
};

static void read_config(void)
{
	ConfigFile *cfgfile;
	gchar *tmp,*filename,eqtext[18];
	gint i,tmpint;
	
	memset(&cfg,0,sizeof(Config));
	cfg.outputplugin=g_strdup("");
	cfg.effectplugin=g_strdup("");
	cfg.autoscroll=TRUE;
	cfg.player_x=20;
	cfg.player_y=20;
	cfg.always_on_top=FALSE;
	cfg.always_show_cb=TRUE;
	cfg.convert_underscore=TRUE;
	cfg.convert_twenty=TRUE;
	cfg.show_numbers_in_pl=TRUE;
	cfg.snap_windows=TRUE;
	cfg.save_window_position=TRUE;
	cfg.dim_titlebar=TRUE;
	cfg.focused_for_state_ctl=TRUE;
	cfg.open_rev_order=FALSE;
	cfg.get_info_on_load=FALSE;
	cfg.get_info_on_demand=TRUE;
	cfg.eq_doublesize_linked=TRUE;
	cfg.no_playlist_advance=FALSE;
	
	cfg.playlist_x=295;
	cfg.playlist_y=20;
	cfg.playlist_width=300;
	cfg.playlist_height=232;
	
	cfg.filesel_path=NULL;
	
	cfg.equalizer_x=20;
	cfg.equalizer_y=136;
	
	cfg.snap_distance=10;
	
	cfg.vis_type=VIS_ANALYZER;
	cfg.analyzer_mode=ANALYZER_FIRE;
	cfg.analyzer_type=ANALYZER_LINES;
	cfg.analyzer_peaks=TRUE;
	cfg.scope_mode=SCOPE_DOT;
	cfg.vu_mode = VU_SMOOTH;
	cfg.vu_mode=VU_NORMAL;
	cfg.vis_refresh=REFRESH_FULL;
	cfg.analyzer_falloff=FALLOFF_FAST;
	cfg.peaks_falloff=FALLOFF_FAST;
	cfg.disabled_iplugins=NULL;
	cfg.enabled_gplugins=NULL;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp",NULL);
	mkdir(filename,S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
	g_free(filename);
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/Skins",NULL);
	mkdir(filename,S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
	g_free(filename);
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	
	cfgfile=x11amp_cfg_open_file(filename);
	if(cfgfile)
	{
		x11amp_cfg_read_boolean(cfgfile,"x11amp","allow_multiple_instances",&cfg.allow_multiple_instances);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","always_show_cb",&cfg.always_show_cb);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","convert_underscore",&cfg.convert_underscore);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","convert_%20",&cfg.convert_twenty);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","show_numbers_in_pl",&cfg.show_numbers_in_pl);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","snap_windows",&cfg.snap_windows);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","save_window_positions",&cfg.save_window_position);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","dim_titlebar",&cfg.dim_titlebar);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","save_playlist_position",&cfg.save_playlist_position);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","focused_for_state_ctl",&cfg.focused_for_state_ctl);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","open_rev_order",&cfg.open_rev_order);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","get_info_on_load",&cfg.get_info_on_load);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","get_info_on_demand",&cfg.get_info_on_demand);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","eq_doublesize_linked",&cfg.eq_doublesize_linked);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","no_playlist_advance",&cfg.no_playlist_advance);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","sort_jump_to_file",&cfg.sort_jump_to_file);
		x11amp_cfg_read_int(cfgfile,"x11amp","player_x",&cfg.player_x);
		x11amp_cfg_read_int(cfgfile,"x11amp","player_y",&cfg.player_y);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","player_shaded",&cfg.player_shaded);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","shuffle",&cfg.shuffle);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","repeat",&cfg.repeat);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","doublesize",&cfg.doublesize);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","autoscroll_songname",&cfg.autoscroll);
		x11amp_cfg_read_int(cfgfile,"x11amp","timer_mode",&cfg.timer_mode);
		x11amp_cfg_read_int(cfgfile,"x11amp","vis_type",&cfg.vis_type);
		x11amp_cfg_read_int(cfgfile,"x11amp","analyzer_mode",&cfg.analyzer_mode);
		x11amp_cfg_read_int(cfgfile,"x11amp","analyzer_type",&cfg.analyzer_type);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","analyzer_peaks",&cfg.analyzer_peaks);
		x11amp_cfg_read_int(cfgfile,"x11amp","scope_mode",&cfg.scope_mode);
		x11amp_cfg_read_int(cfgfile,"x11amp","vu_mode",&cfg.vu_mode);
		x11amp_cfg_read_int(cfgfile,"x11amp","vis_refresh_rate",&cfg.vis_refresh);
		x11amp_cfg_read_int(cfgfile,"x11amp","analyzer_falloff",&cfg.analyzer_falloff);
		x11amp_cfg_read_int(cfgfile,"x11amp","peaks_falloff",&cfg.peaks_falloff);
		x11amp_cfg_read_int(cfgfile,"x11amp","playlist_x",&cfg.playlist_x);
		x11amp_cfg_read_int(cfgfile,"x11amp","playlist_y",&cfg.playlist_y);
		x11amp_cfg_read_int(cfgfile,"x11amp","playlist_width",&cfg.playlist_width);
		x11amp_cfg_read_int(cfgfile,"x11amp","playlist_height",&cfg.playlist_height);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","playlist_visible",&cfg.playlist_visible);
		if(!x11amp_cfg_read_string(cfgfile,"x11amp","playlist_font",&cfg.playlist_font))
			cfg.playlist_font=g_strdup("-*-helvetica-bold-r-*-*-10-*");
		x11amp_cfg_read_int(cfgfile,"x11amp","playlist_position",&cfg.playlist_position);
		x11amp_cfg_read_int(cfgfile,"x11amp","equalizer_x",&cfg.equalizer_x);	
		x11amp_cfg_read_int(cfgfile,"x11amp","equalizer_y",&cfg.equalizer_y);	
		x11amp_cfg_read_int(cfgfile,"x11amp","snap_distance",&cfg.snap_distance);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","equalizer_visible",&cfg.equalizer_visible);	
		x11amp_cfg_read_boolean(cfgfile,"x11amp","equalizer_active",&cfg.equalizer_active);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","equalizer_autoload",&cfg.equalizer_autoload);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","easy_move",&cfg.easy_move);
		x11amp_cfg_read_float(cfgfile,"x11amp","equalizer_preamp",&cfg.equalizer_preamp);	
		for(i=0;i<10;i++)
		{
			sprintf(eqtext,"equalizer_band%d",i);
			x11amp_cfg_read_float(cfgfile,"x11amp",eqtext,&cfg.equalizer_bands[i]);
		}
		x11amp_cfg_read_string(cfgfile,"x11amp","skin",&cfg.skin);
		x11amp_cfg_read_string(cfgfile,"x11amp","output_plugin",&cfg.outputplugin);
		x11amp_cfg_read_string(cfgfile,"x11amp","effect_plugin",&cfg.effectplugin);
		x11amp_cfg_read_string(cfgfile,"x11amp","enabled_gplugins",&cfg.enabled_gplugins);
		x11amp_cfg_read_string(cfgfile,"x11amp","filesel_path",&cfg.filesel_path);
		x11amp_cfg_read_string(cfgfile,"x11amp","disabled_iplugins",&cfg.disabled_iplugins);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","use_eplugins",&cfg.use_eplugins);
		x11amp_cfg_read_boolean(cfgfile,"x11amp","always_on_top",&cfg.always_on_top);
		x11amp_cfg_free(cfgfile);
	}
	else
	{
		cfg.playlist_font=g_strdup("-*-helvetica-bold-r-*-*-10-*");
	}
	g_free(filename);
}

static void save_config(void)
{
	GList *d_iplist;
	gchar *temp;
	gchar *filename,*str;
	int i;
	ConfigFile *cfgfile;

	if(cfg.disabled_iplugins)
		g_free(cfg.disabled_iplugins);
	if(disabled_iplugins&&(g_list_length(disabled_iplugins)>0))
	{
		d_iplist=disabled_iplugins;
		cfg.disabled_iplugins=g_strdup(g_basename(((InputPlugin *)d_iplist->data)->filename));
		d_iplist=d_iplist->next;
		while(d_iplist != NULL)
		{
			temp=cfg.disabled_iplugins;
			cfg.disabled_iplugins=g_strconcat(temp,",",g_basename(((InputPlugin *)d_iplist->data)->filename),NULL);
			g_free(temp);
			d_iplist=d_iplist->next;
		}
	}
	else
		cfg.disabled_iplugins=g_strdup("");
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	cfgfile=x11amp_cfg_open_file(filename);
	if(!cfgfile)
		cfgfile=x11amp_cfg_new();
	x11amp_cfg_write_boolean(cfgfile,"x11amp","allow_multiple_instances",cfg.allow_multiple_instances);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","always_show_cb",cfg.always_show_cb);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","convert_underscore",cfg.convert_underscore);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","convert_%20",cfg.convert_twenty);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","show_numbers_in_pl",cfg.show_numbers_in_pl);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","snap_windows",cfg.snap_windows);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","save_window_positions",cfg.save_window_position);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","dim_titlebar",cfg.dim_titlebar);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","save_playlist_position",cfg.save_playlist_position);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","focused_for_state_ctl",cfg.focused_for_state_ctl);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","open_rev_order",cfg.open_rev_order);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","get_info_on_load",cfg.get_info_on_load);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","get_info_on_demand",cfg.get_info_on_demand);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","eq_doublesize_linked",cfg.eq_doublesize_linked);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","no_playlist_advance",cfg.no_playlist_advance);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","sort_jump_to_file",cfg.sort_jump_to_file);
	x11amp_cfg_write_int(cfgfile,"x11amp","player_x",cfg.player_x);
	x11amp_cfg_write_int(cfgfile,"x11amp","player_y",cfg.player_y);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","player_shaded",cfg.player_shaded);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","shuffle",mainwin_shuffle->tb_selected);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","repeat",mainwin_repeat->tb_selected);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","doublesize",cfg.doublesize);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","autoscroll_songname",cfg.autoscroll);
	x11amp_cfg_write_int(cfgfile,"x11amp","timer_mode",cfg.timer_mode);
	x11amp_cfg_write_int(cfgfile,"x11amp","vis_type",cfg.vis_type);
	x11amp_cfg_write_int(cfgfile,"x11amp","analyzer_mode",cfg.analyzer_mode);
	x11amp_cfg_write_int(cfgfile,"x11amp","analyzer_type",cfg.analyzer_type);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","analyzer_peaks",cfg.analyzer_peaks);
	x11amp_cfg_write_int(cfgfile,"x11amp","scope_mode",cfg.scope_mode);
	x11amp_cfg_write_int(cfgfile,"x11amp","vu_mode",cfg.vu_mode);
	x11amp_cfg_write_int(cfgfile,"x11amp","vis_refresh_rate",cfg.vis_refresh);
	x11amp_cfg_write_int(cfgfile,"x11amp","analyzer_falloff",cfg.analyzer_falloff);
	x11amp_cfg_write_int(cfgfile,"x11amp","peaks_falloff",cfg.peaks_falloff);
	x11amp_cfg_write_int(cfgfile,"x11amp","playlist_x",cfg.playlist_x);
	x11amp_cfg_write_int(cfgfile,"x11amp","playlist_y",cfg.playlist_y);
	x11amp_cfg_write_int(cfgfile,"x11amp","playlist_width",cfg.playlist_width);
	x11amp_cfg_write_int(cfgfile,"x11amp","playlist_height",cfg.playlist_height);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","playlist_visible",cfg.playlist_visible);
	x11amp_cfg_write_string(cfgfile,"x11amp","playlist_font",cfg.playlist_font);
	g_free(cfg.playlist_font);
	x11amp_cfg_write_int(cfgfile,"x11amp","playlist_position",get_playlist_position());
	x11amp_cfg_write_int(cfgfile,"x11amp","equalizer_x",cfg.equalizer_x);
	x11amp_cfg_write_int(cfgfile,"x11amp","equalizer_y",cfg.equalizer_y);
	x11amp_cfg_write_int(cfgfile,"x11amp","snap_distance",cfg.snap_distance);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","equalizer_visible",cfg.equalizer_visible);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","equalizer_active",cfg.equalizer_active);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","equalizer_autoload",cfg.equalizer_autoload);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","easy_move",cfg.easy_move);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","use_eplugins",cfg.use_eplugins);
	x11amp_cfg_write_boolean(cfgfile,"x11amp","always_on_top",cfg.always_on_top);
	x11amp_cfg_write_float(cfgfile,"x11amp","equalizer_preamp",cfg.equalizer_preamp);
	for(i=0;i<10;i++)
	{
		str=g_strdup_printf("equalizer_band%d",i);
		x11amp_cfg_write_float(cfgfile,"x11amp",str,cfg.equalizer_bands[i]);
		g_free(str);
	}
	if(skin->path)
	{
		x11amp_cfg_write_string(cfgfile,"x11amp","skin",skin->path);
		g_free(skin->path);
	}
	else
		x11amp_cfg_remove_key(cfgfile,"x11amp","skin");
	if(cfg.skin) g_free(cfg.skin);
	if(get_current_output_plugin())
		x11amp_cfg_write_string(cfgfile,"x11amp","output_plugin",get_current_output_plugin()->filename);
	else
		x11amp_cfg_remove_key(cfgfile,"x11amp","output_plugin");
	if(cfg.outputplugin) g_free(cfg.outputplugin);
	if(get_current_effect_plugin())
		x11amp_cfg_write_string(cfgfile,"x11amp","effect_plugin",get_current_effect_plugin()->filename);
	else
		x11amp_cfg_remove_key(cfgfile,"x11amp","effect_plugin");
	if(cfg.effectplugin) g_free(cfg.effectplugin);

	str=general_stringify_enabled_list();
	if(str)
	{
		x11amp_cfg_write_string(cfgfile,"x11amp","enabled_gplugins",str);
		g_free(str);
	}
        else
		x11amp_cfg_remove_key(cfgfile,"x11amp","enabled_gplugins");
	x11amp_cfg_write_string(cfgfile,"x11amp","disabled_iplugins",cfg.disabled_iplugins);
	g_free(cfg.disabled_iplugins);
	if(cfg.filesel_path)
	{
		x11amp_cfg_write_string(cfgfile,"x11amp","filesel_path",cfg.filesel_path);
		g_free(cfg.filesel_path);
	}
	x11amp_cfg_write_file(cfgfile,filename);
	x11amp_cfg_free(cfgfile);
	
	g_free(filename);
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/x11amp.m3u",NULL);
	playlist_save(filename);
	g_free(filename);
}

void set_always(gboolean always)
{
	cfg.always_on_top=always;
	hint_set_always(always);
}

void set_doublesize(gboolean ds)
{
	gint ox,oy,height;
	
	cfg.doublesize=ds;
	
	if(cfg.player_shaded)
		height=14;
	else
		height=116;
	
	if(cfg.doublesize)
	{
		gdk_window_set_hints(mainwin->window,0,0,550,height*2,550,height*2,GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(mainwin->window,550,height*2);
		gdk_window_set_back_pixmap(mainwin->window,mainwin_bg_dblsize,0);
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.player_shaded ? SKIN_MASK_SHADE_DS : SKIN_MASK_MAIN_DS),0,0);
		draw_main_window(TRUE);
		if(is_docked(cfg.player_x,cfg.player_y,275,height,cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height))
		{
			ox=(cfg.playlist_x-cfg.player_x);
			oy=(cfg.playlist_y-cfg.player_y);
			if(ox>0) ox*=2;
			if(oy>0) oy*=2;
			if(ox>0||oy>0)
				playlistwin_move(cfg.player_x+ox,cfg.player_y+oy);
		}
		if(is_docked(cfg.player_x,cfg.player_y,275,height,cfg.equalizer_x,cfg.equalizer_y,275,height))
		{
			ox=(cfg.equalizer_x-cfg.player_x);
			oy=(cfg.equalizer_y-cfg.player_y);
			if(ox>0) ox*=2;
			if(oy>0) oy*=2;
			if(ox>0||oy>0)
				equalizerwin_move(cfg.player_x+ox,cfg.player_y+oy);
		}
		
	}
	else
	{
		gdk_window_set_hints(mainwin->window,0,0,275,height,275,height,GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(mainwin->window,275,height);
		gdk_window_set_back_pixmap(mainwin->window,mainwin_bg,0);
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.player_shaded ? SKIN_MASK_SHADE : SKIN_MASK_MAIN),0,0);
		gdk_window_clear(mainwin->window);
		if(is_docked(cfg.player_x,cfg.player_y,550,height*2,cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height))
		{
			ox=(cfg.playlist_x-cfg.player_x);
			oy=(cfg.playlist_y-cfg.player_y);
			if(ox>0) ox/=2;
			if(oy>0) oy/=2;
			if(ox>0||oy>0)
				playlistwin_move(cfg.player_x+ox,cfg.player_y+oy);
		}
		if(is_docked(cfg.player_x,cfg.player_y,550,height*2,cfg.equalizer_x,cfg.equalizer_y,550,height*2))
		{
			ox=(cfg.equalizer_x-cfg.player_x);
			oy=(cfg.equalizer_y-cfg.player_y);
			if(ox>0) ox/=2;
			if(oy>0) oy/=2;
			if(ox>0||oy>0)
				equalizerwin_move(cfg.player_x+ox,cfg.player_y+oy);
		}
	}
	if(cfg.eq_doublesize_linked)
		equalizerwin_set_doublesize(ds);
}

void mainwin_set_shade(gboolean shaded)
{
	gint dy,oy;
	gboolean old_shaded;
	
	old_shaded = cfg.player_shaded;
	cfg.player_shaded = shaded;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/WindowShade Mode"))->active=cfg.player_shaded;
	
	if(shaded)
	{
		gdk_window_set_hints(mainwin->window,0,0,275*(cfg.doublesize+1),14*(cfg.doublesize+1),275*(cfg.doublesize+1),14*(cfg.doublesize+1),GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(mainwin->window,275*(cfg.doublesize+1),14*(cfg.doublesize+1));
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.doublesize ? SKIN_MASK_SHADE_DS : SKIN_MASK_SHADE),0,0);
		
		show_widget(mainwin_svis);
		vis_clear_data(mainwin_vis);
		
		show_widget(mainwin_srew);
		show_widget(mainwin_splay);
		show_widget(mainwin_spause);
		show_widget(mainwin_sstop);
		show_widget(mainwin_sfwd);
		show_widget(mainwin_seject);
		
		show_widget(mainwin_stime_min);
		show_widget(mainwin_stime_sec);
		
		if(get_input_playing() && playlist_get_current_length() != -1)
			show_widget(mainwin_sposition);

		mainwin_shade->pb_ny = mainwin_shade->pb_py = 27;
		
		draw_main_window(TRUE);
		dy = 14 - 116;
	}
	else
	{
		gdk_window_set_hints(mainwin->window,0,0,275*(cfg.doublesize+1),116*(cfg.doublesize+1),275*(cfg.doublesize+1),14*(cfg.doublesize+1),GDK_HINT_MIN_SIZE|GDK_HINT_MAX_SIZE);
		gdk_window_resize(mainwin->window,275*(cfg.doublesize+1),116*(cfg.doublesize+1));
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.doublesize ? SKIN_MASK_MAIN_DS : SKIN_MASK_MAIN),0,0);
		
		hide_widget(mainwin_svis);
		svis_clear_data(mainwin_svis);
		
		hide_widget(mainwin_srew);
		hide_widget(mainwin_splay);
		hide_widget(mainwin_spause);
		hide_widget(mainwin_sstop);
		hide_widget(mainwin_sfwd);
		hide_widget(mainwin_seject);
		
		hide_widget(mainwin_stime_min);
		hide_widget(mainwin_stime_sec);
		hide_widget(mainwin_sposition);

		mainwin_shade->pb_ny = mainwin_shade->pb_py = 18;
		
		draw_main_window(TRUE);
		dy = 116 - 14;
	}
	
	if(cfg.doublesize)
		dy *= 2;
	
	if(is_docked(cfg.player_x,cfg.player_y,275,(old_shaded ? 14 : 116) * (cfg.doublesize + 1),cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height))
	{
		if(cfg.playlist_y-cfg.player_y > 0)
			playlistwin_move(cfg.playlist_x,cfg.player_y+cfg.playlist_y-cfg.player_y+dy);
	}
	if(is_docked(cfg.player_x,cfg.player_y,275,(old_shaded ? 14 : 116) * (cfg.doublesize + 1),cfg.equalizer_x,cfg.equalizer_y,275 * ((cfg.doublesize&&cfg.eq_doublesize_linked) + 1),116 * ((cfg.doublesize&&cfg.eq_doublesize_linked) + 1)))
	{
		if(cfg.equalizer_y-cfg.player_y > 0)
			equalizerwin_move(cfg.equalizer_x,cfg.player_y+cfg.equalizer_y-cfg.player_y+dy);
	}
}

void mainwin_vis_set_refresh(RefreshRate rate)
{
	cfg.vis_refresh=rate;
}

void mainwin_vis_set_afalloff(FalloffSpeed speed)
{
	cfg.analyzer_falloff=speed;
}

void mainwin_vis_set_pfalloff(FalloffSpeed speed)
{
	cfg.peaks_falloff=speed;
}

void mainwin_vis_set_analyzer_mode(AnalyzerMode mode)
{
	cfg.analyzer_mode=mode;
}



void mainwin_vis_set_analyzer_type(AnalyzerType mode)
{
	cfg.analyzer_type=mode;
}

void mainwin_vis_clear(void)
{
	Widget *w;
	
	if(cfg.player_shaded)
		w = &mainwin_svis->vs_widget;
	else
		w = &mainwin_vis->vs_widget;
	
	if(!cfg.doublesize)
		gdk_window_clear_area(mainwin->window,w->x,w->y,w->width,w->height);
	else
		gdk_window_clear_area(mainwin->window,w->x<<1,w->y<<1,w->width<<1,w->height<<1);
}

void mainwin_vis_set_type(VisType mode)
{
	gint i;
	
	cfg.vis_type=mode;
	
	if(mode==VIS_OFF)
		mainwin_vis_clear();
	if(mode==VIS_ANALYZER)
	{
		vis_clear_data(mainwin_vis);
		svis_clear_data(mainwin_svis);
	}


	for(i=0;i<MAINWIN_VIS_MENU_NUM_VIS_MODE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_VIS_MODE+i].path))->active=(cfg.vis_type==i)?TRUE:FALSE;

}



gboolean is_docked(gint x,gint y,gint w,gint h,gint ox,gint oy,gint ow,gint oh)
{
	if((x==ox||x==ox+ow||x+w==ox||x+w==ox+ow)&&oy>=y-oh&&oy<=y+h) return TRUE;
	if((y==oy||y==oy+oh||y+h==oy||y+h==oy+oh)&&ox>=x-ow&&ox<=x+w) return TRUE;
	return FALSE;
}

void dock(gint *x,gint *y,gint w,gint h,gint ox,gint oy,gint ow,gint oh)
{
	gint snapd=cfg.snap_distance;
	
	if(!cfg.snap_windows)
		return;
	if(*x+w>ox-snapd && *x+w<ox+snapd && *y>oy-h && *y<oy+oh)
	{
		*x=ox-w;
		if(*y>oy-snapd && *y<oy+snapd) *y=oy;
		if(*y+h>oy+oh-snapd && *y+h<oy+oh+snapd) *y=oy+oh-h;
	}
	
	if(*x>ox+ow-snapd && *x<ox+ow+snapd && *y>oy-h && *y<oy+oh) 
	{
		*x=ox+ow;
		if(*y>oy-snapd && *y<oy+snapd) *y=oy;
		if(*y+h>oy+oh-snapd && *y+h<oy+oh+snapd) *y=oy+oh-h;
	}
	if(*y+h>oy-snapd && *y+h<oy+snapd && *x>ox-w && *x<ox+ow) 
	{
		*y=oy-h;
		if(*x>ox-snapd && *x<ox+snapd) *x=ox;
		if(*x+w>ox+ow-snapd && *x+w<ox+ow+snapd) *x=ox+ow-w;
	}
	if(*y>oy+oh-snapd && *y<oy+oh+snapd && *x>ox-w && *x<ox+ow) 
	{
		*y=oy+oh;
		if(*x>ox-snapd && *x<ox+snapd) *x=ox;
		if(*x+w>ox+ow-snapd && *x+w<ox+ow+snapd) *x=ox+ow-w;
	}
}

void mainwin_menubtn_cb(void)
{
	gtk_item_factory_popup(mainwin_general_menu,cfg.player_x+6*(1+cfg.doublesize),cfg.player_y+14*(1+cfg.doublesize),1,GDK_CURRENT_TIME);
}

void mainwin_minimize_cb(void)
{
	Window xwindow;

	if (!mainwin->window) return;

	xwindow = GDK_WINDOW_XWINDOW(mainwin->window);
	XIconifyWindow(GDK_DISPLAY(), xwindow, DefaultScreen(GDK_DISPLAY()));
}


void mainwin_shade_cb(void)
{
	mainwin_set_shade(!cfg.player_shaded);
}

void mainwin_quit_cb(void)
{
	gtk_timeout_remove(mainwin_timeout_tag);
	save_config();
	cleanup_ctrlsocket();
	cleanup_skins();
	cleanup_plugins();
	playlist_clear();
	gtk_main_quit();
}

void draw_mainwin_titlebar(int focus)
{
	GdkImage *img,*img2;
	if(focus || !cfg.dim_titlebar)
		gdk_draw_pixmap(mainwin_bg,mainwin_gc,get_skin_pixmap(SKIN_TITLEBAR),27,29*cfg.player_shaded,0,0,275,14);
	else
		gdk_draw_pixmap(mainwin_bg,mainwin_gc,get_skin_pixmap(SKIN_TITLEBAR),27,(27*cfg.player_shaded)+15,0,0,275,14);
}
	
void draw_main_window(gboolean force)
{
	GdkImage *img,*img2;
	GList *wl;
	Widget *w;
	gboolean redraw;
	
	
	if(force)
	{
		gdk_draw_pixmap(mainwin_bg,mainwin_gc,get_skin_pixmap(SKIN_MAIN),0,0,0,0,275,cfg.player_shaded ? 14 : 116);
		draw_mainwin_titlebar(mainwin_focus);
		draw_widget_list(mainwin_wlist,&redraw,TRUE);
	}
	else
		draw_widget_list(mainwin_wlist,&redraw,FALSE);
	
	if(redraw||force)
	{
		
		if(force)
		{
			if(cfg.doublesize)
			{
				img=gdk_image_get(mainwin_bg,0,0,275,cfg.player_shaded ? 14 : 116);
				img2=create_dblsize_image(img);
				gdk_draw_image(mainwin_bg_dblsize,mainwin_gc,img2,0,0,0,0,550,cfg.player_shaded ? 28 : 232);
				gdk_image_destroy(img2);
				gdk_image_destroy(img);
			}
		}
		else
		{
			wl=mainwin_wlist;
			while(wl)
			{
				w=(Widget *)wl->data;
				if(w->redraw&&w->visible)
				{
					if(cfg.doublesize)
					{
						img=gdk_image_get(mainwin_bg,w->x,w->y,w->width,w->height);
						img2=create_dblsize_image(img);
						gdk_draw_image(mainwin_bg_dblsize,mainwin_gc,img2,0,0,w->x<<1,w->y<<1,w->width<<1,w->height<<1);
						gdk_image_destroy(img2);
						gdk_image_destroy(img);
						gdk_window_clear_area(mainwin->window,w->x<<1,w->y<<1,w->width<<1,w->height<<1);
					}
					else
						gdk_window_clear_area(mainwin->window,w->x,w->y,w->width,w->height);
					w->redraw=FALSE;
					
				}
				wl=wl->next;
			}
		}
		if(force) gdk_window_clear(mainwin->window);
		gdk_flush();			
	}
}

void mainwin_set_info_text(void)
{
	gchar *text;
	
	if(mainwin_info_text_locked)
		return;
	
	if(text=input_get_info_text())
	{
		textbox_set_text(mainwin_info,text);
	}
	else if(text=playlist_get_info_text())
	{
		textbox_set_text(mainwin_info,text);
		g_free(text);
	}
	else
	{
		text=g_strdup_printf("%s %s",PACKAGE,VERSION);
		textbox_set_text(mainwin_info,text);
		g_free(text);
	}
}

void mainwin_lock_info_text(gchar *text)
{
	mainwin_info_text_locked=TRUE;
	textbox_set_text(mainwin_info,text);
}

void mainwin_release_info_text(void)
{
	mainwin_info_text_locked=FALSE;
	mainwin_set_info_text();
}

void mainwin_set_song_info(int rate,int freq,int nch)
{
	gchar text[10];
	gchar *tmp,*title;
	bitrate=rate;
	frequency=freq;
	numchannels=nch;
	if(rate==0&&freq==0&&nch==0)
	{
		textbox_set_text(mainwin_rate_text,"   ");
		textbox_set_text(mainwin_freq_text,"  ");
		monostereo_set_num_channels(mainwin_monostereo,0);
		playstatus_set_status(mainwin_playstatus,STATUS_STOP);
		hide_widget(mainwin_minus_num);
		hide_widget(mainwin_10min_num);
		hide_widget(mainwin_min_num);
		hide_widget(mainwin_10sec_num);
		hide_widget(mainwin_sec_num);
		textbox_set_text(mainwin_stime_min,"   ");
		textbox_set_text(mainwin_stime_sec,"  ");
		hide_widget(mainwin_position);
		hide_widget(mainwin_sposition);
		playlistwin_hide_timer();
		draw_main_window(TRUE);
		gtk_window_set_title(GTK_WINDOW(mainwin),"X11Amp");
		return;
	}
	if(rate!=-1)
	{
		rate/=1000; 
		if(rate<1000)
		{
			sprintf(text,"%3d",rate);
			textbox_set_text(mainwin_rate_text,text);
		}
		else
		{
			rate/=100;
			sprintf(text,"%2dH",rate);
			textbox_set_text(mainwin_rate_text,text);
		}
	}
	else
		textbox_set_text(mainwin_rate_text,"VBR");
		
	sprintf(text,"%2d",freq);
	textbox_set_text(mainwin_freq_text,text);
	monostereo_set_num_channels(mainwin_monostereo,nch);
	
	show_widget(mainwin_minus_num);
	show_widget(mainwin_10min_num);
	show_widget(mainwin_min_num);
	show_widget(mainwin_10sec_num);
	show_widget(mainwin_sec_num);
	playstatus_set_status(mainwin_playstatus,STATUS_PLAY);
	if(playlist_get_current_length()!=-1)
	{
		if(cfg.player_shaded)
			show_widget(mainwin_sposition);
		show_widget(mainwin_position);
	}
	else
	{
		hide_widget(mainwin_position);
		hide_widget(mainwin_sposition);
		mainwin_force_redraw=TRUE;
	}
	mainwin_position->hs_pressed=FALSE;
	mainwin_sposition->hs_pressed=FALSE;
	if(tmp=playlist_get_info_text())
	{
		mainwin_title_text=g_strdup_printf("X11Amp - %s",tmp);
		
		g_free(tmp);
	}
}

void mainwin_release(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	gdk_pointer_ungrab(GDK_CURRENT_TIME);
	
	/*
	 *
	 * The gdk_flush() is just for making sure that the pointer really
	 * gets ungrabbed before calling any button callbacks
	 *
	 */ 
	
	gdk_flush();
	
	if(mainwin_moving)
	{
		mainwin_moving=FALSE;
	}
	if(mainwin_menurow->mr_doublesize_selected)
	{
		event->x/=2;
		event->y/=2;
	}
	handle_release_cb(mainwin_wlist,widget,event);
		
	draw_main_window(FALSE);

}

void mainwin_motion(GtkWidget *widget,GdkEventMotion *event,gpointer callback_data)
{
	XEvent ev;
	
	while(XCheckMaskEvent(GDK_DISPLAY(),ButtonMotionMask,&ev));
	
	if(cfg.doublesize)
	{
		event->x/=2;
		event->y/=2;
	}
	if(mainwin_moving)
	{
		gint mx,my,newx,newy,eqw,eqh,min_offsetx=0,min_offsety=0;
		gint sw,sh,w,h;
		GdkModifierType modmask;
		
		gdk_window_get_pointer(NULL, &mx, &my, &modmask);
		newx=mx-mainwin_move_x;
		newy=my-mainwin_move_y;
		sw=gdk_screen_width();
		sh=gdk_screen_height();
		gdk_window_get_size(mainwin->window,&w,&h);
		if(mainwin_move_playlist && cfg.playlist_visible)
		{
			if(cfg.playlist_x+cfg.playlist_width>cfg.player_x+w) w=cfg.playlist_x+cfg.playlist_width-cfg.player_x;
			if(cfg.playlist_y+cfg.playlist_height>cfg.player_y+h) h=cfg.playlist_y+cfg.playlist_height-cfg.player_y;
			if(cfg.playlist_x<cfg.player_x) min_offsetx=cfg.player_x-cfg.playlist_x;
			if(cfg.playlist_y<cfg.player_y) min_offsety=cfg.player_y-cfg.playlist_y;
		}
		if(mainwin_move_equalizer && cfg.equalizer_visible)
		{
			if(cfg.doublesize&&cfg.eq_doublesize_linked)
			{
				eqw=550;
				eqh=232;
			}
			else
			{
				eqw=275;
				eqh=116;
			}
			if(cfg.equalizer_x+eqw>cfg.player_x+w) w=cfg.equalizer_x+eqw-cfg.player_x;
			if(cfg.equalizer_y+eqh>cfg.player_y+h) h=cfg.equalizer_y+eqh-cfg.player_y;
			if(cfg.equalizer_x<cfg.player_x-min_offsetx) min_offsetx=cfg.player_x-cfg.equalizer_x;
			if(cfg.equalizer_y<cfg.player_y-min_offsety) min_offsety=cfg.player_y-cfg.equalizer_y;
		}
		
		if(cfg.snap_windows)
		{
			if(newx>min_offsetx-10&&newx<min_offsetx+10) newx=min_offsetx;
			if(newx+w>sw-10&&newx+w<sw+10) newx=sw-w;
			if(newy>min_offsety-10&&newy<min_offsety+10) newy=min_offsety;
			if(newy+h>sh-10&&newy+h<sh+10) newy=sh-h;
		}
		
		if(cfg.playlist_visible&&!mainwin_move_playlist) dock(&newx,&newy,w,h,cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height);
		if(cfg.equalizer_visible&&!mainwin_move_equalizer)
			if(cfg.doublesize&&cfg.eq_doublesize_linked)
				dock(&newx,&newy,w,h,cfg.equalizer_x,cfg.equalizer_y,550,232);
			else
				dock(&newx,&newy,w,h,cfg.equalizer_x,cfg.equalizer_y,275,116);
		if(mainwin_move_playlist) playlistwin_move((cfg.playlist_x-cfg.player_x)+newx,(cfg.playlist_y-cfg.player_y)+newy);
		if(mainwin_move_equalizer) equalizerwin_move((cfg.equalizer_x-cfg.player_x)+newx,(cfg.equalizer_y-cfg.player_y)+newy);
		cfg.player_x=newx;
		cfg.player_y=newy;
		gdk_window_move(mainwin->window,newx,newy);
	}
	else
	{
		handle_motion_cb(mainwin_wlist,widget,event);
		draw_main_window(FALSE);
	}
	gdk_flush();
	

}

static gboolean inside_sensitive_widgets(gint x, gint y)
{
	return(inside_widget(x,y,mainwin_menubtn)||inside_widget(x,y,mainwin_minimize)||
		inside_widget(x,y,mainwin_shade)||inside_widget(x,y,mainwin_close)||
		inside_widget(x,y,mainwin_rew)||inside_widget(x,y,mainwin_play)||
		inside_widget(x,y,mainwin_pause)||inside_widget(x,y,mainwin_stop)||
		inside_widget(x,y,mainwin_fwd)||inside_widget(x,y,mainwin_eject)||
		inside_widget(x,y,mainwin_shuffle)||inside_widget(x,y,mainwin_repeat)||
		inside_widget(x,y,mainwin_pl)||inside_widget(x,y,mainwin_eq)||
		inside_widget(x,y,mainwin_info)||inside_widget(x,y,mainwin_menurow)||
		inside_widget(x,y,mainwin_volume)||inside_widget(x,y,mainwin_balance)||
		(inside_widget(x,y,mainwin_position)&&((Widget *)mainwin_position)->visible)||
		inside_widget(x,y,mainwin_minus_num)||inside_widget(x,y,mainwin_10min_num)||
		inside_widget(x,y,mainwin_min_num)||inside_widget(x,y,mainwin_10sec_num)||
		inside_widget(x,y,mainwin_sec_num)||inside_widget(x,y,mainwin_vis)||
		inside_widget(x,y,mainwin_minimize)||inside_widget(x,y,mainwin_shade)||
		inside_widget(x,y,mainwin_close)||inside_widget(x,y,mainwin_menubtn)||
		inside_widget(x,y,mainwin_sposition)||inside_widget(x,y,mainwin_stime_min)||
		inside_widget(x,y,mainwin_stime_sec)||inside_widget(x,y,mainwin_srew)||
		inside_widget(x,y,mainwin_splay)||inside_widget(x,y,mainwin_spause)||
		inside_widget(x,y,mainwin_sstop)||inside_widget(x,y,mainwin_sfwd)||
		inside_widget(x,y,mainwin_seject) || inside_widget(x,y,mainwin_svis));
}
		
void mainwin_press(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	gint mx,my,w,h;
	gboolean grab=TRUE;
	
	mx=event->x;
	my=event->y;
	if(cfg.doublesize)
	{
		event->x/=2;
		event->y/=2;
	}

	if(event->button==1&&event->type == GDK_BUTTON_PRESS && !inside_sensitive_widgets(event->x,event->y)&&(cfg.easy_move || event->y<14))
	{
		gdk_window_raise(mainwin->window);
		equalizerwin_raise();
		playlistwin_raise();

		mainwin_moving=TRUE;
		mainwin_move_x=mx;
		mainwin_move_y=my;
		gdk_window_get_size(mainwin->window,&w,&h);
		if(is_docked(cfg.player_x,cfg.player_y,w,h,cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height))  mainwin_move_playlist=TRUE;
		else mainwin_move_playlist=FALSE;
		if(cfg.doublesize)
		{
			if(is_docked(cfg.player_x,cfg.player_y,w,h,cfg.equalizer_x,cfg.equalizer_y,550,cfg.player_shaded ? 28 : 232))  mainwin_move_equalizer=TRUE;
			else mainwin_move_equalizer=FALSE;
			if(mainwin_move_equalizer||mainwin_move_playlist)
			{
				if(is_docked(cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height,cfg.equalizer_x,cfg.equalizer_y,550,cfg.player_shaded ? 28 : 232))
				{
					mainwin_move_equalizer=TRUE;
					mainwin_move_playlist=TRUE;
				}
			}
		}
		else
		{
			if(is_docked(cfg.player_x,cfg.player_y,w,h,cfg.equalizer_x,cfg.equalizer_y,275,cfg.player_shaded ? 14 : 116))  mainwin_move_equalizer=TRUE;
			else mainwin_move_equalizer=FALSE;	
			if(mainwin_move_equalizer||mainwin_move_playlist)
			{
				if(is_docked(cfg.playlist_x,cfg.playlist_y,cfg.playlist_width,cfg.playlist_height,cfg.equalizer_x,cfg.equalizer_y,275,cfg.player_shaded ? 14 : 116))
				{
					mainwin_move_equalizer=TRUE;
					mainwin_move_playlist=TRUE;
				}
			}

		}		
	}
	else if(event->button == 1 && event->type == GDK_2BUTTON_PRESS && event->y < 14)
		mainwin_set_shade(!cfg.player_shaded);
	else	
	{
		handle_press_cb(mainwin_wlist,widget,event);
		draw_main_window(FALSE);
	}
        if((event->button==1)&&event->type != GDK_2BUTTON_PRESS && (inside_widget(event->x,event->y,mainwin_vis) || inside_widget(event->x,event->y,mainwin_svis)))
	{
		cfg.vis_type++;
		if(cfg.vis_type>VIS_OFF)
			cfg.vis_type=VIS_ANALYZER;
		mainwin_vis_set_type(cfg.vis_type);
	}
	if(event->button==3)
	{
		GdkModifierType modmask;
		if(inside_widget(event->x,event->y,mainwin_info))
		{
			gdk_window_get_pointer(NULL,&mx,&my, &modmask);
			gtk_item_factory_popup(mainwin_songname_menu,mx,my,3,GDK_CURRENT_TIME);
			grab=FALSE;
		}
		else if(inside_widget(event->x,event->y,mainwin_vis) || inside_widget(event->x,event->y,mainwin_svis))
		{
			gdk_window_get_pointer(NULL,&mx,&my, &modmask);
			gtk_item_factory_popup(mainwin_vis_menu,mx,my,3,GDK_CURRENT_TIME);
			grab=FALSE;
		}
		else
		{
			gdk_window_get_pointer(NULL,&mx,&my, &modmask);
			gtk_item_factory_popup(mainwin_general_menu,mx,my,3,GDK_CURRENT_TIME);
			grab=FALSE;
		}
	}
	if(event->button==1)
	{
		if(event->x>35&&event->x<100&&event->y>25&&event->y<40 || inside_widget(event->x,event->y,mainwin_stime_min) || inside_widget(event->x,event->y,mainwin_stime_sec))
		{
			if(cfg.timer_mode==TIMER_ELAPSED) set_timer_mode(TIMER_REMAINING);
			else set_timer_mode(TIMER_ELAPSED);
		}
		
	}
	if(grab) gdk_pointer_grab(mainwin->window,FALSE,GDK_BUTTON_MOTION_MASK|GDK_BUTTON_RELEASE_MASK,GDK_NONE,GDK_NONE,GDK_CURRENT_TIME);
	
}

void mainwin_focus_in(GtkWidget *widget,GdkEvent *event,gpointer callback_data)
{
	mainwin_focus=1;
	if(cfg.focused_for_state_ctl)
	{
		show_widget(mainwin_menubtn);
		show_widget(mainwin_minimize);
		show_widget(mainwin_shade);
		show_widget(mainwin_close);
	}
	draw_main_window(TRUE);
}

void mainwin_focus_out(GtkWidget *widget,GdkEventButton *event,gpointer callback_data)
{
	mainwin_focus=0;
	if(cfg.focused_for_state_ctl)
	{
		hide_widget(mainwin_menubtn);
		hide_widget(mainwin_minimize);
		hide_widget(mainwin_shade);
		hide_widget(mainwin_close);
	}
	draw_main_window(TRUE);
}

void mainwin_jump_to_time_cb(GtkWidget *widget,GtkWidget *entry)
{
	guint min=0,sec=0,params,time;
	gchar timestr[6];

	strcpy(timestr,gtk_entry_get_text(GTK_ENTRY(entry)));

	params=sscanf(timestr,"%u:%u",&min,&sec);
	if(params==2)
		time=(min*60)+sec;
	else if(params==1)
		time=min;
	else
		return;

	if(time>=0&&time<=(playlist_get_current_length()/1000))
	{
		input_seek(time);
		gtk_widget_destroy(mainwin_jtt);
	}
}

void mainwin_jump_to_time()
{
	GtkWidget *vbox,*frame,*vbox_inside,*hbox_new,*hbox_total;
	GtkWidget *time_entry,*label,*bbox,*jump,*cancel;
	guint len,tindex;
	gchar timestr[10];

	if(!get_input_playing())
		return;

	mainwin_jtt=gtk_window_new(GTK_WINDOW_DIALOG);
	gtk_window_set_title(GTK_WINDOW(mainwin_jtt),"Jump to time");
	gtk_window_set_position(GTK_WINDOW(mainwin_jtt),GTK_WIN_POS_CENTER);
	gtk_window_set_policy(GTK_WINDOW(mainwin_jtt),FALSE,FALSE,FALSE);
	gtk_window_set_transient_for(GTK_WINDOW(mainwin_jtt),GTK_WINDOW(mainwin));
	gtk_signal_connect(GTK_OBJECT(mainwin_jtt),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&mainwin_jtt);
	gtk_container_border_width(GTK_CONTAINER(mainwin_jtt),10);

	vbox=gtk_vbox_new(FALSE,5);
	gtk_container_add(GTK_CONTAINER(mainwin_jtt),vbox);
	gtk_widget_show(vbox);
	frame=gtk_frame_new("Jump to:");
	gtk_box_pack_start(GTK_BOX(vbox),frame,TRUE,TRUE,0);
	gtk_widget_set_usize(frame,250,-1);
	gtk_widget_show(frame);
	vbox_inside=gtk_vbox_new(FALSE,0);
	gtk_container_add(GTK_CONTAINER(frame),vbox_inside);
	gtk_widget_show(vbox_inside);

	hbox_new=gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(vbox_inside),hbox_new,TRUE,TRUE,5);
	gtk_widget_show(hbox_new);
	time_entry=gtk_entry_new_with_max_length(5);
	gtk_box_pack_start(GTK_BOX(hbox_new),time_entry,FALSE,FALSE,5);
	gtk_signal_connect(GTK_OBJECT(time_entry),"activate",GTK_SIGNAL_FUNC(mainwin_jump_to_time_cb),time_entry);
	gtk_widget_show(time_entry);
	gtk_widget_set_usize(time_entry,70,-1);
	label=gtk_label_new("minutes:seconds");
	gtk_box_pack_start(GTK_BOX(hbox_new),label,FALSE,FALSE,5);
	gtk_widget_show(label);

	hbox_total=gtk_hbox_new(FALSE,0);
	gtk_box_pack_start(GTK_BOX(vbox_inside),hbox_total,TRUE,TRUE,5);
	gtk_widget_show(hbox_total);
	label=gtk_label_new("Track length:");
	gtk_box_pack_start(GTK_BOX(hbox_total),label,FALSE,FALSE,5);
	gtk_widget_show(label);
	len=playlist_get_current_length()/1000;
	sprintf(timestr,"%u:%2.2u",len/60,len%60);
	label=gtk_label_new(timestr);
	gtk_box_pack_start(GTK_BOX(hbox_total),label,FALSE,FALSE,10);
	gtk_widget_show(label);

	bbox=gtk_hbutton_box_new();
	gtk_box_pack_start(GTK_BOX(vbox),bbox,TRUE,TRUE,0);
	gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_START);
	gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
	gtk_widget_show(bbox);
	jump=gtk_button_new_with_label("Jump");
	GTK_WIDGET_SET_FLAGS(jump,GTK_CAN_DEFAULT);
	gtk_container_add(GTK_CONTAINER(bbox),jump);
	gtk_signal_connect(GTK_OBJECT(jump),"clicked",GTK_SIGNAL_FUNC(mainwin_jump_to_time_cb),time_entry);
	gtk_widget_show(jump);
	cancel=gtk_button_new_with_label("Cancel");
	GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
	gtk_container_add(GTK_CONTAINER(bbox),cancel);
	gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(mainwin_jtt));
	gtk_widget_show(cancel);

	tindex=input_get_time()/1000;
	sprintf(timestr,"%u:%2.2u",tindex/60,tindex%60);
	gtk_entry_set_text(GTK_ENTRY(time_entry),timestr);
	gtk_entry_select_region(GTK_ENTRY(time_entry),0,strlen(timestr));

	gtk_window_set_modal(GTK_WINDOW(mainwin_jtt),1);
        gtk_widget_show(mainwin_jtt);
	gtk_widget_grab_focus(time_entry);
	gtk_widget_grab_default(jump);
}

void mainwin_jump_to_file_real_cb(GtkWidget* widget)
{
	gint *pos;
	if(GTK_CLIST(widget)->selection)
	{
		if(get_input_playing())
			input_stop();
		pos=(gint*)gtk_clist_get_row_data(GTK_CLIST(widget),(gint)GTK_CLIST(widget)->selection->data);
		playlist_set_position(*pos);
		playlist_play();
		gtk_widget_destroy(mainwin_jtf);
	}
}

void mainwin_jump_to_file_select_row_cb(GtkWidget* widget,gint row,gint column,GdkEventButton *event,gpointer cb_data)
{
	if(event&&event->button==1&&event->type==GDK_2BUTTON_PRESS)
		mainwin_jump_to_file_real_cb(widget);
}

void mainwin_jump_to_file_keypress_cb(GtkWidget* widget,GdkEventKey* event,GList userdata)
{
	if(event&&(event->keyval==GDK_Return))
		mainwin_jump_to_file_real_cb(widget);
	else if(event&&(event->keyval==GDK_Escape))
		gtk_widget_destroy(mainwin_jtf);
}

void mainwin_jump_to_file()
{
	GtkWidget *vbox, *scrollwin, *clist, *sep,*bbox, *ok, *cancel;
	GList *playlist;
	gchar *title[]={"Files"};
	gchar *desc_buf;
	gint *data_buf;
	gint row;
	
	playlist=get_playlist();

	if(!g_list_length(playlist))
		return;
	
	mainwin_jtf=gtk_window_new(GTK_WINDOW_DIALOG);
	gtk_window_set_title(GTK_WINDOW(mainwin_jtf),"Jump to file");
	gtk_window_set_position(GTK_WINDOW(mainwin_jtf),GTK_WIN_POS_CENTER);
	gtk_window_set_policy(GTK_WINDOW(mainwin_jtf),FALSE,FALSE,FALSE);
	gtk_window_set_transient_for(GTK_WINDOW(mainwin_jtf),GTK_WINDOW(mainwin));
	gtk_signal_connect(GTK_OBJECT(mainwin_jtf),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&mainwin_jtf);
	gtk_container_border_width(GTK_CONTAINER(mainwin_jtf),10);
	gtk_widget_set_usize(mainwin_jtf,300,250);
	
	vbox=gtk_vbox_new(FALSE,5);
	gtk_container_add(GTK_CONTAINER(mainwin_jtf), vbox);
	gtk_widget_show(vbox);
	
	clist=gtk_clist_new_with_titles(1,title);
	gtk_clist_set_selection_mode(GTK_CLIST(clist),GTK_SELECTION_BROWSE);
	gtk_signal_connect(GTK_OBJECT(clist),"select_row",GTK_SIGNAL_FUNC(mainwin_jump_to_file_select_row_cb),NULL);
	gtk_signal_connect(GTK_OBJECT(clist),"key_press_event",GTK_SIGNAL_FUNC(mainwin_jump_to_file_keypress_cb),NULL);
	
	scrollwin=gtk_scrolled_window_new(NULL,NULL);
	gtk_container_add(GTK_CONTAINER(scrollwin),clist);
	gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrollwin),GTK_POLICY_AUTOMATIC,GTK_POLICY_ALWAYS);
	gtk_box_pack_start(GTK_BOX(vbox),scrollwin,TRUE,TRUE,0);
	gtk_widget_set_usize(scrollwin,330,200);
	gtk_widget_show(clist);
	gtk_widget_show(scrollwin);
	
	sep=gtk_hseparator_new();
	gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,0);
	gtk_widget_show(sep);
	
	bbox=gtk_hbutton_box_new();
	gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
	gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
	gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);
	
	cancel=gtk_button_new_with_label("Close");
	gtk_box_pack_start(GTK_BOX(bbox),cancel,FALSE,FALSE,0);
	gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(mainwin_jtf));
	GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
	gtk_widget_show(cancel);
	gtk_widget_grab_default(cancel);
	gtk_widget_show(bbox);
	
	gtk_clist_clear(GTK_CLIST(clist));

	while(playlist)
	{
		if(((PlaylistEntry*)playlist->data)->title)
			desc_buf=((PlaylistEntry*)playlist->data)->title;
		else
			desc_buf=strrchr(((PlaylistEntry*)playlist->data)->filename,'/')+1;
		row=gtk_clist_append(GTK_CLIST(clist),&desc_buf);
		data_buf=g_malloc(sizeof(gint));
		*data_buf=row;
		gtk_clist_set_row_data_full(GTK_CLIST(clist),row,data_buf,g_free);
		playlist=playlist->next;
	}
	
	gtk_clist_select_row(GTK_CLIST(clist),get_playlist_position(),0);
	if(cfg.sort_jump_to_file)
	{
		gtk_clist_set_sort_column(GTK_CLIST(clist),0);
		gtk_clist_set_sort_type(GTK_CLIST(clist),GTK_SORT_ASCENDING);
		gtk_clist_sort(GTK_CLIST(clist));
	}
	gtk_window_set_modal(GTK_WINDOW(mainwin_jtf),1);
	gtk_widget_show(mainwin_jtf);
	gtk_widget_grab_focus(clist);
	gtk_clist_moveto(GTK_CLIST(clist),(gint)GTK_CLIST(clist)->selection->data,0,0.5,0.0);
	GTK_CLIST(clist)->focus_row=(gint)GTK_CLIST(clist)->selection->data;
}

gint mainwin_configure(GtkWidget *window)
{
	/*
	 * On some WM's gdk_window_get_root_origin return weird values so..
	 */
	
	Window dummy;
	if(!mainwin_moving)
		XTranslateCoordinates(GDK_DISPLAY(),GDK_WINDOW_XWINDOW(window->window),GDK_ROOT_WINDOW(),0,0,&cfg.player_x,&cfg.player_y,&dummy);
	return FALSE;
}

static void mainwin_drag_data_received(GtkWidget *widget,
					GdkDragContext   *context,
					gint              x,
					gint              y,
					GtkSelectionData *selection_data,
					guint             info,
					guint             time)
{
	if(selection_data->data)
	{
		playlist_clear();
		playlist_add_url_string((gchar *)selection_data->data);
		playlistwin_update_list();
		playlist_play();
	}
}

void mainwin_url_ok_clicked(GtkWidget *w,GtkWidget *entry)
{
	gchar *text;
	text=gtk_entry_get_text(GTK_ENTRY(entry));
	if(text&&*text)
	{
		playlist_clear();
		playlist_add(text);
		playlist_generate_shuffle_list();
		playlistwin_update_list();
		playlist_play();
	}
	gtk_widget_destroy(mainwin_url_window);
}


void mainwin_show_add_url_window(void)
{
	GtkWidget *vbox,*bbox,*ok,*cancel,*entry;
	if(!mainwin_url_window)
	{
		mainwin_url_window=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_window_set_transient_for(GTK_WINDOW(mainwin_url_window),GTK_WINDOW(mainwin));
		gtk_window_set_title(GTK_WINDOW(mainwin_url_window),"Enter URL to add:");
		gtk_window_set_position(GTK_WINDOW(mainwin_url_window),GTK_WIN_POS_MOUSE);
		gtk_signal_connect(GTK_OBJECT(mainwin_url_window),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&mainwin_url_window);
		gtk_container_set_border_width(GTK_CONTAINER(mainwin_url_window),10);
		
		vbox=gtk_vbox_new(FALSE,10);
		gtk_container_add(GTK_CONTAINER(mainwin_url_window),vbox);
		
		entry=gtk_entry_new();
		gtk_signal_connect(GTK_OBJECT(entry),"activate",GTK_SIGNAL_FUNC(mainwin_url_ok_clicked),entry);
		gtk_box_pack_start(GTK_BOX(vbox),entry,FALSE,FALSE,0);
		gtk_widget_show(entry);
		
		bbox=gtk_hbutton_box_new();
		gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
		gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
		
		ok=gtk_button_new_with_label("Ok");
		gtk_signal_connect(GTK_OBJECT(ok),"clicked",GTK_SIGNAL_FUNC(mainwin_url_ok_clicked),entry);
		GTK_WIDGET_SET_FLAGS(ok,GTK_CAN_DEFAULT);
		gtk_window_set_default(GTK_WINDOW(mainwin_url_window),ok);
		gtk_box_pack_start(GTK_BOX(bbox),ok,FALSE,FALSE,0);
		gtk_widget_show(ok);
		
		cancel=gtk_button_new_with_label("Cancel");
		gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(mainwin_url_window));
		GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),cancel,FALSE,FALSE,0);
		gtk_widget_show(cancel);
		
		gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);
		gtk_widget_show(bbox);
		gtk_widget_show(vbox);
		gtk_widget_show(mainwin_url_window);
	}
	if(!GTK_WIDGET_VISIBLE(mainwin_url_window))
		gtk_widget_show(mainwin_url_window);
}

void mainwin_filesel_cancel(GtkWidget *w,GtkWidget *filesel)
{
	gtk_widget_destroy(GTK_WIDGET(filesel));
	mainwin_filesel=NULL;
}

static int int_compare_func(const void* a,const void* b)
{
	if((gint)a<(gint)b)
		return -1;
	if((gint)a>(gint)b)
		return 1;
	else
		return 0;
}

void mainwin_filesel_changed(GtkWidget *w,GtkFileSelection *filesel)
{
	gchar *text=gtk_entry_get_text(GTK_ENTRY(w)),*current="./",*parent="../";
	GList *list,*node;
	
	if(!text || !(*text))
	{
		if(list=input_scan_dir(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel))))
		{
			gtk_clist_clear(GTK_CLIST(filesel->dir_list));
			gtk_clist_append(GTK_CLIST(filesel->dir_list),&current);
			gtk_clist_append(GTK_CLIST(filesel->dir_list),&parent);
			
			gtk_clist_freeze(GTK_CLIST(filesel->file_list));
			gtk_clist_clear(GTK_CLIST(filesel->file_list));
			node=list;
			while(node)
			{
				gtk_clist_append(GTK_CLIST(filesel->file_list),(gchar **)&node->data);
				g_free(node->data);
				node=g_list_next(node);
			}
			gtk_clist_thaw(GTK_CLIST(filesel->file_list));
			g_list_free(list);
		}
	}
}

void mainwin_filesel_ok(GtkWidget *w,GtkWidget *filesel)
{
	GList *node;
	gchar *text,*text2;
	GList *sel_list=NULL;
	
	struct stat buf;

	text=g_strdup(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
	while(*(strrchr(text,'/')+1)=='\0')
		*(strrchr(text,'/'))='\0';

	if(stat(text, &buf) == 0) 
	{
		if(S_ISDIR(buf.st_mode)) 
		{ /* Selected directory -- don't close frequester */
			text2=g_strdup_printf("%s/",text);
			gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),text2);
			g_free(text2);
			return;
		}
	}

	g_free(text);
	
	/*
	 * This is *REAL* ugly and needs to be fixed
	 */
	
	gtk_widget_hide(filesel);
	
	if(cfg.filesel_path)
		g_free(cfg.filesel_path);
	cfg.filesel_path=g_strdup(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
	text=strrchr(cfg.filesel_path,'/');
	if(text)
		*(text+1)='\0';
	
	node=GTK_CLIST(GTK_FILE_SELECTION(filesel)->file_list)->selection;
	node = g_list_sort(node,int_compare_func);
	while(node)
	{
		gtk_clist_get_text(GTK_CLIST(GTK_FILE_SELECTION(filesel)->file_list),(gint)node->data,0,&text);
		text2=g_malloc(strlen(text)+1);
		strcpy(text2,text);
		if(cfg.open_rev_order)
			sel_list=g_list_prepend(sel_list,text2);
		else
			sel_list=g_list_append(sel_list,text2);



		node=node->next;
	}
	node=sel_list;
	if(node)
	{
		if(get_input_playing()) input_stop();
		playlist_clear();
		while(node)
		{
			text=(gchar *)node->data;
			gtk_file_selection_set_filename(GTK_FILE_SELECTION(filesel),text);
			playlist_add(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
			g_free(text);
			node=node->next;
		}
		g_list_free(sel_list);
		playlist_generate_shuffle_list();
		playlist_play();
	}
	else
	{
		text=gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel));
		if(text[strlen(text)-1]!='/')
		{
			if(get_input_playing()) input_stop();
			playlist_clear();
			playlist_add(gtk_file_selection_get_filename(GTK_FILE_SELECTION(filesel)));
			playlist_generate_shuffle_list();
			playlist_play();
		}
	}
	gtk_widget_destroy(GTK_WIDGET(filesel));
	mainwin_filesel=NULL;
	
}

void mainwin_eject_pushed(void)
{
	if(!mainwin_filesel)
	{
		mainwin_filesel=gtk_file_selection_new("Load file(s)");
		gtk_clist_set_selection_mode(GTK_CLIST(GTK_FILE_SELECTION(mainwin_filesel)->file_list),GTK_SELECTION_EXTENDED);
		gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(mainwin_filesel)->selection_entry),"changed",GTK_SIGNAL_FUNC(mainwin_filesel_changed),mainwin_filesel);
		gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(mainwin_filesel)->ok_button),"clicked",GTK_SIGNAL_FUNC(mainwin_filesel_ok),mainwin_filesel);
		gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(mainwin_filesel)->cancel_button),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(mainwin_filesel));
     		gtk_signal_connect(GTK_OBJECT(mainwin_filesel),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&mainwin_filesel);
		if(cfg.filesel_path)
			gtk_file_selection_set_filename(GTK_FILE_SELECTION(mainwin_filesel),cfg.filesel_path);
		gtk_widget_show(mainwin_filesel);
	}
	if(!GTK_WIDGET_VISIBLE(mainwin_filesel))
		gtk_widget_show(mainwin_filesel);
}

void mainwin_play_pushed(void)
{
	if(get_input_paused())
	{
		input_pause();
		return;
	}
	if(get_playlist_length())
		playlist_play();
	else
		mainwin_eject_pushed();
}

void mainwin_stop_pushed(void)
{
	mainwin_set_song_info(0,0,0);
	input_stop();
}


		
void mainwin_shuffle_pushed(gboolean toggled)
{
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Shuffle"))->active=toggled;
	cfg.shuffle=toggled;
}

void mainwin_repeat_pushed(gboolean toggled)
{
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Repeat"))->active=toggled;
	cfg.repeat=toggled;
}

void mainwin_eq_pushed(gboolean toggled)
{
	if(toggled) equalizerwin_show();
	else equalizerwin_hide();
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Graphical EQ"))->active=cfg.equalizer_visible;
}

void mainwin_pl_pushed(gboolean toggled)
{
	if(toggled) playlistwin_show();
	else playlistwin_hide();
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Playlist Editor"))->active=cfg.playlist_visible;
}

gint mainwin_spos_frame_cb(gint pos)
{
	if(mainwin_sposition)
	{
		if(pos<6)
			mainwin_sposition->hs_knob_nx = mainwin_sposition->hs_knob_px = 17;
		else if(pos<9)
			mainwin_sposition->hs_knob_nx = mainwin_sposition->hs_knob_px = 20;
		else
			mainwin_sposition->hs_knob_nx = mainwin_sposition->hs_knob_px = 23;
	}
	return 1;
}

void mainwin_spos_motion_cb(gint pos)
{
	gint time;
	gchar *tmp;
	pos--;

	
	time=((playlist_get_current_length()/1000)*pos)/12;
	if(cfg.timer_mode == TIMER_REMAINING)
	{
		time = (playlist_get_current_length()/1000) - time;
		tmp = g_strdup_printf("-%2.2d",time/60);
		textbox_set_text(mainwin_stime_min,tmp);
		g_free(tmp);
	}
	else
	{
		tmp = g_strdup_printf(" %2.2d",time/60);
		textbox_set_text(mainwin_stime_min,tmp);
		g_free(tmp);
	}
	tmp = g_strdup_printf("%2.2d",time%60);
	textbox_set_text(mainwin_stime_sec,tmp);
	g_free(tmp);
}

void mainwin_spos_release_cb(gint pos)
{
	input_seek(((playlist_get_current_length()/1000)*(pos-1))/12);
}

void mainwin_position_motioncb(gint pos)
{
	gint length,time;
	gchar *buf;
	length=playlist_get_current_length()/1000;
	time=(length*pos)/219;
	buf=g_strdup_printf("SEEK TO: %d:%-2.2d/%d:%-2.2d (%d%%)",time/60,time%60,length/60,length%60,(length!=0)?(time*100)/length:0);
	mainwin_lock_info_text(buf);
	g_free(buf);
}

void mainwin_position_releasecb(gint pos)
{
	int length,time;
	length=playlist_get_current_length()/1000;
	time=(length*pos)/219;
	input_seek(time);
	mainwin_release_info_text();
}	

gint mainwin_volume_framecb(gint pos)
{
	return (int)rint((pos/52.0)*28);
}

void mainwin_volume_motioncb(gint pos)
{
	char tmp[20];	
	int v,b;
	
	setting_volume=TRUE;
	v=(int)rint((pos/51.0)*100);
	sprintf(tmp,"VOLUME: %d%%",v);
	mainwin_lock_info_text(tmp);
	if(mainwin_balance->hs_position<12)
	{
		b=(mainwin_balance->hs_position*100)/12;
		input_set_volume(v,(v*b)/100);
	}
	else if(mainwin_balance->hs_position>12)
	{
		b=100-(((mainwin_balance->hs_position-12)*100)/12);
		input_set_volume((v*b)/100,v);
	}
	else
	{
		input_set_volume(v,v);
	}
}

void mainwin_volume_releasecb(gint pos)
{
	mainwin_release_info_text();
	setting_volume=FALSE;
}

gint mainwin_balance_framecb(gint pos)
{
	return ((abs(pos-12)*28)/13);
}	

void mainwin_balance_motioncb(gint pos)
{
	char tmp[20];
	int b,v;
	
	setting_volume=TRUE;
	v=(int)rint((mainwin_volume->hs_position/51.0)*100);
	if(pos<12)
	{
		b=((12-pos)*100)/12;
		sprintf(tmp,"BALANCE: %d%% LEFT",b);
		input_set_volume(v,(int)rint(((100-b)/100.0)*v));
	}
	else if(pos==12)
	{
		sprintf(tmp,"BALANCE: CENTER");		
		input_set_volume(v,v);
	}
	else if(pos>12)
	{
		b=((pos-12)*100)/12;
		sprintf(tmp,"BALANCE: %d%% RIGHT",b);
		input_set_volume((int)rint(((100-b)/100.0)*v),v);
	}
	mainwin_lock_info_text(tmp);
}

void mainwin_balance_releasecb(gint pos)
{
	mainwin_release_info_text();
	setting_volume=FALSE;
}

void mainwin_songname_menu_callback(gpointer cb_data,guint action,GtkWidget *w)
{
	switch(action)
	{
		case	MAINWIN_SONGNAME_FILEINFO:
			break;
		case	MAINWIN_SONGNAME_JTF:
			mainwin_jump_to_file();
			break;
		case	MAINWIN_SONGNAME_JTT:
			mainwin_jump_to_time();
			break;
		case	MAINWIN_SONGNAME_SCROLL:
			cfg.autoscroll=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_songname_menu,"/Autoscroll Songname"))->active;
			textbox_set_scroll(mainwin_info,cfg.autoscroll);
			break;
	}
}

void mainwin_options_menu_callback(gpointer cb_data,guint action,GtkWidget *w)
{
	switch(action)
	{
		case	MAINWIN_OPT_PREFS:
			show_prefs_window();
			break;
		case	MAINWIN_OPT_SKIN:
			show_skin_window();
			break;
		case	MAINWIN_OPT_SHUFFLE:
			tbutton_set_toggled(mainwin_shuffle,GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Shuffle"))->active);
			cfg.shuffle=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Shuffle"))->active;
			break;
		case	MAINWIN_OPT_REPEAT:
			tbutton_set_toggled(mainwin_repeat,GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Repeat"))->active);
			cfg.repeat=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Repeat"))->active;
			break;
		case	MAINWIN_OPT_TELAPSED:
			set_timer_mode(TIMER_ELAPSED);
			break;
		case	MAINWIN_OPT_TREMAINING:
			set_timer_mode(TIMER_REMAINING);
			break;
		case	MAINWIN_OPT_ALWAYS:
			mainwin_menurow->mr_always_selected=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Always On Top"))->active;
			cfg.always_on_top=mainwin_menurow->mr_always_selected;
			draw_widget(mainwin_menurow);
			set_always(mainwin_menurow->mr_always_selected);
			break;
		case	MAINWIN_OPT_WS:
			mainwin_set_shade(GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/WindowShade Mode"))->active);
			break;
		case	MAINWIN_OPT_DOUBLESIZE:
			mainwin_menurow->mr_doublesize_selected=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/DoubleSize"))->active;
			draw_widget(mainwin_menurow);
			set_doublesize(mainwin_menurow->mr_doublesize_selected);
			gdk_flush();
			break;
		case	MAINWIN_OPT_EASY_MOVE:
			cfg.easy_move=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Easy Move"))->active;
			break;
		case	MAINWIN_OPT_NPA:
			cfg.no_playlist_advance=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/No Playlist Advance"))->active;
	}
}

void mainwin_vis_menu_callback(gpointer cb_data,guint action,GtkWidget *w)
{
	switch(action)
	{
		case	MAINWIN_VIS_ANALYZER:
		case	MAINWIN_VIS_SCOPE:
		case	MAINWIN_VIS_OFF:
			mainwin_vis_set_type(action-MAINWIN_VIS_ANALYZER);
			break;
		case	MAINWIN_VIS_ANALYZER_NORMAL:
		case	MAINWIN_VIS_ANALYZER_FIRE:
		case	MAINWIN_VIS_ANALYZER_VLINES:
			mainwin_vis_set_analyzer_mode(action-MAINWIN_VIS_ANALYZER_NORMAL);
			break;
		case    MAINWIN_VIS_ANALYZER_LINES:
		case    MAINWIN_VIS_ANALYZER_BARS:
			mainwin_vis_set_analyzer_type(action-MAINWIN_VIS_ANALYZER_LINES);
			break;
		case	MAINWIN_VIS_ANALYZER_PEAKS:
			cfg.analyzer_peaks=GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_ANALYZER_PEAKS].path))->active;
			break;
		case	MAINWIN_VIS_SCOPE_DOT:
		case	MAINWIN_VIS_SCOPE_LINE:
		case	MAINWIN_VIS_SCOPE_SOLID:
			cfg.scope_mode=action-MAINWIN_VIS_SCOPE_DOT;
			break;
		case	MAINWIN_VIS_VU_NORMAL:
		case	MAINWIN_VIS_VU_SMOOTH:
			cfg.vu_mode=action-MAINWIN_VIS_VU_NORMAL;
			break;
		case	MAINWIN_VIS_REFRESH_FULL:
		case	MAINWIN_VIS_REFRESH_HALF:
		case	MAINWIN_VIS_REFRESH_QUARTER:
		case	MAINWIN_VIS_REFRESH_EIGTH:
			mainwin_vis_set_refresh(action-MAINWIN_VIS_REFRESH_FULL);
			break;
		case	MAINWIN_VIS_AFALLOFF_SLOWEST:
		case	MAINWIN_VIS_AFALLOFF_SLOW:
		case	MAINWIN_VIS_AFALLOFF_MEDIUM:
		case	MAINWIN_VIS_AFALLOFF_FAST:			
		case	MAINWIN_VIS_AFALLOFF_FASTEST:
			mainwin_vis_set_afalloff(action-MAINWIN_VIS_AFALLOFF_SLOWEST);
			break;
		case	MAINWIN_VIS_PFALLOFF_SLOWEST:
		case	MAINWIN_VIS_PFALLOFF_SLOW:
		case	MAINWIN_VIS_PFALLOFF_MEDIUM:
		case	MAINWIN_VIS_PFALLOFF_FAST:			
		case	MAINWIN_VIS_PFALLOFF_FASTEST:
			mainwin_vis_set_pfalloff(action-MAINWIN_VIS_PFALLOFF_SLOWEST);
			break;
	}
}

void mainwin_general_menu_callback(gpointer cb_data,guint action,GtkWidget *w)
{
	switch(action)
	{
		case	MAINWIN_GENERAL_ABOUT:
			break;
		case	MAINWIN_GENERAL_PLAYFILE:
			mainwin_eject_pushed();
			break;
		case	MAINWIN_GENERAL_PLAYLOCATION:
			mainwin_show_add_url_window();
			break;
		case	MAINWIN_GENERAL_FILEINFO:
			break;
		case	MAINWIN_GENERAL_SHOWMWIN:
			break;
		case	MAINWIN_GENERAL_SHOWPLWIN:
			if(!cfg.playlist_visible)
				playlistwin_show();
			else
				playlistwin_hide();
			break;
		case	MAINWIN_GENERAL_SHOWEQWIN:
			if(!cfg.equalizer_visible)
				equalizerwin_show();
			else
				equalizerwin_hide();
			break;
		case	MAINWIN_GENERAL_PREV:
			playlist_prev();
			break;
		case	MAINWIN_GENERAL_PLAY:
			mainwin_play_pushed();
			break;
		case	MAINWIN_GENERAL_PAUSE:
			input_pause();
			break;
		case	MAINWIN_GENERAL_STOP:
			mainwin_stop_pushed();
			break;
		case	MAINWIN_GENERAL_NEXT:
			playlist_next();
			break;
		case	MAINWIN_GENERAL_STOPFADE:
			break;
		case	MAINWIN_GENERAL_BACK5SEC:
			if(get_input_playing())
				input_seek((((input_get_time()/1000)-5>=0)?(input_get_time()/1000)-5:0));
			break;
		case	MAINWIN_GENERAL_FWD5SEC:
			if(get_input_playing())
				input_seek(((((input_get_time()/1000)+5)<(playlist_get_current_length()/1000))?((input_get_time()/1000)+5):((playlist_get_current_length()/1000)-1)));
			break;
		case	MAINWIN_GENERAL_START:
			playlist_set_position(0);
			break;
		case	MAINWIN_GENERAL_BACK10:
			playlist_set_position((((get_playlist_position()-10)>=0)?get_playlist_position()-10:0));
			break;
		case	MAINWIN_GENERAL_FWD10:
			playlist_set_position((((get_playlist_position()+10)<get_playlist_length())?(get_playlist_position()+10):(get_playlist_length()-1)));
			break;
		case	MAINWIN_GENERAL_JTT:
			mainwin_jump_to_time();
			break;
		case	MAINWIN_GENERAL_JTF:
			mainwin_jump_to_file();
			break;
		case	MAINWIN_GENERAL_EXIT:
			mainwin_quit_cb();
			break;
	}
}

void mainwin_mr_change(MenuRowItem i)
{
	switch(i)
	{
		case	MENUROW_NONE:
			mainwin_set_info_text();
			break;
		case	MENUROW_OPTIONS:
			mainwin_lock_info_text("OPTIONS MENU");
			break;
		case	MENUROW_ALWAYS:
			if (wm_hints==WM_HINTS_NONE)
				if(mainwin_menurow->mr_always_selected)
					mainwin_lock_info_text("DISABLE ALWAYS ON TOP (N/A)");
				else
					mainwin_lock_info_text("ENABLE ALWAYS ON TOP (N/A)");
			else
				if(mainwin_menurow->mr_always_selected)
					mainwin_lock_info_text("DISABLE ALWAYS ON TOP");
				else
					mainwin_lock_info_text("ENABLE ALWAYS ON TOP");
			break;
		case	MENUROW_FILEINFOBOX:
			mainwin_lock_info_text("FILE INFO BOX");
			break;
		case	MENUROW_DOUBLESIZE:
			if(mainwin_menurow->mr_doublesize_selected)
				mainwin_lock_info_text("DISABLE DOUBLESIZE");
			else	
				mainwin_lock_info_text("ENABLE DOUBLESIZE");
			break;
		case	MENUROW_VISUALIZATION:
			mainwin_lock_info_text("VISUALIZATION MENU");
			break;
	}
}

void mainwin_mr_release(MenuRowItem i)
{
	GdkModifierType modmask;
	gint x,y;

	switch(i)
	{
		case	MENUROW_OPTIONS:
			gdk_window_get_pointer(NULL,&x,&y, &modmask);
			gtk_item_factory_popup(mainwin_options_menu,x,y,1,GDK_CURRENT_TIME);
			break;
		case	MENUROW_ALWAYS:
			GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Always On Top"))->active=mainwin_menurow->mr_always_selected;
			set_always(mainwin_menurow->mr_always_selected);
			break;
		case	MENUROW_FILEINFOBOX:
			break;
		case	MENUROW_DOUBLESIZE:
			GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/DoubleSize"))->active=mainwin_menurow->mr_doublesize_selected;
			set_doublesize(mainwin_menurow->mr_doublesize_selected);
			break;
		case	MENUROW_VISUALIZATION:
			gdk_window_get_pointer(NULL,&x,&y, &modmask);
			gtk_item_factory_popup(mainwin_vis_menu,x,y,1,GDK_CURRENT_TIME);
			break;
	}
	mainwin_release_info_text();
}


#define VOLSET_DISP_TIMES 50
enum {VOLSET_STARTUP,VOLSET_UPDATE};

void read_volume(gint when)
{
	int vl,vr,b;
	static int pvl=0,pvr=0,times=VOLSET_DISP_TIMES;
	static gboolean changing=FALSE,do_update=TRUE;
	gchar tmp[20];

	if(!do_update) return;
	input_get_volume(&vl,&vr);
	if(when==VOLSET_STARTUP)
	{
		vl=((vl>100||vl<0)?0:vl);
		vr=((vr>100||vr<0)?0:vr);
		pvl=vl;
		pvr=vr;
	}
	else if(when==VOLSET_UPDATE)
	{
		if(vl>100||vl<0||vr>100||vr<0)
		{
			do_update=FALSE;
			return;
		}

		if(setting_volume)
		{
			pvl=vl;
			pvr=vr;
			return;
		}
		else if(pvr==vr&&pvl==vl&&changing)
		{
			if(times<VOLSET_DISP_TIMES)
				times++;
			else
			{
				mainwin_release_info_text();
				changing=FALSE;
			}
		}
		else if(pvr!=vr||pvl!=vl)
		{
			if(((vr>vl)?vr:vl)!=((pvr>pvl)?pvr:pvl))
				sprintf(tmp,"VOLUME: %d%%",((vr>vl)?vr:vl));
			else
			{
				if(vl>vr)
				{
					b=100-(int)rint(((float)vr/vl)*100);
					sprintf(tmp,"BALANCE: %d%% LEFT",b);
				}
				else if(vr==vl)
					sprintf(tmp,"BALANCE: CENTER");		
				else if(vl<vr)
				{
					b=100-(int)rint(((float)vl/vr)*100);
					sprintf(tmp,"BALANCE: %d%% RIGHT",b);
				}
			}
			mainwin_lock_info_text(tmp);
			pvr=vr;
			pvl=vl;
			times=0;
			changing=TRUE;
		}
	}
	
	if(vl>vr)
	{
		hslider_set_position(mainwin_volume,(int)rint((vl/100.0)*51));
		hslider_set_position(mainwin_balance,(int)rint(((float)vr/vl)*12));
	}
	else if(vr>vl)
	{
		hslider_set_position(mainwin_volume,(int)rint((vr/100.0)*51));
		hslider_set_position(mainwin_balance,24-(int)rint(((float)vl/vr)*12));
	}
	else
	{
		hslider_set_position(mainwin_volume,(int)rint((vl/100.0)*51));
		hslider_set_position(mainwin_balance,12);
	}
}

void create_popups(void)
{
	GtkMenuItem *item;
	int i;
	
	mainwin_options_menu=gtk_item_factory_new(GTK_TYPE_MENU,"<Main>",global_accel);
	gtk_item_factory_create_items(mainwin_options_menu,MAINWIN_OPTIONS_MENU_ENTRIES,mainwin_options_menu_entries,NULL);
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Shuffle"))->active=cfg.shuffle;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Repeat"))->active=cfg.repeat;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Easy Move"))->active=cfg.easy_move;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/No Playlist Advance"))->active=cfg.no_playlist_advance;
	if(cfg.timer_mode==TIMER_ELAPSED)
	{
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Elapsed"))->active=TRUE;
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Remaining"))->active=FALSE;
	}
	else
	{
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Elapsed"))->active=FALSE;
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Remaining"))->active=TRUE;
	}

	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Always On Top"))->active=cfg.always_on_top;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/DoubleSize"))->active=cfg.doublesize;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/WindowShade Mode"))->active=cfg.player_shaded;
	mainwin_songname_menu=gtk_item_factory_new(GTK_TYPE_MENU,"<Main>",mainwin_accel);
	gtk_item_factory_create_items(mainwin_songname_menu,MAINWIN_SONGNAME_MENU_ENTRIES,mainwin_songname_menu_entries,NULL);
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_songname_menu,"/Autoscroll Songname"))->active=cfg.autoscroll;
	
	mainwin_vis_menu=gtk_item_factory_new(GTK_TYPE_MENU,"<Main>",mainwin_accel);
	gtk_item_factory_create_items(mainwin_vis_menu,MAINWIN_VIS_MENU_ENTRIES,mainwin_vis_menu_entries,NULL);
	for(i=0;i<MAINWIN_VIS_MENU_NUM_VIS_MODE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_VIS_MODE+i].path))->active=(cfg.vis_type==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_ANALYZER_MODE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_ANALYZER_MODE+i].path))->active=(cfg.analyzer_mode==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_ANALYZER_TYPE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_ANALYZER_TYPE+i].path))->active=(cfg.analyzer_type==i)?TRUE:FALSE;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_ANALYZER_PEAKS].path))->active=cfg.analyzer_peaks;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_SCOPE_MODE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_SCOPE_MODE+i].path))->active=(cfg.scope_mode==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_WSHADEVU_MODE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_WSHADEVU_MODE+i].path))->active=(cfg.vu_mode==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_REFRESH_RATE;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_REFRESH_RATE+i].path))->active=(cfg.vis_refresh==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_AFALLOFF;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_AFALLOFF+i].path))->active=(cfg.analyzer_falloff==i)?TRUE:FALSE;
	for(i=0;i<MAINWIN_VIS_MENU_NUM_AFALLOFF;i++)
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_vis_menu,mainwin_vis_menu_entries[MAINWIN_VIS_MENU_PFALLOFF+i].path))->active=(cfg.peaks_falloff==i)?TRUE:FALSE;

	mainwin_general_menu=gtk_item_factory_new(GTK_TYPE_MENU,"<Main>",global_accel);
	gtk_item_factory_create_items(mainwin_general_menu,MAINWIN_GENERAL_MENU_ENTRIES,mainwin_general_menu_entries,NULL);
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Playlist Editor"))->active=cfg.playlist_visible;
	GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Graphical EQ"))->active=cfg.equalizer_visible;
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Options")),GTK_WIDGET(gtk_item_factory_get_widget(mainwin_options_menu,"")));
	gtk_menu_item_set_submenu(GTK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_general_menu,"/Visualization")),GTK_WIDGET(gtk_item_factory_get_widget(mainwin_vis_menu,"")));
}

void setup_main_window(void)
{
	
	mainwin_bg=gdk_pixmap_new(mainwin->window,275,116,gdk_visual_get_best_depth());
	mainwin_bg_dblsize=gdk_pixmap_new(mainwin->window,550,232,gdk_visual_get_best_depth());
	if(cfg.doublesize)
		gdk_window_set_back_pixmap(mainwin->window,mainwin_bg_dblsize,0);
	else
		gdk_window_set_back_pixmap(mainwin->window,mainwin_bg,0);
	mainwin_gc=gdk_gc_new(mainwin->window);
	
	mainwin_menubtn=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,6,3,9,9,0,0,0,9,mainwin_menubtn_cb,SKIN_TITLEBAR);
	mainwin_minimize=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,244,3,9,9,9,0,9,9,mainwin_minimize_cb,SKIN_TITLEBAR);
	mainwin_shade=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,254,3,9,9,0,18,9,18,mainwin_shade_cb,SKIN_TITLEBAR);
	mainwin_close=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,264,3,9,9,18,0,18,9,mainwin_quit_cb,SKIN_TITLEBAR);
	
	mainwin_rew=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,16,88,23,18,0,0,0,18,playlist_prev,SKIN_CBUTTONS);
	mainwin_play=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,39,88,23,18,23,0,23,18,mainwin_play_pushed,SKIN_CBUTTONS);
	mainwin_pause=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,62,88,23,18,46,0,46,18,input_pause,SKIN_CBUTTONS);
	mainwin_stop=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,85,88,23,18,69,0,69,18,mainwin_stop_pushed,SKIN_CBUTTONS);
	mainwin_fwd=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,108,88,22,18,92,0,92,18,playlist_next,SKIN_CBUTTONS);
	mainwin_eject=create_pbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,136,89,22,16,114,0,114,16,mainwin_eject_pushed,SKIN_CBUTTONS);
	
	mainwin_srew=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,169,4,8,7,playlist_prev);
	mainwin_splay=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,177,4,10,7,mainwin_play_pushed);
	mainwin_spause=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,187,4,10,7,input_pause);
	mainwin_sstop=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,197,4,9,7,mainwin_stop_pushed);
	mainwin_sfwd=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,206,4,8,7,playlist_next);
	mainwin_seject=create_sbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,216,4,9,7,mainwin_eject_pushed);
	
	mainwin_shuffle=create_tbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,164,89,46,15,28,0,28,15,28,30,28,45,mainwin_shuffle_pushed,SKIN_SHUFREP);
	tbutton_set_toggled(mainwin_shuffle,cfg.shuffle);
	mainwin_repeat=create_tbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,210,89,28,15,0,0,0,15,0,30,0,45,mainwin_repeat_pushed,SKIN_SHUFREP);
	tbutton_set_toggled(mainwin_repeat,cfg.repeat);
	
	mainwin_eq=create_tbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,219,58,23,12,0,61,46,61,0,73,46,73,mainwin_eq_pushed,SKIN_SHUFREP);
	tbutton_set_toggled(mainwin_eq,cfg.equalizer_visible);
	mainwin_pl=create_tbutton(&mainwin_wlist,mainwin_bg,mainwin_gc,242,58,23,12,23,61,69,61,23,73,69,73,mainwin_pl_pushed,SKIN_SHUFREP);
	tbutton_set_toggled(mainwin_pl,cfg.playlist_visible);
	
	mainwin_info=create_textbox(&mainwin_wlist,mainwin_bg,mainwin_gc,112,27,153,1,SKIN_TEXT);
	textbox_set_scroll(mainwin_info,cfg.autoscroll);
	mainwin_rate_text=create_textbox(&mainwin_wlist,mainwin_bg,mainwin_gc,111,43,15,0,SKIN_TEXT);
	mainwin_freq_text=create_textbox(&mainwin_wlist,mainwin_bg,mainwin_gc,156,43,10,0,SKIN_TEXT);
	
	mainwin_menurow=create_menurow(&mainwin_wlist,mainwin_bg,mainwin_gc,10,22,304,0,304,44,mainwin_mr_change,mainwin_mr_release,SKIN_TITLEBAR);
	mainwin_menurow->mr_doublesize_selected=cfg.doublesize;
	mainwin_menurow->mr_always_selected=cfg.always_on_top;	
	
	mainwin_volume=create_hslider(&mainwin_wlist,mainwin_bg,mainwin_gc,107,57,68,13,15,422,0,422,14,11,15,0,0,51,mainwin_volume_framecb,mainwin_volume_motioncb,mainwin_volume_releasecb,SKIN_VOLUME);
	mainwin_balance=create_hslider(&mainwin_wlist,mainwin_bg,mainwin_gc,177,57,38,13,15,422,0,422,14,11,15,9,0,24,mainwin_balance_framecb,mainwin_balance_motioncb,mainwin_balance_releasecb,SKIN_BALANCE);
	read_volume(VOLSET_STARTUP);
	
	mainwin_monostereo=create_monostereo(&mainwin_wlist,mainwin_bg,mainwin_gc,212,41,SKIN_MONOSTEREO);
	
	mainwin_playstatus=create_playstatus(&mainwin_wlist,mainwin_bg,mainwin_gc,24,28);
	
	mainwin_minus_num=create_number(&mainwin_wlist,mainwin_bg,mainwin_gc,36,26,SKIN_NUMBERS);
	hide_widget(mainwin_minus_num);
	mainwin_10min_num=create_number(&mainwin_wlist,mainwin_bg,mainwin_gc,48,26,SKIN_NUMBERS);
	hide_widget(mainwin_10min_num);
	mainwin_min_num=create_number(&mainwin_wlist,mainwin_bg,mainwin_gc,60,26,SKIN_NUMBERS);
	hide_widget(mainwin_min_num);
	mainwin_10sec_num=create_number(&mainwin_wlist,mainwin_bg,mainwin_gc,78,26,SKIN_NUMBERS);
	hide_widget(mainwin_10sec_num);
	mainwin_sec_num=create_number(&mainwin_wlist,mainwin_bg,mainwin_gc,90,26,SKIN_NUMBERS);
	hide_widget(mainwin_sec_num);
	
	mainwin_vis=create_vis(&mainwin_wlist,mainwin_bg,mainwin_gc,24,43);
	mainwin_svis=create_svis(&mainwin_wlist,mainwin_bg,mainwin_gc,79,4);
	
	mainwin_position=create_hslider(&mainwin_wlist,mainwin_bg,mainwin_gc,16,72,248,10,248,0,278,0,29,10,10,0,0,219,NULL,mainwin_position_motioncb,mainwin_position_releasecb,SKIN_POSBAR);
	hide_widget(mainwin_position);
	
	mainwin_sposition=create_hslider(&mainwin_wlist,mainwin_bg,mainwin_gc,226,4,17,7,17,36,17,36,3,7,36,0,1,13,mainwin_spos_frame_cb,mainwin_spos_motion_cb,mainwin_spos_release_cb,SKIN_TITLEBAR);
	hide_widget(mainwin_sposition);
	
	mainwin_stime_min = create_textbox(&mainwin_wlist,mainwin_bg,mainwin_gc,130,4,15,FALSE,SKIN_TEXT);
	mainwin_stime_sec = create_textbox(&mainwin_wlist,mainwin_bg,mainwin_gc,147,4,10,FALSE,SKIN_TEXT);
	
	if(!cfg.player_shaded)
	{
		hide_widget(mainwin_svis);
		hide_widget(mainwin_srew);
		hide_widget(mainwin_splay);
		hide_widget(mainwin_spause);
		hide_widget(mainwin_sstop);
		hide_widget(mainwin_sfwd);
		hide_widget(mainwin_seject);
		hide_widget(mainwin_stime_min);
		hide_widget(mainwin_stime_sec);
	}
	
}

void set_timer_mode(TimerMode mode)
{
	cfg.timer_mode=mode;
	if(mode==TIMER_ELAPSED)
	{
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Elapsed"))->active=TRUE;
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Remaining"))->active=FALSE;
	}
	else
	{
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Elapsed"))->active=FALSE;
		GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(mainwin_options_menu,"/Time Remaining"))->active=TRUE;
	}
}
	
gint idle_func(gpointer data)
{		
	gint time,t,length,x;
	guchar *vis_data;
	static gint round=0;
	gchar stime_prefix,*tmp;	
	
	static gint vis_offset=0,vis_delta=1,prev_type=-1,vis_sync_vu = 0,vis_sync_delta = 1;
				
	if(get_input_playing())
	{
		
		time=input_get_time();
		if(time==-1)
		{
			playlist_eof_reached();
		}
		else
		{
			length=playlist_get_current_length();
			playlistwin_set_time(time,length);
                        if(cfg.vis_type!=VIS_OFF)
                        {
				if(vis_data=input_get_vis(time))
				{
					if(cfg.player_shaded)
						svis_set_data(mainwin_svis,vis_data);
					else
						vis_set_data(mainwin_vis,vis_data);
					g_free(vis_data);
					prev_type=input_get_vis_type();
				}
				else if(prev_type!=input_get_vis_type()&&prev_type!=-1)
				{
					vis_data=g_malloc0(75);
					switch(cfg.vis_type)
					{
						case	VIS_ANALYZER:
							if(cfg.player_shaded)
							{
								vis_data[0] = vis_data[1] = vis_sync_vu;
								vis_sync_vu += vis_sync_delta;
								if(vis_sync_vu == 0)
									vis_sync_delta = 1;
								else if(vis_sync_vu == 37)
									vis_sync_delta = -1;
								
							}
							else
							{
								vis_data[vis_offset]=15;
								vis_offset+=vis_delta;
								if(vis_offset==0)
									vis_delta=1;
								else if(vis_offset==74)
									vis_delta=-1;

								
							}
							break;
						case	VIS_SCOPE:
							for(x=0;x<75;x++)
								vis_data[x]=(gint)((sin((x+vis_offset)*((2*M_PI)/75.0))*6.0)+6.0);
							vis_offset++;
							if(vis_offset==75)
								vis_offset=0;
							break;
					}
					if(cfg.player_shaded)
						svis_set_data(mainwin_svis,vis_data);
					else
						vis_set_data(mainwin_vis,vis_data);
				}
				if(cfg.player_shaded)
					svis_timeout_func(mainwin_svis);
				else
					vis_timeout_func(mainwin_vis);
			}
			else
				prev_type=INPUT_VIS_OFF;

			if(cfg.timer_mode==TIMER_REMAINING)
			{
				if(length!=-1)
				{
					number_set_number(mainwin_minus_num,11);
					t=length-time;
					stime_prefix = '-';
				}
				else
				{
					number_set_number(mainwin_minus_num,10);
					t=time;
					stime_prefix = ' ';
				}
			}
			else
			{
				number_set_number(mainwin_minus_num,10);
				t=time;
				stime_prefix = ' ';
			}
			t/=1000;
			number_set_number(mainwin_10min_num,t/600);
			number_set_number(mainwin_min_num,(t/60)%10);
			number_set_number(mainwin_10sec_num,(t/10)%6);
			number_set_number(mainwin_sec_num,t%10);
			
			if(!mainwin_sposition->hs_pressed)
			{
				tmp = g_strdup_printf("%c%2.2d",stime_prefix,t/60);
				textbox_set_text(mainwin_stime_min,tmp);
				g_free(tmp);

				tmp = g_strdup_printf("%2.2d",t%60);
				textbox_set_text(mainwin_stime_sec,tmp);
				g_free(tmp);
			}
			
			time/=1000;
			length/=1000;
			if(length>0)
			{
				if (time>length)
				{
					hslider_set_position(mainwin_position,219);
					hslider_set_position(mainwin_sposition,13);
				}
				else
				{
					hslider_set_position(mainwin_position,(time*219)/length);
					hslider_set_position(mainwin_sposition,((time*12)/length)+1);
				}
			}
			else
			{
				hslider_set_position(mainwin_position,0);
				hslider_set_position(mainwin_sposition,1);
			}
		}
		
	}
	if(round==5 && (cfg.get_info_on_load || cfg.get_info_on_demand))
	{
		playlist_get_info_iteration();
		round=0;
	}
	
	draw_main_window(mainwin_force_redraw);
	read_volume(VOLSET_UPDATE);
	mainwin_force_redraw=FALSE;
	draw_playlist_window(FALSE);
	draw_equalizer_window(FALSE);
	
	if(mainwin_title_text)
	{
		gtk_window_set_title(GTK_WINDOW(mainwin),mainwin_title_text);
		g_free(mainwin_title_text);
		mainwin_title_text=NULL;
	}
	
	round++;
	
	return TRUE;
	
}

struct option long_options[]=
{
	{"help",0,0,0},
	{"session",1,0,0},
	{"rew",0,0,0},
	{"play",0,0,0},
	{"pause",0,0,0},
	{"stop",0,0,0},
	{"fwd",0,0,0},
	{"enqueue",0,0,0},
	{"version",0,0,0},
	{0,0,0,0}    
};


void display_usage(void)
{
    fprintf( stderr, "\nUsage: x11amp [options] [files] ...\n\n\
Options:\n\
--------\n\n\
-h, --help              Display this text and exit.\n\
-n, --session		Select X11Amp session (Default: 0)\n\
-r, --rew               Skip backwards in playlist\n\
-p, --play		Start playing current playlist\n\
-u, --pause		Pause current song\n\
-s, --stop		Stop current song\n\
-f, --fwd               Skip forward in playlist\n\
-e, --enqueue		Don't clear the playlist\n\
-v, --version           Print version number and exit.\n\
-z                      Start without visualization.\n");


	exit(0);
}
	
void parse_cmd_line(int argc,char **argv,gboolean remote)
{
	gint c,o,session=0,i;
	gboolean do_rew=FALSE,do_play=FALSE,do_pause=FALSE,do_stop=FALSE,do_fwd=FALSE,enqueue=FALSE,do_vis=TRUE;
	gchar *filename,*tmp;
	GList *playlist=NULL,*node;
	struct stat statbuf;
	gchar *ext;
	
	while((c=getopt_long(argc,argv,"hn:rpusfevz",long_options,&o))!=-1)
	{
		switch(c)
		{
			case	0:
				switch(o)
				{
					case	0:
						display_usage();
						break;
					case	1:
						session=atoi(optarg);
						break;
					case	2:
						do_rew=TRUE;
						break;
					case	3:
						do_play=TRUE;
						break;
					case	4:
						do_pause=TRUE;
						break;
					case	5:
						do_stop=TRUE;
						break;
					case	6:
						do_fwd=TRUE;
						break;
					case	7:
						enqueue=TRUE;
						break;
					case	8:
						printf("%s %s\n",PACKAGE,VERSION);
						exit(0);
						break;
                                        case 9:
                                          do_vis=FALSE;
                                          break;
                                          

				}
				break;
			case	'h':
				display_usage();
				break;
			case	'n':
				session=atoi(optarg);
				break;
			case	'r':
				do_rew=TRUE;
				break;
			case	'p':
				do_play=TRUE;
				break;
			case	'u':
				do_pause=TRUE;
				break;
			case	's':
				do_stop=TRUE;
				break;
			case	'f':
				do_fwd=TRUE;
				break;
			case	'e':
				enqueue=TRUE;
				break;
			case	'z':
				do_vis=FALSE;
				break;
			case	'v':
				printf("%s %s\n",PACKAGE,VERSION);
				exit(0);
				break;
		}
	}
	if(!remote&&!enqueue&&argc-optind>0)
		playlist_clear();
	for(i=optind;i<argc;i++)
	{
		if(argv[i][0]=='/'||strstr(argv[i],"://"))
			filename=g_strdup(argv[i]);
		else
		{
			filename=g_strconcat(tmp=g_get_current_dir(),"/",argv[i],NULL);
			g_free(tmp);
		}
		if(remote)
			playlist=g_list_append(playlist,filename);
		else
		{
			playlist_add_url_string(filename);
			start_playing=TRUE;
			g_free(filename);
		}
	}
	if(remote)
	{
		if(playlist)
		{
			if(!enqueue) x11amp_remote_playlist_clear(session);
			x11amp_remote_playlist_add(session,playlist);
			if(!enqueue) x11amp_remote_play(session);
			node=playlist;
			while(node)
			{
				g_list_free(node->data);
				node=node->next;
			}
			g_list_free(playlist);
		}
		if(do_rew)
			x11amp_remote_playlist_prev(session);
		if(do_play)
			x11amp_remote_play(session);
		if(do_pause)
			x11amp_remote_pause(session);
		if(do_stop)
			x11amp_remote_stop(session);
		if(do_fwd)
			x11amp_remote_playlist_next(session);
	}	
        if ( !do_vis )
          mainwin_vis_set_type( VIS_OFF );
}
			
int main(int argc,char **argv)
{
	gchar *filename,*ext;
	gint i,x,y;
		
	srand(time(NULL));
	
	read_config();
	
	if(!setup_ctrlsocket())
	{
		parse_cmd_line(argc,argv,TRUE);
		exit(0);
	}
	
	
	gtk_init(&argc,&argv);
	gdk_rgb_init();
	
	init_plugins();

	
	/*
	 * Why doesn't GTK 1.1.5 have GTK_HAVE_FEATURES_1_1_5 defined?! :/
	 */

	
	root_window=gdk_window_foreign_new(GDK_ROOT_WINDOW());
#if (GTK_MAJOR_VERSION>=1) && (GTK_MINOR_VERSION==1) && (GTK_MICRO_VERSION>=5) && (GTK_MICRO_VERSION<=7)
	mainwin=gtk_draw_window_new(GTK_WINDOW_TOPLEVEL);
#else
	mainwin=gtk_window_new(GTK_WINDOW_TOPLEVEL);
#ifdef GTK_HAVE_FEATURES_1_1_8
	gtk_widget_set_app_paintable(mainwin,TRUE);
#endif
#endif
	gtk_window_set_title(GTK_WINDOW(mainwin),"X11Amp");
	gtk_window_set_policy(GTK_WINDOW(mainwin),FALSE,FALSE,TRUE);
	gtk_window_set_wmclass(GTK_WINDOW(mainwin),"X11Amp_Player","x11amp");
	
	gtk_widget_set_events (mainwin,GDK_FOCUS_CHANGE_MASK|GDK_BUTTON_MOTION_MASK|GDK_BUTTON_PRESS_MASK|GDK_BUTTON_RELEASE_MASK|GDK_STRUCTURE_MASK);
	gtk_widget_realize(mainwin);
	if(cfg.doublesize)
		gtk_widget_set_usize(mainwin,550,cfg.player_shaded ? 28 : 232);
	else
		gtk_widget_set_usize(mainwin,275,cfg.player_shaded ? 14 : 116);
	gdk_window_set_decorations(mainwin->window,0);
	mainwin_accel=gtk_accel_group_new();
	global_accel=gtk_accel_group_new();
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/gtkrc",NULL);
	gtk_rc_init();
	gtk_rc_parse(filename);
	g_free(filename);
	
	
	setup_main_window();
	playlistwin_create();
	equalizerwin_create();
	init_skins();
	load_skin(cfg.skin);
	create_popups();
	create_prefs_window();
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/x11amp.m3u",NULL);
	playlist_load(filename);
	g_free(filename);
	if(cfg.save_playlist_position)
		playlist_set_position(cfg.playlist_position);
	parse_cmd_line(argc,argv,FALSE);
	mainwin_set_info_text();
	
	gtk_window_add_accel_group(GTK_WINDOW(mainwin),mainwin_accel);
	gtk_window_add_accel_group(GTK_WINDOW(mainwin),global_accel);
	gtk_window_add_accel_group(GTK_WINDOW(playlistwin),global_accel);
	gtk_window_add_accel_group(GTK_WINDOW(equalizerwin),global_accel);
	
	gtk_signal_connect(GTK_OBJECT(mainwin),"button_press_event",GTK_SIGNAL_FUNC(mainwin_press),NULL);
	gtk_signal_connect(GTK_OBJECT(mainwin),"button_release_event",GTK_SIGNAL_FUNC(mainwin_release),NULL);
	gtk_signal_connect(GTK_OBJECT(mainwin),"motion_notify_event",GTK_SIGNAL_FUNC(mainwin_motion),NULL);
	gtk_signal_connect(GTK_OBJECT(mainwin),"focus_in_event",GTK_SIGNAL_FUNC(mainwin_focus_in),NULL);
	gtk_signal_connect(GTK_OBJECT(mainwin),"focus_out_event",GTK_SIGNAL_FUNC(mainwin_focus_out),NULL);
	gtk_signal_connect(GTK_OBJECT(mainwin),"configure_event",GTK_SIGNAL_FUNC(mainwin_configure),NULL);
	gtk_drag_dest_set(mainwin,GTK_DEST_DEFAULT_ALL,drop_types,1,GDK_ACTION_COPY);
	gtk_signal_connect(GTK_OBJECT(mainwin),"drag_data_received",GTK_SIGNAL_FUNC(mainwin_drag_data_received),NULL);
		
        /* AUTOFLUSH - got rid of this so the normal 
                       x11amp window doesn't show up.
                       Same goes for playlist win and Equilizer.	
	if(cfg.playlist_visible) playlistwin_show();
	if(cfg.equalizer_visible) equalizerwin_show();
        gtk_widget_show(mainwin); 
        */
	if(cfg.player_x!=-1&&cfg.save_window_position)
		/*
		gtk_widget_set_uposition(mainwin,cfg.player_x,cfg.player_y);
		*/
		gdk_window_move(mainwin->window,cfg.player_x,cfg.player_y);
	gdk_flush();
	
	/* Check if always on top is available */
	check_wm_hints();
	set_always(mainwin_menurow->mr_always_selected);

	draw_main_window(TRUE);
	/*
	 * There seems to be something strange going on with timeouts, if this is set to 20
	 * it starts running at 30 (Intel Pentium II, Kernel 2.2.0), if it is set to 10 it 
	 * runs at 20, this may cause problems on timing the visualization on other systems so
	 * there is a lame check in vis_update_func to make sure that the visualization don't get 
	 * updated to often
	 */
	
	mainwin_timeout_tag=gtk_timeout_add(10,idle_func,NULL); 
	bitrate=0;
	frequency=0;
	numchannels=0;
	if(start_playing)
		playlist_play();	
	gtk_main();
	
	return 0;

}
