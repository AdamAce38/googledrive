/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

struct OutputPluginData *op_data;

OutputPlugin *get_current_output_plugin(void)
{
	return op_data->current_output_plugin;
}

void set_current_output_plugin(int i)
{
	op_data->current_output_plugin=(OutputPlugin *)g_list_nth(op_data->output_list,i)->data;
}

GList *get_output_list(void)
{
	return op_data->output_list;
}

void output_about(void)
{
	if(op_data->current_output_plugin&&op_data->current_output_plugin->about) 
		op_data->current_output_plugin->about();
}

void output_configure(void)
{
	if(op_data->current_output_plugin&&op_data->current_output_plugin->configure)
		op_data->current_output_plugin->configure();
}

void output_get_volume(int *l,int *r)
{
	if(op_data->current_output_plugin&&op_data->current_output_plugin->get_volume) 
		op_data->current_output_plugin->get_volume(l,r);
	else
		(*l)=(*r)=-1;
}

void output_set_volume(int l,int r)
{
	if(op_data->current_output_plugin&&op_data->current_output_plugin->set_volume) 
		op_data->current_output_plugin->set_volume(l,r);
}

