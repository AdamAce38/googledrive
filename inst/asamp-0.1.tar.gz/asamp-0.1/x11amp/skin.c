/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"
#include "defskin/main.xpm"
#include "defskin/cbuttons.xpm"
#include "defskin/titlebar.xpm"
#include "defskin/shufrep.xpm"
#include "defskin/text.xpm"
#include "defskin/volume.xpm"
#include "defskin/balance.xpm"
#include "defskin/monoster.xpm"
#include "defskin/playpaus.xpm"
#include "defskin/nums_ex.xpm"
#include "defskin/posbar.xpm"
#include "defskin/pledit.xpm"
#include "defskin/eqmain.xpm"
		
Skin *skin;		

static gint skin_default_viscolor[24][3]=
{
	0,0,0,
	24,33,41, 
	239,49,16,
	206,41,16,
	214,90,0, 
	214,102,0,
	214,115,0,
	198,123,8,
	222,165,24,
	214,181,33,
	189,222,41,
	148,222,33,
	41,206,16,
	50,190,16,
	57,181,16,
	49,156,8,
	41,148,0,
	24,132,8,
	255,255,255,
	214,214,222,
	181,189,189,
	160,170,175,  
	148,156,165,  
	150, 150, 150,
};

		
void init_skins(void)
{
	gint i;
	
	GdkWindow *rootwin;
	GdkGC *gc;
	GdkColor pattern;
	
	rootwin=gdk_window_foreign_new(GDK_ROOT_WINDOW());
	skin=(Skin *)g_malloc0(sizeof(Skin));
	skin->def_main=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_main);
	skin->def_cbuttons=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_cbuttons);
	skin->def_titlebar=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_titlebar);
	skin->def_shufrep=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_shufrep);
	skin->def_text=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_text);
	skin->def_volume=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_volume);
	skin->def_balance=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_balance);
	skin->def_monostereo=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_monoster);
	skin->def_playpause=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_playpaus);
	skin->def_numbers=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_nums_ex);
	skin->def_posbar=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_posbar);
	skin->def_pledit=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_pledit);
	skin->def_eqmain=gdk_pixmap_create_from_xpm_d(rootwin,NULL,NULL,skin_eqmain);

	skin->def_mask=gdk_pixmap_new(rootwin,550,232,1);
	gc=gdk_gc_new(skin->def_mask);
	pattern.pixel=1;
	gdk_gc_set_foreground(gc,&pattern);
	gdk_draw_rectangle(skin->def_mask,gc,TRUE,0,0,550,232);
	gdk_gc_destroy(gc);
	
	gdk_window_unref(rootwin);
	skin->def_pledit_normal.red=0x0000;
	skin->def_pledit_normal.green=0xFFFF;
	skin->def_pledit_normal.blue=0x0000;
	gdk_color_alloc(gdk_colormap_get_system(),&skin->def_pledit_normal);
	skin->def_pledit_current.red=0xFFFF;
	skin->def_pledit_current.green=0xFFFF;
	skin->def_pledit_current.blue=0xFFFF;
	gdk_color_alloc(gdk_colormap_get_system(),&skin->def_pledit_current);
	skin->def_pledit_normalbg.red=0x0000;
	skin->def_pledit_normalbg.green=0x0000;
	skin->def_pledit_normalbg.blue=0x0000;
	gdk_color_alloc(gdk_colormap_get_system(),&skin->def_pledit_normalbg);
	skin->def_pledit_selectedbg.red=0x00FF;
	skin->def_pledit_selectedbg.green=0x00FF;
	skin->def_pledit_selectedbg.blue=0xFFFF;
	gdk_color_alloc(gdk_colormap_get_system(),&skin->def_pledit_selectedbg);
	for(i=0;i<24;i++)
	{
		skin->vis_color[i][0]=skin_default_viscolor[i][0];
		skin->vis_color[i][1]=skin_default_viscolor[i][1];
		skin->vis_color[i][2]=skin_default_viscolor[i][2];
	}
	create_skin_window();
}

GdkColor *load_skin_color(const gchar *path,const gchar *file,const gchar *section,const gchar *key)
{
	char *filename,*value,*tmp;
	GdkColor *color=NULL;
	int i,c;

	filename=find_file_recursively(path,file);
	if(filename)
	{
		color=g_malloc(sizeof(GdkColor));
		value=read_ini_string(filename,section,key);
		g_strchug(g_strchomp(value));
		if(value[0]=='#')
			sscanf(value,"#%2x%2x%2x",&color->red,&color->green,&color->blue);
		else
			sscanf(value,"%2x%2x%2x",&color->red,&color->green,&color->blue);
		color->red=(color->red<<8)|0xFF;
		color->green=(color->green<<8)|0xFF;
		color->blue=(color->blue<<8)|0xFF;
		gdk_color_alloc(gdk_colormap_get_system(),color);
		g_free(value);
		g_free(filename);
	}
	return color;
}		
		
		

GdkPixmap *load_skin_pixmap(const gchar *path,const gchar *file)
{
	char *filename;
	GdkPixmap *pixmap=NULL;
	
	filename=find_file_recursively(path,file);
	if(filename)
	{
		pixmap=read_bmp(filename);
		g_free(filename);
	}
	return pixmap;
}

		

GdkBitmap* skin_create_transparent_mask(const gchar *path,const gchar *file,const gchar *section,GdkWindow *window, gint width, gint height,gboolean doublesize)
{
	gchar *filename;
	
	GdkBitmap *mask;
	GdkGC *gc;
	GdkColor pattern;
	GdkPoint *gpoints;
	
	gboolean created_mask=FALSE,inited_mask=FALSE;
	GArray *num,*point;
	gint i,j,k;
	
	mask=gdk_pixmap_new(window,width,height,1);
	gc=gdk_gc_new(mask);

	if(path)
	{
		filename=find_file_recursively(path,file);
		if(filename)
		{
			if((num=read_ini_array(filename,section,"NumPoints"))!=NULL)
			{
				if((point=read_ini_array(filename,section,"PointList"))!=NULL)
				{
					
					
					pattern.pixel=0;
					gdk_gc_set_foreground(gc,&pattern);
					gdk_draw_rectangle(mask,gc,TRUE,0,0,width,height);
					pattern.pixel=1;
					gdk_gc_set_foreground(gc,&pattern);
					inited_mask=TRUE;

					j=0;
					for(i=0;i<num->len;i++)
					{
						if((point->len-j)>=(g_array_index(num,gint,i)*2))
						{
							created_mask=TRUE;
							gpoints=g_malloc(g_array_index(num,gint,i)*sizeof(GdkPoint));
							for(k=0;k<g_array_index(num,gint,i);k++)
							{
								gpoints[k].x=g_array_index(point,gint,j+k*2)*(1+doublesize);
								gpoints[k].y=g_array_index(point,gint,j+k*2+1)*(1+doublesize);
							}
							j+=k*2;
							gdk_draw_polygon(mask,gc,TRUE,gpoints,g_array_index(num,gint,i));
							g_free(gpoints);
						}
					}
					g_array_free(num,TRUE);
				}
				g_array_free(point,TRUE);
			}
			g_free(filename);
		}
	}
	if(!inited_mask)
		return NULL;
	
	if(!created_mask)
		gdk_draw_rectangle(mask,gc,TRUE,0,0,width,height);

	gdk_gc_destroy(gc);

	return mask;
}

void load_skin_viscolor(const gchar *path,const gchar *file)
{
	FILE *f;
	gint i,c,x,y;
	gchar line[256],tmp[10],*filename;
	
	for(i=0;i<24;i++)
	{
		skin->vis_color[i][0]=skin_default_viscolor[i][0];
		skin->vis_color[i][1]=skin_default_viscolor[i][1];
		skin->vis_color[i][2]=skin_default_viscolor[i][2];
	}
	
	filename=find_file_recursively(path,file);
	if(filename)
	{
		if(f=fopen(filename,"r"))
		{
			for(i=0;i<24;i++)
			{
				if(fgets(line,255,f))
				{
					x=0;
					for(c=0;c<3;c++)
					{
						if(line[x]==','||line[x]==' ')
							while(line[x]==','||line[x]==' ')
								x++;
						y=0;
						while(line[x]>='0'&&line[x]<='9')
							tmp[y++]=line[x++];
						tmp[y]='\0';
						if(y)
							skin->vis_color[i][c]=atoi(tmp);
					}
				}
				else
					break;				

			}
			fclose(f);
		}
		g_free(filename);
	}
}

void free_skin(void)
{
	gint i;
	if(skin->main) gdk_pixmap_unref(skin->main);
	if(skin->cbuttons) gdk_pixmap_unref(skin->cbuttons);
	if(skin->titlebar) gdk_pixmap_unref(skin->titlebar);
	if(skin->shufrep) gdk_pixmap_unref(skin->shufrep);
	if(skin->text) gdk_pixmap_unref(skin->text);
	if(skin->volume) gdk_pixmap_unref(skin->volume);
	if(skin->balance) gdk_pixmap_unref(skin->balance);
	if(skin->monostereo) gdk_pixmap_unref(skin->monostereo);
	if(skin->playpause) gdk_pixmap_unref(skin->playpause);
	if(skin->numbers) gdk_pixmap_unref(skin->numbers);
	if(skin->posbar) gdk_pixmap_unref(skin->posbar);
	if(skin->pledit) gdk_pixmap_unref(skin->pledit);
	if(skin->eqmain) gdk_pixmap_unref(skin->eqmain);
  	if(skin->mask_main) gdk_bitmap_unref(skin->mask_main); 
  	if(skin->mask_eq) gdk_bitmap_unref(skin->mask_eq); 
  	if(skin->mask_main_ds) gdk_bitmap_unref(skin->mask_main_ds); 
  	if(skin->mask_eq_ds) gdk_bitmap_unref(skin->mask_eq_ds); 
	if(skin->mask_shade) gdk_bitmap_unref(skin->mask_shade);
	if(skin->mask_shade_ds) gdk_bitmap_unref(skin->mask_shade_ds);
	if(skin->pledit_normal) g_free(skin->pledit_normal);
	if(skin->pledit_current) g_free(skin->pledit_current);
	if(skin->pledit_normalbg) g_free(skin->pledit_normalbg);
	if(skin->pledit_selectedbg) g_free(skin->pledit_selectedbg);
	skin->main=NULL;
	skin->cbuttons=NULL;
	skin->titlebar=NULL;
	skin->shufrep=NULL;
	skin->text=NULL;
	skin->volume=NULL;
	skin->balance=NULL;
	skin->monostereo=NULL;
	skin->playpause=NULL;
	skin->numbers=NULL;
	skin->posbar=NULL;
	skin->pledit=NULL;
	skin->eqmain=NULL;
	skin->pledit_normal=NULL;
	skin->pledit_current=NULL;
	skin->pledit_normalbg=NULL;
	skin->pledit_selectedbg=NULL;
  	skin->mask_main=NULL; 
  	skin->mask_eq=NULL;
  	skin->mask_main_ds=NULL; 
  	skin->mask_eq_ds=NULL;
	skin->mask_shade=NULL;
	skin->mask_shade_ds=NULL;
	for(i=0;i<24;i++)
	{
		skin->vis_color[i][0]=skin_default_viscolor[i][0];
		skin->vis_color[i][1]=skin_default_viscolor[i][1];
		skin->vis_color[i][2]=skin_default_viscolor[i][2];
	}
}

void load_skin(const gchar *path)
{
	char *ending,*tmp,*tempdir,*unzip,*tar,*color;
	if(skin->path&&path)
		if(!strcasecmp(skin->path,path))
				return;
	if(!skin->path&&!path)
		return;
	free_skin();
	if(path)
	{
		if(strncmp(path,"/tmp",4))
		{
			skin->path=g_realloc(skin->path,strlen(path)+1);
			strcpy(skin->path,path);
		}
		ending=strrchr(path,'.');
		if(ending) {
		  if(!strcasecmp(ending,".zip") || !strcasecmp(ending, ".tgz") ||
		     !strcasecmp(ending, ".gz") || !strcasecmp(ending, ".bz2") ||
		     !strcasecmp(ending, ".tar")) {
		    
		    tempdir=tempnam(NULL,NULL);
		    
		    unzip=getenv("UNZIPCMD");
		    if(!unzip) unzip="unzip";
		    tar = getenv("TARCMD");
		    if(!tar) tar="tar";
		    if(!strcasecmp(ending, ".zip")) {
		      tmp=g_strdup_printf("%s >/dev/null -o -j \"%s\" -d %s",unzip,path,tempdir);
		    }
		    if(!strcasecmp(ending, ".tgz") || !strcasecmp(ending, ".gz")) {
		      tmp=g_strdup_printf("%s >/dev/null xzf \"%s\" -C %s", tar,path,tempdir);
		      mkdir(tempdir, 0x1ed);  /* Permissions: 755 */
		    }
		    if(!strcasecmp(ending, ".bz2")) {
		      tmp=g_strdup_printf("%s >/dev/null xIf \"%s\" -C %s", tar,path,tempdir);
		      mkdir(tempdir, 0x1ed);  /* Permissions: 755 */
		    }
		    if(!strcasecmp(ending, ".tar")) {
		      tmp=g_strdup_printf("%s >/dev/null xf \"%s\" -C %s", tar,path,tempdir);
		      mkdir(tempdir, 0x1ed);  /* Permissions: 755 */
		    }
		    system(tmp);
		    g_free(tmp);
		    load_skin(tempdir);
		    del_directory(tempdir);
		    free(tempdir);
		    return;
		  }
		}
		skin->main=load_skin_pixmap(path,"main.bmp");
		skin->cbuttons=load_skin_pixmap(path,"cbuttons.bmp");
		skin->titlebar=load_skin_pixmap(path,"titlebar.bmp");
		skin->shufrep=load_skin_pixmap(path,"shufrep.bmp");
		skin->text=load_skin_pixmap(path,"text.bmp");
		skin->volume=load_skin_pixmap(path,"volume.bmp");
		skin->balance=load_skin_pixmap(path,"balance.bmp");
		skin->monostereo=load_skin_pixmap(path,"monoster.bmp");
		skin->playpause=load_skin_pixmap(path,"playpaus.bmp");
		skin->numbers=load_skin_pixmap(path,"nums_ex.bmp");
		if(!skin->numbers) skin->numbers=load_skin_pixmap(path,"numbers.bmp");
		skin->posbar=load_skin_pixmap(path,"posbar.bmp");
		skin->pledit=load_skin_pixmap(path,"pledit.bmp");
		skin->eqmain=load_skin_pixmap(path,"eqmain.bmp");
		skin->pledit_normal=load_skin_color(path,"pledit.txt","text","normal");
		skin->pledit_current=load_skin_color(path,"pledit.txt","text","current");
		skin->pledit_normalbg=load_skin_color(path,"pledit.txt","text","normalbg");
		skin->pledit_selectedbg=load_skin_color(path,"pledit.txt","text","selectedbg");
		skin->mask_main=skin_create_transparent_mask(path,"region.txt","Normal",mainwin->window,275,116,FALSE);
		skin->mask_main_ds=skin_create_transparent_mask(path,"region.txt","Normal",mainwin->window,550,232,TRUE);
		skin->mask_eq=skin_create_transparent_mask(path,"region.txt","Equalizer",equalizerwin->window,275,116,FALSE);
		skin->mask_eq_ds=skin_create_transparent_mask(path,"region.txt","Equalizer",equalizerwin->window,550,232,TRUE);
		skin->mask_shade=skin_create_transparent_mask(path,"region.txt","WindowShade",mainwin->window,275,14,FALSE);
		skin->mask_shade_ds=skin_create_transparent_mask(path,"region.txt","WindowShade",mainwin->window,550,28,TRUE);
		load_skin_viscolor(path,"viscolor.txt");
	}
	else
	{
		if(skin->path) g_free(skin->path);
		skin->path=NULL;
	}

	if(cfg.doublesize)
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.player_shaded?SKIN_MASK_SHADE_DS:SKIN_MASK_MAIN_DS),0,0);
	else
		gdk_window_shape_combine_mask(mainwin->window,get_skin_pixmap(cfg.player_shaded?SKIN_MASK_SHADE:SKIN_MASK_MAIN),0,0);
	if(cfg.eq_doublesize_linked&cfg.doublesize)
		gdk_window_shape_combine_mask(equalizerwin->window,get_skin_pixmap(SKIN_MASK_EQ_DS),0,0);
	else
		gdk_window_shape_combine_mask(equalizerwin->window,get_skin_pixmap(SKIN_MASK_EQ),0,0);

	draw_main_window(TRUE);
	draw_playlist_window(TRUE);
	draw_equalizer_window(TRUE);
	playlistwin_update_list();
}

void cleanup_skins(void)
{
	free_skin();
	free(skin);
}

GdkPixmap *get_skin_pixmap(SkinIndex si)
{	
	GdkPixmap *ret;
	switch(si)
	{
		case	SKIN_MAIN:
				ret=skin->main;
				if(!ret) ret=skin->def_main;
				break;
		case	SKIN_CBUTTONS:
				ret=skin->cbuttons;
				if(!ret) ret=skin->def_cbuttons;
				break;
		case	SKIN_TITLEBAR:
				ret=skin->titlebar;
				if(!ret) ret=skin->def_titlebar;
				break;
		case	SKIN_SHUFREP:
				ret=skin->shufrep;
				if(!ret) ret=skin->def_shufrep;
				break;
		case	SKIN_TEXT:
				ret=skin->text;
				if(!ret) ret=skin->def_text;
				break;
		case	SKIN_VOLUME:
				ret=skin->volume;
				if(!ret) ret=skin->def_volume;
				break;
		case	SKIN_BALANCE:
				ret=skin->balance;
				if(!ret) 
				{
					if(!skin->path)
						ret=skin->def_balance;
					else
						ret=get_skin_pixmap(SKIN_VOLUME);
				}
				break;
		case	SKIN_MONOSTEREO:
				ret=skin->monostereo;
				if(!ret) ret=skin->def_monostereo;
				break;
		case	SKIN_PLAYPAUSE:
				ret=skin->playpause;
				if(!ret) ret=skin->def_playpause;
				break;
		case	SKIN_NUMBERS:
				ret=skin->numbers;
				if(!ret) ret=skin->def_numbers;
				break;
		case	SKIN_POSBAR:
				ret=skin->posbar;
				if(!ret) ret=skin->def_posbar;
				break;
		case	SKIN_PLEDIT:
				ret=skin->pledit;
				if(!ret) ret=skin->def_pledit;
				break;
		case	SKIN_EQMAIN:
				ret=skin->eqmain;
				if(!ret) ret=skin->def_eqmain;
				break;
		case	SKIN_MASK_MAIN:
				ret=skin->mask_main;
				if(!ret) ret=skin->def_mask;
				break;
		case	SKIN_MASK_MAIN_DS:
				ret=skin->mask_main_ds;
				if(!ret) ret=skin->def_mask;
				break;
		case	SKIN_MASK_EQ:
				ret=skin->mask_eq;
				if(!ret) ret=skin->def_mask;
				break;
		case	SKIN_MASK_EQ_DS:
				ret=skin->mask_eq_ds;
				if(!ret) ret=skin->def_mask;
				break;
		case	SKIN_MASK_SHADE:
				ret=skin->mask_shade;
				if(!ret) ret=skin->def_mask;
				break;
		case	SKIN_MASK_SHADE_DS:
				ret=skin->mask_shade_ds;
				if(!ret) ret=skin->def_mask;
				break;
	}
	return ret;
}

GdkColor *get_skin_color(SkinIndex si)
{
	GdkColor *ret;
	switch(si)
	{
		case	SKIN_PLEDIT_NORMAL:
			ret=skin->pledit_normal;
			if(!ret) ret=&skin->def_pledit_normal;
			break;
		case	SKIN_PLEDIT_CURRENT:
			ret=skin->pledit_current;
			if(!ret) ret=&skin->def_pledit_current;
			break;
		case	SKIN_PLEDIT_NORMALBG:
			ret=skin->pledit_normalbg;
			if(!ret) ret=&skin->def_pledit_normalbg;
			break;
		case	SKIN_PLEDIT_SELECTEDBG:
			ret=skin->pledit_selectedbg;
			if(!ret) ret=&skin->def_pledit_selectedbg;
			break;
	}
	return ret;
}

void get_skin_viscolor(guchar vis_color[24][3])
{
	gint i;
	for(i=0;i<24;i++)
	{
		vis_color[i][0]=skin->vis_color[i][0];
		vis_color[i][1]=skin->vis_color[i][1];
		vis_color[i][2]=skin->vis_color[i][2];
	}
}

gboolean is_new_skin(gchar *old_skin)
{
	if(!old_skin&&skin->path)
		return TRUE;
	if(old_skin&&!skin->path)
		return TRUE;
	if(!old_skin&&!skin->path)
		return FALSE;
	if(strcmp(old_skin,skin->path))
		return TRUE;
	return FALSE;
}
