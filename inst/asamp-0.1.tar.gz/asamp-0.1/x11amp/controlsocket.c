/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

/*
 * This is just a *quick* implementation, it will change in the future to something more
 * sophisticated
 */


extern gint bitrate,frequency,numchannels;

gint session_id=0;
static gint ctrl_fd=0;
static gchar *socket_name;

static void *ctrlsocket_func(void *);
static pthread_t ctrlsocket_thread;
static gboolean going = TRUE;

gboolean setup_ctrlsocket(void)
{
	struct sockaddr_un saddr;
	gboolean retval=FALSE;
	gint i,fd,dummy;
    
	if((ctrl_fd=socket(AF_UNIX,SOCK_STREAM,0))!=-1)
	{
		for(i=0;;i++)
		{
			saddr.sun_family=AF_UNIX;
			sprintf(saddr.sun_path,"%s/.x11amp/x11amp_ctrl.%d",g_get_home_dir(),i);
			if(!(fd=x11amp_connect_to_session(i)))
				unlink(saddr.sun_path);
			else
			{
				dummy=0;
				write(fd,&dummy,sizeof(gint));
				read(fd,&dummy,sizeof(gint));
				read(fd,&dummy,sizeof(gint));
				close(fd);
				if(cfg.allow_multiple_instances)
					continue;
			}
			if(bind(ctrl_fd,(struct sockaddr *)&saddr,sizeof(saddr))!=-1)
			{
				session_id=i;
				listen(ctrl_fd,100);
				going = TRUE;

				pthread_create(&ctrlsocket_thread,NULL,ctrlsocket_func,NULL);
				socket_name=g_strdup(saddr.sun_path);
				retval=TRUE;
				break;
			}
			else if(!cfg.allow_multiple_instances||errno!=EADDRINUSE)
				break;
		}
				
	}
	if(!retval)
	{
		close(ctrl_fd);
		ctrl_fd=0;
	}
	return retval;
}

void cleanup_ctrlsocket(void)
{
	if(ctrl_fd)
	{
		going = FALSE;
		pthread_join(ctrlsocket_thread,NULL);
		close(ctrl_fd);
		unlink(socket_name);
		g_free(socket_name);
		ctrl_fd=0;
	}
}

void *ctrlsocket_func(void *arg)
{
	fd_set set;
	struct timeval tv,tv_def;
	struct sockaddr_un saddr;
	gint fd,len,vl,vr,temp,num,length,i,cmd;
	gboolean tbool;
	gchar *filename,*ext;
	GList *list;
	
	tv_def.tv_sec=0;
	tv_def.tv_usec=25000;
	while(going)
	{
		FD_ZERO(&set);
		FD_SET(ctrl_fd,&set);
		tv.tv_sec = 0;
		tv.tv_usec = 100000;
		if(select(ctrl_fd+1,&set,NULL,NULL,&tv) > 0)
		{
			len=sizeof(saddr);
			if((fd=accept(ctrl_fd,(struct sockaddr *)&saddr,&len))!=-1)
			{
				FD_ZERO(&set);
				FD_SET(fd,&set);
				tv=tv_def;
				if(!select(fd+1,&set,NULL,NULL,&tv))
				{
					close(fd);
					return;
				}
				read(fd,&cmd,sizeof(gint));
				switch(cmd)
				{
					case	CMD_GET_VERSION:
						temp=0x09a3;
						write(fd,&temp,sizeof(gint));
						break;
					case	CMD_PLAYLIST_ADD:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&length,sizeof(gint));
						while(length>0)
						{
							filename=g_malloc0(length+1);
							tv=tv_def;
							if(!select(fd+1,&set,NULL,NULL,&tv))
							{
								close(fd);
								return;
							}
							read(fd,filename,length);
							*(filename+length)='\0';
							playlist_add_url_string(filename);
							g_free(filename);
							write(fd,&i,sizeof(gint));
							tv=tv_def;
							if(!select(fd+1,&set,NULL,NULL,&tv))
							{
								close(fd);
								return;
							}
							read(fd,&length,sizeof(gint));
						}
						playlistwin_update_list(); 
						break;
					case	CMD_PLAY:
						if(get_input_paused())
							input_pause();
						else if(get_playlist_length())
							playlist_play();
						else
							mainwin_eject_pushed();
						break;
					case	CMD_PAUSE:
						input_pause();
						break;
					case	CMD_STOP:
						input_stop();
						mainwin_set_song_info(0,0,0);
						break;
					case	CMD_IS_PLAYING:
						tbool=get_input_playing();
						write(fd,&tbool,sizeof(gboolean));
						break;
					case	CMD_IS_PAUSED:
						tbool=get_input_paused();
						write(fd,&tbool,sizeof(gboolean));
						break;
					case	CMD_GET_PLAYLIST_POS:
						num=get_playlist_position();
						write(fd,&num,sizeof(gint));
						break;
					case	CMD_SET_PLAYLIST_POS:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&num,sizeof(gint));
						if(num>=0&&num<get_playlist_length())
							playlist_set_position(num);
						break;
					case	CMD_GET_PLAYLIST_LENGTH:
						num=get_playlist_length();
						write(fd,&num,sizeof(gint));
						break;
					case	CMD_PLAYLIST_CLEAR:
						playlist_clear();
						break;
					case	CMD_GET_OUTPUT_TIME:
						temp=input_get_time();
						write(fd,&temp,sizeof(gint));
						break;
					case	CMD_JUMP_TO_TIME:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&temp,sizeof(gint));
						if(temp>=0&&temp<=playlist_get_current_length())
							input_seek(temp/1000);
						break;
					case	CMD_GET_VOLUME:
						input_get_volume(&vl,&vr);
						write(fd,&vl,sizeof(gint));
						write(fd,&vr,sizeof(gint));
						break;
					case	CMD_SET_VOLUME:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&vl,sizeof(gint));
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&vr,sizeof(gint));
						if(vl>=0&&vl<=100&&vr>=0&&vr<=100)
							input_set_volume(vl,vr);
						break;
					case	CMD_GET_SKIN:
						length=(skin->path?strlen(skin->path):0);
						write(fd,&length,sizeof(gint));
						if(skin->path)
							write(fd,skin->path,length);
						break;
					case	CMD_SET_SKIN:
						filename=NULL;
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&length,sizeof(gint));
						if(length)
						{
							filename=g_malloc(length+1);
							tv=tv_def;
							if(!select(fd+1,&set,NULL,NULL,&tv))
							{
								close(fd);
								return;
							}
							read(fd,filename,length);
							*(filename+length)='\0';
						}
						load_skin(filename);
						if(length)
							g_free(filename);
						break;
					case	CMD_GET_PLAYLIST_FILE:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&i,sizeof(gint));
						list=g_list_nth(get_playlist(),i);
						filename=((PlaylistEntry *)list->data)->filename;
						length=strlen(filename);
						write(fd,&length,sizeof(gint));
						write(fd,filename,length);
						break;
					case	CMD_GET_PLAYLIST_TITLE:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&i,sizeof(gint));
						list=g_list_nth(get_playlist(),i);
						if(!((PlaylistEntry *)list->data)->title)
							input_get_song_info(((PlaylistEntry *)list->data)->filename,
							    &((PlaylistEntry *)list->data)->title,&((PlaylistEntry *)list->data)->length);
						filename=((PlaylistEntry *)list->data)->title;
						length=strlen(filename);
						write(fd,&length,sizeof(gint));
						write(fd,filename,length);
						break;
					case	CMD_GET_PLAYLIST_TIME:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&i,sizeof(gint));
						list=g_list_nth(get_playlist(),i);
						if(!((PlaylistEntry *)list->data)->title)
							input_get_song_info(((PlaylistEntry *)list->data)->filename,
							    &((PlaylistEntry *)list->data)->title,&((PlaylistEntry *)list->data)->length);
						temp=((PlaylistEntry *)list->data)->length;
						write(fd,&temp,sizeof(gint));
						break;
					case	CMD_GET_INFO:
						write(fd,&bitrate,sizeof(gint));
						write(fd,&frequency,sizeof(gint));
						write(fd,&numchannels,sizeof(gint));
						break;
					case	CMD_GET_EQ_DATA:
						/* write me! */
						break;
					case	CMD_SET_EQ_DATA:
						/* write me! */
						break;
					case	CMD_PL_WIN_TOGGLE:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&tbool,sizeof(gboolean));
						if(tbool)
							playlistwin_show();
						else
							playlistwin_hide();
						break;
					case	CMD_EQ_WIN_TOGGLE:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&tbool,sizeof(gboolean));
						if(tbool)
							equalizerwin_show();
						else
							equalizerwin_hide();
						break;
					case	CMD_SHOW_PREFS_BOX:
						show_prefs_window();
						break;
					case	CMD_TOGGLE_AOT:
						tv=tv_def;
						if(!select(fd+1,&set,NULL,NULL,&tv))
						{
							close(fd);
							return;
						}
						read(fd,&tbool,sizeof(gboolean));
						set_always(tbool);
						break;
					case	CMD_SHOW_ABOUT_BOX:
						break;
					case	CMD_EJECT:
						mainwin_eject_pushed();
						break;
					case	CMD_PLAYLIST_PREV:
						playlist_prev();
						break;
					case	CMD_PLAYLIST_NEXT:
						playlist_next();
						break;
					default:
						printf("Unknown socket command received\n");
				}
				cmd=0;
				write(fd,&cmd,sizeof(gint));
				close(fd);
			}
		}
	}
	pthread_exit(NULL);
}
