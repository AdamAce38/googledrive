/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef PLUGIN_H
#define PLUGIN_H

#include <glib.h>

typedef enum
{
	FMT_U8,FMT_S8,FMT_U16_LE,FMT_U16_BE,FMT_U16_NE,FMT_S16_LE,FMT_S16_BE,FMT_S16_NE
} AFormat;
	
typedef struct
{
	void	*handle;					/* Filled in by x11amp */
	char	*filename;					/* Filled in by x11amp */
	char	*description;					/* The description that is shown in the preferences box */
	void	(*init)(void);
	void	(*about)(void);					/* Show the about box */
	void	(*configure)(void);				/* Show the configuration dialog */
	void	(*get_volume)(int *l,int *r);
	void	(*set_volume)(int l,int r); 			/* Set the volume */
	int	(*open_audio)(AFormat fmt,int rate,int nch);	/* Open the device, if the device can't handle the given 
								   parameters the plugin is responsible for downmixing
								   the data to the right format before outputting it */
	void	(*write_audio)(void *ptr,int length);		/* The input plugin calls this to write data to the output 
								   buffer */
	void	(*close_audio)(void);				/* No comment... */
	void	(*flush)(int time);				/* Flush the buffer and set the plugins internal timers to time */
	void	(*pause)(short paused);				/* Pause or unpause the output */
	int	(*buffer_free)(void);				/* Return the amount of data that can be written to the buffer,
								two calls to this without a call to write_audio should make
								the plugin output audio directly */
	int	(*buffer_playing)(void);			/* Returns TRUE if the plugin currently is playing some audio,
								otherwise return FALSE */
	int	(*output_time)(void);				/* Return the current playing time */
	int	(*written_time)(void);				/* Return the length of all the data that has been written to
								   the buffer */
} OutputPlugin;

typedef struct
{
    void        *handle;                    /* Filled in by x11amp */
    char        *filename;                  /* Filled in by x11amp */
    char        *description;               /* The description that is shown in the preferences box */
    void		(*init)(void);				/* Called when the plugin is loaded */
	void		(*cleanup)(void);			/* Called when the plugin is unloaded */
	void        (*about)(void);             /* Show the about box */
    void        (*configure)(void);			/* Show the configure box */
    int         (*mod_samples)(short int *data, int ds, int bps, int nch, int srate); /* Modify samples */
} EffectPlugin;

typedef enum
{
	INPUT_VIS_ANALYZER,INPUT_VIS_SCOPE,INPUT_VIS_VU,INPUT_VIS_OFF
} InputVisType;

typedef struct
{
	void		*handle;					/* Filled in by x11amp */
	char		*filename;					/* Filled in by x11amp */
	char		*description;					/* The description that is shown in the preferences box */
	void		(*init)(void);					/* Called when the plugin is loaded */
	void		(*about)(void);					/* Show the about box */
	void		(*configure)(void);
	int		(*is_our_file)(char *filename);			/* Return 1 if the plugin can handle the file */
	GList *		(*scan_dir)(char *dirname);			/* Look in Input/cdaudio/cdaudio.c to see how */
									/* to use this */
	void		(*play_file)(char *filename);			/* Guess what... */
	void		(*stop)(void);					/* Tricky one */
	void		(*pause)(short paused);				/* Pause or unpause */
	void		(*seek)(int time);				/* Seek to the specified time */
	void		(*set_eq)(int on,float preamp,float *bands);	/* Set the equalizer, most plugins won't be able to do this */
	int		(*get_time)(void);				/* Get the time, usually returns the output plugins output time */
	void		(*get_volume)(int *l,int *r);			 /* Input-plugin specific volume functions, just provide a NULL if */
	void		(*set_volume)(int l,int r); 			/*  you want the output plugin to handle it */
	void		(*add_vis)(int time,unsigned char *data,InputVisType type);
	InputVisType	(*get_vis_type)(void);
	void		(*add_vis_pcm)(int time,AFormat fmt,int nch,int length,void *ptr);
	void		(*set_info)(char *title,int length,int rate,int freq,int nch); /* Fill in the stuff that is shown in the player window
										  set length to -1 if it's unknown. Filled in by x11amp */
	void		(*set_info_text)(char *text);			/* Show some text in the song title box in the main window,
									   call it with NULL as argument to reset it to the song title.
									   Filled in by x11amp */
	void		(*get_song_info)(char *filename,char **title,int *length);		/* Function to grab the title string */
	OutputPlugin 	*output;					/* Handle to the current output plugin. Filled in by x11amp */
} InputPlugin;

/* So that input plugins can communicate with effect plugins */
EffectPlugin *get_current_effect_plugin(void);
int effects_enabled(void);

typedef struct {
	void	*handle;		/* Filled in by x11amp */
	char	*filename;		/* Filled in by x11amp */
	gint	x11amp_session;		/* The session ID for attaching to the control socket */
	char	*description;		/* The description that is shown in the preferences box */
	void	(*init)(void);		/* Called when the plugin is enabled */
	void	(*about)(void);		/* Show the about box */
	void	(*configure)(void);
	void	(*cleanup)(void);	/* Called when the plugin is disabled or when x11amp exits */
} GeneralPlugin;

#endif
