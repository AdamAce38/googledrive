#include <X11/Xlib.h>
#include <X11/Xmd.h>
#include <X11/Xatom.h>
#include <gdk/gdkx.h>
#include <gdk/gdkprivate.h>
#include "x11amp.h"

/* Hints for "Always on Top" mode */

Atom _XA_WIN_SUPPORTING_WM_CHECK;
Atom _XA_WIN_LAYER;

/* The type of hints detected */
int wm_hints = WM_HINTS_NONE;

void hint_set_always(gboolean always)
{
	switch (wm_hints)
	{
		case WM_HINTS_NONE:
			break;
		case WM_HINTS_GNOME:
			gnome_wm_set_always(always);
			break;
		default:
			break;
	}
}

void gnome_wm_set_always(gboolean always)
{
	gnome_wm_set_window_always(mainwin, always);
	gnome_wm_set_window_always(equalizerwin, always);
	gnome_wm_set_window_always(playlistwin, always);
}

void gnome_wm_set_window_always(GtkWidget *window, gboolean always)
{
	XEvent xev;
	GdkWindowPrivate *priv;
	gint prev_error;
	int layer=WIN_LAYER_DOCK;

	if (always==FALSE) 
		layer = WIN_LAYER_NORMAL;

	prev_error = gdk_error_warnings;
	gdk_error_warnings = 0;
	priv = (GdkWindowPrivate*)(GTK_WIDGET(window)->window);
	
	if (GTK_WIDGET_MAPPED(window))
	{
		xev.type = ClientMessage;
		xev.xclient.type = ClientMessage;
		xev.xclient.window = priv->xwindow;
		xev.xclient.message_type = _XA_WIN_LAYER;
		xev.xclient.format = 32;
		xev.xclient.data.l[0] = (CARD32)layer;
		xev.xclient.data.l[1] = gdk_time_get();
		
		XSendEvent(GDK_DISPLAY(), GDK_ROOT_WINDOW(), False,
			SubstructureNotifyMask, (XEvent*) &xev);
	}
	else
	{
		long data[1];
		
		data[0] = layer;
		XChangeProperty(GDK_DISPLAY(), priv->xwindow, _XA_WIN_LAYER,
			XA_CARDINAL, 32, PropModeReplace, (unsigned char *)data,
			1);
	}
	gdk_error_warnings = prev_error;

}

gboolean gnome_wm_found(void)
{
	Atom r_type;
	int r_format;
	unsigned long count;
	unsigned long bytes_remain;
	unsigned char *prop, *prop2;
	gint prev_error;

	prev_error = gdk_error_warnings;
	gdk_error_warnings = 0;

	_XA_WIN_SUPPORTING_WM_CHECK = XInternAtom(GDK_DISPLAY(), XA_WIN_SUPPORTING_WM_CHECK, False);
	_XA_WIN_LAYER = XInternAtom(GDK_DISPLAY(), XA_WIN_LAYER, False);
	
	if (XGetWindowProperty(GDK_DISPLAY(), GDK_ROOT_WINDOW(),
			_XA_WIN_SUPPORTING_WM_CHECK, 0, 1, False, XA_CARDINAL,
			&r_type, &r_format,
			&count, &bytes_remain, &prop) == Success && prop)
	{
		if (r_type == XA_CARDINAL && r_format == 32 && count ==1)
		{
			Window n = *(long *)prop;
			if (XGetWindowProperty(GDK_DISPLAY(), n,
					_XA_WIN_SUPPORTING_WM_CHECK, 0, 1, False,
					XA_CARDINAL,
					&r_type, &r_format, &count, &bytes_remain,
					&prop2) == Success && prop)
			{
				if (r_type == XA_CARDINAL && r_format == 32 && count ==	1)
				{
					XFree(prop);
					XFree(prop2);
					gdk_error_warnings = prev_error;
					return TRUE;
				}
				XFree(prop2);
			}
		}
		XFree(prop);
	}
	gdk_error_warnings = prev_error;
	return FALSE;
}

gboolean check_wm_hints(void)
{
	/* Check for gnome wm first */
	if (gnome_wm_found())
		wm_hints = WM_HINTS_GNOME;

}
