/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "x11amp.h"

static gfloat vis_afalloff_speeds[]={0.34,0.5,1.0,1.3,1.6};
static gfloat vis_pfalloff_speeds[]={1.1,1.16,1.23,1.3,1.4};
static gint vis_redraw_delays[]={1,2,4,8};
static guint8 vis_scope_colors[]={21,21,20,20,19,19,18,19,19,20,20,21,21};
		
		
gint vis_timeout_func(gpointer data)
{
	static GTimer *timer=NULL;
	gulong micros=9999999;
	if(!timer)
	{
		timer=g_timer_new();
		g_timer_start(timer);
	}
	else
	{
		g_timer_elapsed(timer,&micros);
		if(micros>14000)
			g_timer_reset(timer);
		
	}
	if(micros>14000)
	{
		if(cfg.vis_type==VIS_ANALYZER)
		{
			vis_afalloff_func(data);
			vis_pfalloff_func(data);
		}
		vis_redraw_func(data);
	}
}

gint vis_afalloff_func(gpointer data)
{
	Vis *vis=(Vis *)data;
	gint i,j,max;
	
	for(i=0;i<75;i++)
	{
		if(vis->vs_data[i]>0.0)
		{
			vis->vs_data[i]-=vis_afalloff_speeds[cfg.analyzer_falloff];
			if(vis->vs_data[i]<0.0) vis->vs_data[i]=0.0;
		}
	}

	return TRUE;
}

gint vis_pfalloff_func(gpointer data)
{
	Vis *vis=(Vis *)data;
	gint i,j;

	
	for(i=0;i<75;i++)
	{
		if(vis->vs_peak[i]>0.0)
		{
			vis->vs_peak[i]-=vis->vs_peak_speed[i];
			vis->vs_peak_speed[i]*=vis_pfalloff_speeds[cfg.peaks_falloff];
			if(vis->vs_peak[i]<vis->vs_data[i])
				vis->vs_peak[i]=vis->vs_data[i];
			if(vis->vs_peak[i]<0.0)
				vis->vs_peak[i]=0.0;
		}
	}
	return TRUE;
}

gint vis_redraw_func(gpointer data)
{
	Vis *vis=(Vis *)data;
	
	
	if(!vis->vs_refresh_delay)
	{
		vis_draw((Widget*)vis);
		vis->vs_refresh_delay=vis_redraw_delays[cfg.vis_refresh];
		
	}
	vis->vs_refresh_delay--;
	return TRUE;
}



void vis_draw(Widget *w)
{
	Vis *vis=(Vis *)w;
	gint i,x,y,h,h2;
	guchar vis_color[24][3],*tmp;
	guchar rgb_data[152*32],*ptr,c;
	guint32 colors[24];
	static GdkImage *img=NULL;
	GdkRgbCmap *cmap;
	
	
	get_skin_viscolor(vis_color);
	for(y=0;y<24;y++)
	{
		colors[y]=vis_color[y][0]<<16|vis_color[y][1]<<8|vis_color[y][2];
	}
	cmap=gdk_rgb_cmap_new(colors,24);
	

	if(!cfg.doublesize)
	{
		memset(rgb_data,0,76*16);
		for(y=1;y<16;y+=2)
		{
			ptr=rgb_data+(y*76);
			for(x=0;x<76;x+=2,ptr+=2)
				*ptr=1;
		}		
		if(cfg.vis_type==VIS_ANALYZER)
		{
			for(x=0;x<75;x++)
			{
				if((cfg.analyzer_type==ANALYZER_BARS&&(x%4)==0)||cfg.analyzer_type==ANALYZER_LINES)
					h=(gint)vis->vs_data[x];

				if(h&&(cfg.analyzer_type==ANALYZER_LINES||(x%4)!=3))
				{
					ptr=rgb_data+((16-h)*76)+x;
					switch(cfg.analyzer_mode)
					{
						case	ANALYZER_NORMAL:		
							for(y=0;y<h;y++,ptr+=76)
								*ptr=18-h+y;
							break;
						case	ANALYZER_FIRE:
							for(y=0;y<h;y++,ptr+=76)
								*ptr=y+2;
							break;
						case	ANALYZER_VLINES:
							for(y=0;y<h;y++,ptr+=76)
								*ptr=18-h;
							break;
					}
				}
			}
			if(cfg.analyzer_peaks)
			{
				for(x=0;x<75;x++)
				{
					if((cfg.analyzer_type==ANALYZER_BARS&&(x%4)==0)||cfg.analyzer_type==ANALYZER_LINES)
						h=(gint)vis->vs_peak[x];
					if(h&&(cfg.analyzer_type==ANALYZER_LINES||(x%4)!=3))
						rgb_data[(16-h)*76+x]=23;
				}
			}
		}
		else if(cfg.vis_type==VIS_SCOPE)
		{
			for(x=0;x<75;x++)
			{
				switch(cfg.scope_mode)
				{
					case	SCOPE_DOT:
						h=(gint)vis->vs_data[x];
						ptr=rgb_data+((15-h)*76)+x;
						*ptr=vis_scope_colors[h];
						break;
					case	SCOPE_LINE:
						if(x!=74)
						{
							h=15-(gint)vis->vs_data[x];
							h2=15-(gint)vis->vs_data[x+1];
							if(h>h2)
							{
								y=h;
								h=h2;
								h2=y;
							}
							ptr=rgb_data+(h*76)+x;
							for(y=h;y<=h2;y++,ptr+=76)
								*ptr=vis_scope_colors[y-3];
						
						}
						else
						{
							h=15-(gint)vis->vs_data[x];
							ptr=rgb_data+(h*76)+x;
							*ptr=vis_scope_colors[h];
						}
						break;
					case	SCOPE_SOLID:
						h=15-(gint)vis->vs_data[x];
						h2=9;
						c=vis_scope_colors[(gint)vis->vs_data[x]];
						if(h>h2)
						{
							y=h;
							h=h2;
							h2=y;
						}
						ptr=rgb_data+(h*76)+x;
						for(y=h;y<=h2;y++,ptr+=76)
							*ptr=c;
						break;
				}
			}
		}
						
		gdk_draw_indexed_image(mainwin->window,mainwin_gc,vis->vs_widget.x,vis->vs_widget.y,vis->vs_widget.width,vis->vs_widget.height,GDK_RGB_DITHER_NONE,(guchar *)rgb_data,76,cmap);		
	}
	else
	{
		memset(rgb_data,0,152*32);
		for(y=1;y<16;y+=2)
		{
			ptr=rgb_data+(y*304);
			for(x=0;x<76;x+=2,ptr+=4)
			{
				*ptr=1;
				*(ptr+1)=1;
				*(ptr+152)=1;
				*(ptr+153)=1;
			}
		}		
		if(cfg.vis_type==VIS_ANALYZER)
		{
			for(x=0;x<75;x++)
			{
				if((cfg.analyzer_type==ANALYZER_BARS&&(x%4)==0)||cfg.analyzer_type==ANALYZER_LINES)
					h=(gint)vis->vs_data[x];
				if(h&&(cfg.analyzer_type==ANALYZER_LINES||(x%4)!=3))
				{
					ptr=rgb_data+((16-h)*304)+(x<<1);
					switch(cfg.analyzer_mode)
					{
						case	ANALYZER_NORMAL:		
							for(y=0;y<h;y++,ptr+=304)
							{
								*ptr=18-h+y;
								*(ptr+1)=18-h+y;
								*(ptr+152)=18-h+y;
								*(ptr+153)=18-h+y;
							}
							break;
						case	ANALYZER_FIRE:
							for(y=0;y<h;y++,ptr+=304)
							{
								*ptr=y+2;
								*(ptr+1)=y+2;
								*(ptr+152)=y+2;
								*(ptr+153)=y+2;
							}
							break;
						case	ANALYZER_VLINES:
							for(y=0;y<h;y++,ptr+=304)
							{
								*ptr=18-h;
								*(ptr+1)=18-h;
								*(ptr+152)=18-h;
								*(ptr+153)=18-h;
							}

							break;
					}

				}
			}
			if(cfg.analyzer_peaks)
			{

				for(x=0;x<75;x++)
				{
					if((cfg.analyzer_type==ANALYZER_BARS&&(x%4)==0)||cfg.analyzer_type==ANALYZER_LINES)
						h=(gint)vis->vs_peak[x];

					if(h&&(cfg.analyzer_type==ANALYZER_LINES||(x%4)!=3))
					{
						ptr=rgb_data+(16-h)*304+(x<<1);
						*ptr=23;
						*(ptr+1)=23;
						*(ptr+152)=23;
						*(ptr+153)=23;
					}
				}
			}
		}
		else if(cfg.vis_type==VIS_SCOPE)
		{
			for(x=0;x<75;x++)
			{
				switch(cfg.scope_mode)
				{
					case	SCOPE_DOT:
						h=(gint)vis->vs_data[x];
						ptr=rgb_data+((15-h)*304)+(x<<1);
						*ptr=vis_scope_colors[h];
						*(ptr+1)=vis_scope_colors[h];
						*(ptr+152)=vis_scope_colors[h];
						*(ptr+153)=vis_scope_colors[h];
						break;
					case	SCOPE_LINE:
						if(x!=74)
						{
							h=15-(gint)vis->vs_data[x];
							h2=15-(gint)vis->vs_data[x+1];
							if(h>h2)
							{
								y=h;
								h=h2;
								h2=y;
							}
							ptr=rgb_data+(h*304)+(x<<1);
							for(y=h;y<=h2;y++,ptr+=304)
							{
								*ptr=vis_scope_colors[y-3];
								*(ptr+1)=vis_scope_colors[y-3];
								*(ptr+152)=vis_scope_colors[y-3];
								*(ptr+153)=vis_scope_colors[y-3];
							}
						}
						else
						{
							h=15-(gint)vis->vs_data[x];
							ptr=rgb_data+(h*304)+(x<<1);
							*ptr=vis_scope_colors[h];
							*(ptr+1)=vis_scope_colors[h];
							*(ptr+152)=vis_scope_colors[h];
							*(ptr+153)=vis_scope_colors[h];
						}
						break;
					case	SCOPE_SOLID:
						h=15-(gint)vis->vs_data[x];
						h2=9;
						c=vis_scope_colors[(gint)vis->vs_data[x]];
						if(h>h2)
						{
							y=h;
							h=h2;
							h2=y;
						}
						ptr=rgb_data+(h*304)+(x<<1);
						for(y=h;y<=h2;y++,ptr+=304)
						{
							*ptr=c;
							*(ptr+1)=c;
							*(ptr+152)=c;
							*(ptr+153)=c;
						}
						break;
				}
			}
		}
		
		gdk_draw_indexed_image(mainwin->window,mainwin_gc,vis->vs_widget.x<<1,vis->vs_widget.y<<1,vis->vs_widget.width<<1,vis->vs_widget.height<<1,GDK_RGB_DITHER_NONE,(guchar *)rgb_data,152,cmap);		
	}
	gdk_rgb_cmap_free(cmap);
	gdk_flush();
}

void vis_set_data(Vis *vis,guchar *data)
{
	gint i;
	for(i=0;i<75;i++)
	{
		if(data[i]>vis->vs_data[i]||cfg.vis_type==VIS_SCOPE) 
		{
			vis->vs_data[i]=data[i];
			if(vis->vs_data[i]>vis->vs_peak[i])
			{
				vis->vs_peak[i]=vis->vs_data[i];
				vis->vs_peak_speed[i]=0.05;
				
			}
		}
	}
}

void vis_clear_data(Vis *vis)
{
	gint i;
	
	for(i=0;i<75;i++)
	{
		vis->vs_data[i]=0;
		vis->vs_peak[i]=0;
	}
}

Vis *create_vis(GList **wlist,GdkPixmap *parent,GdkGC *gc,gint x,gint y)
{
	Vis *vis;
	vis=(Vis *)g_malloc0(sizeof(Vis));
	vis->vs_widget.parent=parent;
	vis->vs_widget.gc=gc;
	vis->vs_widget.x=x;
	vis->vs_widget.y=y;
	vis->vs_widget.width=76;
	vis->vs_widget.height=16;
	vis->vs_widget.visible=1;
	vis->vs_widget.draw=vis_draw;
/*	vis->vs_afalloff_tag=gtk_timeout_add(20,vis_timeout_func,vis);
	vis->vs_pfalloff_tag=gtk_timeout_add(20,vis_pfalloff_func,vis);
	
	vis->vs_redraw_tag=gtk_timeout_add((cfg.vis_refresh+1)*20,vis_redraw_func,vis);*/
	add_widget(wlist,vis);
	return vis;
}


