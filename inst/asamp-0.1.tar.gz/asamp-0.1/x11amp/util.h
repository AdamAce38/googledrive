/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#ifndef UTIL_H
#define UTIL_H
		
int find_file(char *dest,const char *dirname,const char *file);
gchar *find_file_recursively(const char *dirname, const char *file);
int del_directory(const char *dirname);
GdkImage *create_dblsize_image(GdkImage *img);
void *shalloc(int bytes);
void shfree(void *ptr);
char *read_ini_string(const char *filename,const char *section,const char *key);
GArray* read_ini_array(const gchar *filename,const gchar *section,const gchar *key);
void glist_movedown(GList *list);
void glist_moveup(GList *list);

#endif
