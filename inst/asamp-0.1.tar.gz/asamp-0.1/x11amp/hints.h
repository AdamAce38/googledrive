#ifndef HINTS_H
#define HINTS_H

#include <gtk/gtkwidget.h>

extern int wm_hints;

/* Window Managers that handle Always on top */
#define WM_HINTS_NONE				0
#define WM_HINTS_GNOME				1

#define XA_WIN_LAYER				"_WIN_LAYER"
#define XA_WIN_SUPPORTING_WM_CHECK 	"_WIN_SUPPORTING_WM_CHECK"

/* flags for the window layer */
typedef enum
{
	WIN_LAYER_DESKTOP = 0,
	WIN_LAYER_BELOW = 2,
	WIN_LAYER_NORMAL = 4,
	WIN_LAYER_ONTOP = 6,
	WIN_LAYER_DOCK = 8,
	WIN_LAYER_ABOVE_DOCK = 10
} WinLayer;
	
gboolean gnome_wm_found(void);
void gnome_wm_set_window_always(GtkWidget *window, gboolean always);
void gnome_wm_set_always(gboolean always);

gboolean check_wm_hints(void);
void hint_set_always(gboolean always);

#endif
