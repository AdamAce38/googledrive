#ifndef VOICE_H
#define VOICE_H

#include <pthread.h>

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <glib.h>
#include <gtk/gtk.h>

#include "x11amp/plugin.h"

extern EffectPlugin voice_ep;

void about(void);
static int modify_samples(short int *data, int datasize, int bps, int nch, int srate);

#endif
