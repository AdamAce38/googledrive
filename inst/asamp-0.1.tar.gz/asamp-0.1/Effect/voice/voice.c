/* A voice removal plugin 
   by Anders Carlsson <anders.carlsson@tordata.se> */

#include "voice.h"

EffectPlugin voice_ep =
{
	NULL,
	NULL,
	"Voice removal plugin",
	NULL,
	NULL, 
	about,
	NULL,
	modify_samples,
};
	
EffectPlugin *get_eplugin_info(void)
{
	return &voice_ep;
}

static int modify_samples(short int *data, int datasize, int bps, int nch, int srate)
{
	int x;
	int left,right;
	short *dataptr = data;

	if (nch==2)
	{
		if (bps==16)
		{
			for (x=0;x<datasize;x+=2)
			{
				left = dataptr[1]-dataptr[0];
				right = dataptr[0]-dataptr[1];
				if (left < -32768) left = -32768;
        		if (left > 32767) left = 32767;
        		if (right < -32768) right = -32768;
        		if (right > 32767) right = 32767;
				dataptr[0] = left;
				dataptr[1] = right;
				dataptr+=2;
			}
		}
	}
	
	return datasize;
}

