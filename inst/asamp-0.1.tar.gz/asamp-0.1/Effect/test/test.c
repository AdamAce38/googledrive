/* This plugin isn't used for anything other than a skeleton for
   building additional plugins */

#include "test.h"

EffectPlugin test_ep =
{
	NULL,
	NULL,
	"Test Effect Plugin",
	init,
	NULL,
	NULL,
	NULL,
	modify_samples,
};
	
EffectPlugin *get_eplugin_info(void)
{
	return &test_ep;
}

static void init(void)
{
}

static int modify_samples(short int *data, int datasize, int bps, int nch, int srate)
{
//	printf("data[0]: %d datasize: %d bps: %d nch: %d srate: %d\n", data[0], datasize, bps, nch, srate);

	return datasize;
}

