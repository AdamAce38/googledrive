aclocal $ACLOCAL_FLAGS
autoheader
automake --add-missing
autoconf
cd libx11amp
aclocal $ACLOCAL_FLAGS
autoheader
automake --add-missing
autoconf
cd ..
./configure $@
