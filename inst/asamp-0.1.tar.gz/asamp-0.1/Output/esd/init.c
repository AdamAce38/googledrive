/*	x11amp - esound output plugin
 *	Copyright (C) 1999	Galex Yen
 *	
 *	this program is free software
 *	
 *	Description:
 *		This program is an output plugin for x11amp v0.9 or greater.
 *		The program uses the esound daemon to output audio in order
 *		to allow more than one program to play audio on the same
 *		device at the same time.
 *
 *		Contains code Copyright (C) 1998-1999 Mikael Alm, Olle Hallnas,
 *		Thomas Nillson and 4Front Technologies
 *
 */
 
#include "Esd.h"
#include "libx11amp/configfile.h"

EsDConfig esd_cfg;

void init(void) 
{
	ConfigFile *cfgfile;
	gchar *filename;
	
	memset(&esd_cfg,0,sizeof(EsDConfig));
	
	esd_cfg.server = malloc(50);		/* this is an arbitrary number.  if anyone has
									   a better method, please tell me how */
	esd_cfg.server = g_strconcat("localhost",NULL);
	esd_cfg.port = 0;					/* by default I don't even worry about it */
	esd_cfg.buffer_size = 1500;
	esd_cfg.prebuffer = 25;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	if(cfgfile=x11amp_cfg_open_file(filename))
	{
		x11amp_cfg_read_string(cfgfile,"EsD","server",&esd_cfg.server);
		x11amp_cfg_read_int(cfgfile,"Esd","port",&esd_cfg.port);
		x11amp_cfg_read_int(cfgfile,"Esd","buffer_size",&esd_cfg.buffer_size);
		x11amp_cfg_read_int(cfgfile,"Esd","prebuffer",&esd_cfg.prebuffer);
		x11amp_cfg_free(cfgfile);
	}
}