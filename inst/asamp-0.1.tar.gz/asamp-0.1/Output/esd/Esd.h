/*	x11amp - esound output plugin
 *	Copyright (C) 1999	Galex Yen
 *	
 *	this program is free software
 *	
 *	Description:
 *		This program is an output plugin for x11amp v0.9 or greater.
 *		The program uses the esound daemon to output audio in order
 *		to allow more than one program to play audio on the same
 *		device at the same time.
 *
 *		Contains code Copyright (C) 1998-1999 Mikael Alm, Olle Hallnas,
 *		Thomas Nillson and 4Front Technologies
 *
 */
 
 #ifndef EsD_H
 #define EsD_H
 
 #include <gtk/gtk.h>
 
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <sys/time.h>
 #include <esd.h>
 
 #include <fcntl.h>
 #include <pthread.h>
 
 #include <stdlib.h>
 #include <stdio.h>
 
 #include "x11amp/plugin.h"
  
 extern OutputPlugin op;

 typedef struct
 {
	gchar	*server;
	gint	port;
	gint	buffer_size;
	gint	prebuffer;
 } EsDConfig;
 
 extern EsDConfig esd_cfg;
 
 void init(void);
 void about(void);
 void configure(void);
 
 void get_volume(int *l,int *r);
 void set_volume(int l,int r);
 
 int abuffer_playing(void);
 int abuffer_free(void);
 void abuffer_write(void *ptr,int length);
 void abuffer_close(void);
 void abuffer_flush(int time);
 void abuffer_pause(short p);
 int abuffer_open(AFormat fmt,int rate,int nch);
 int abuffer_get_output_time(void);
 int abuffer_get_written_time(void);
 void abuffer_set_audio_params(void);
 
 #endif
 