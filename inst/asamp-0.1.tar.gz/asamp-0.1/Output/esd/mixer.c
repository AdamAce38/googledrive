/*	x11amp - esound output plugin
 *	Copyright (C) 1999	Galex Yen
 *	
 *	this program is free software
 *	
 *	Description:
 *		This program is an output plugin for x11amp v0.9 or greater.
 *		The program uses the esound daemon to output audio in order
 *		to allow more than one program to play audio on the same
 *		device at the same time.
 *
 *		Contains code Copyright (C) 1998-1999 Mikael Alm, Olle Hallnas,
 *		Thomas Nillson and 4Front Technologies
 *
 */
 
 
#include "Esd.h"
#include <sys/soundcard.h>

void get_volume(int *l,int *r)
{
	int fd,v,cmd,devs;
		
	fd=open("/dev/mixer",O_RDONLY);
	if(fd!=-1)
	{
		ioctl(fd,SOUND_MIXER_READ_DEVMASK,&devs);
		if(devs&SOUND_MASK_PCM)
			cmd=SOUND_MIXER_READ_PCM;
		else if(devs&SOUND_MASK_VOLUME)
			cmd=SOUND_MIXER_READ_VOLUME;
		else
		{
			close(fd);
			return;
		}
		ioctl(fd,cmd,&v);
		*r=(v&0xFF00)>>8;
		*l=(v&0x00FF);
		close(fd);
	}
}

void set_volume(int l,int r)
{
	int fd,v,cmd,devs;
		
	fd=open("/dev/mixer",O_RDONLY);

	if(fd!=-1)
	{
		ioctl(fd,SOUND_MIXER_READ_DEVMASK,&devs);
		if(devs&SOUND_MASK_PCM)
			cmd=SOUND_MIXER_WRITE_PCM;
		else if(devs&SOUND_MASK_VOLUME)
			cmd=SOUND_MIXER_WRITE_VOLUME;
		else
		{
			close(fd);
			return;
		}
		v=(r<<8)|l; 
		ioctl(fd,cmd,&v);
		close(fd);
	}
}