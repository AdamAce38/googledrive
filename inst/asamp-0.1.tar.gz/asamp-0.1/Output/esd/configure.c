/*	x11amp - esound output plugin
 *	Copyright (C) 1999	Galex Yen
 *	
 *	this program is free software
 *	
 *	Description:
 *		This program is an output plugin for x11amp v0.9 or greater.
 *		The program uses the esound daemon to output audio in order
 *		to allow more than one program to play audio on the same
 *		device at the same time.
 *
 *		Contains code Copyright (C) 1998-1999 Mikael Alm, Olle Hallnas,
 *		Thomas Nillson and 4Front Technologies
 *
 */
 
#include "Esd.h"
#include <gtk/gtk.h>

void configure(void)
{

	/* nothing yet */
}