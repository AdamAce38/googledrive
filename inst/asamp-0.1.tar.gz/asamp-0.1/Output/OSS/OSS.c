/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "OSS.h"


OutputPlugin op=
{
	NULL,
	NULL,
	"OSS Driver 0.9",
	init,
	about,
	configure,
	get_volume,
	set_volume,
	abuffer_open,
	abuffer_write,
	abuffer_close,
	abuffer_flush,
	abuffer_pause,
	abuffer_free,
	abuffer_playing,
	abuffer_get_output_time,
	abuffer_get_written_time,
};


OutputPlugin *get_oplugin_info(void)
{
	return &op;
}
