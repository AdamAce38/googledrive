#include "OSS.h"
#include "libx11amp/configfile.h"

OSSConfig oss_cfg;

void init(void)
{
	ConfigFile *cfgfile;
	gchar *filename;
	
	memset(&oss_cfg,0,sizeof(OSSConfig));
	
	oss_cfg.audio_device=-1;
	oss_cfg.mixer_device=-1;
	oss_cfg.buffer_size=1500;
	oss_cfg.prebuffer=25;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	if(cfgfile=x11amp_cfg_open_file(filename))
	{
		x11amp_cfg_read_int(cfgfile,"OSS","audio_device",&oss_cfg.audio_device);
		x11amp_cfg_read_int(cfgfile,"OSS","mixer_device",&oss_cfg.mixer_device);
		x11amp_cfg_read_int(cfgfile,"OSS","buffer_size",&oss_cfg.buffer_size);
		x11amp_cfg_read_int(cfgfile,"OSS","prebuffer",&oss_cfg.prebuffer);
		x11amp_cfg_free(cfgfile);
	}
}
