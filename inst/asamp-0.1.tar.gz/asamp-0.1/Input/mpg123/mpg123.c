#include "mpg123.h"
#include "libx11amp/configfile.h"
#include <string.h>
#include <pthread.h>

long outscale  = 32768;

static struct frame fr;

PlayerInfo *info=NULL;
pthread_t decode_thread;

gboolean pos=TRUE;

gboolean vbr_set=FALSE,have_xing_header=FALSE;
XHEADDATA xing_header;
unsigned char xing_toc[100];
gint bitrate;

extern int tabsel_123[2][3][16];

static double compute_tpf(struct frame *fr)
{
	static int bs[4] = { 0,384,1152,1152 };
	double tpf;

	tpf = (double) bs[fr->lay];
	tpf /= freqs[fr->sampling_frequency] << (fr->lsf);
	return tpf;
}

void set_synth_functions(struct frame *fr)
{
	typedef int (*func)(real *,int,unsigned char *,int *);
	typedef int (*func_mono)(real *,unsigned char *,int *);
	int ds = fr->down_sample;
	int p8=0;

	static func funcs[2][4] = { 
		{ synth_1to1,
		  synth_2to1,
		  synth_4to1,
		  synth_ntom } ,
		{ synth_1to1_8bit,
		  synth_2to1_8bit,
		  synth_4to1_8bit,
		  synth_ntom_8bit } 
	};

	static func_mono funcs_mono[2][2][4] = {    
		{ { synth_1to1_mono2stereo ,
		    synth_2to1_mono2stereo ,
		    synth_4to1_mono2stereo ,
		    synth_ntom_mono2stereo } ,
		  { synth_1to1_8bit_mono2stereo ,
		    synth_2to1_8bit_mono2stereo ,
		    synth_4to1_8bit_mono2stereo ,
		    synth_ntom_8bit_mono2stereo } } ,
		{ { synth_1to1_mono ,
		    synth_2to1_mono ,
		    synth_4to1_mono ,
		    synth_ntom_mono } ,
		  { synth_1to1_8bit_mono ,
		    synth_2to1_8bit_mono ,
		    synth_4to1_8bit_mono ,
		    synth_ntom_8bit_mono } }
	};

	if(mpg123_cfg.resolution == 8)
		p8 = 1;
	fr->synth = funcs[p8][ds];
	fr->synth_mono = funcs_mono[1][p8][ds];

	if(p8) {
		make_conv16to8_table();
	}
}

void init(void)
{
	ConfigFile *cfg;
	gchar *filename;
	
	make_decode_tables(outscale);
	
	mpg123_cfg.resolution=16;
	mpg123_cfg.channels=2;
	mpg123_cfg.downsample=0;
	mpg123_cfg.downsample_custom=44100;
	mpg123_cfg.http_buffer_size=128;
	mpg123_cfg.http_prebuffer=25;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	if( (cfg=x11amp_cfg_open_file(filename)) != 0 )
	{
		x11amp_cfg_read_int(cfg,"MPG123","resolution",&mpg123_cfg.resolution);
		x11amp_cfg_read_int(cfg,"MPG123","channels",&mpg123_cfg.channels);
		x11amp_cfg_read_int(cfg,"MPG123","downsample",&mpg123_cfg.downsample);
		/*x11amp_cfg_read_int(cfg,"MPG123","downsample_custom",&mpg123_cfg.downsample_custom);*/
		x11amp_cfg_read_int(cfg,"MPG123","http_buffer_size",&mpg123_cfg.http_buffer_size);
		x11amp_cfg_read_int(cfg,"MPG123","http_prebuffer",&mpg123_cfg.http_prebuffer);
		/* FIXME: need to g_free(mpg123_cfg.id3_format) */
		if (!x11amp_cfg_read_string(cfg,"MPG123","id3_format",&mpg123_cfg.id3_format))
			mpg123_cfg.id3_format = g_strdup("%1 - %2") ;
		x11amp_cfg_free(cfg);
	}
	else
		mpg123_cfg.id3_format = g_strdup("%1 - %2") ;
}


/* needed for is_our_file() */ 
static int read_n_bytes(FILE *file, guint8 *buf, int n) {

  if(fread(buf, 1, n, file) != n) {
    return FALSE;
  }
  return TRUE;
}

static guint32 convert_to_header(guint8 * buf) {

  return (buf[0]<<24) + (buf[1]<<16) + (buf[2]<<8) + buf[3];
}

static guint32 convert_to_long(guint8 * buf) {

  return (buf[3]<<24) + (buf[2]<<16) + (buf[1]<<8) + buf[0];
}


static guint16 read_wav_id(char *filename) {
  FILE *file;
  guint16 wavid;
  guint8 buf[4];
  guint32 head;
  long seek;

  if(!(file=fopen(filename, "rb"))) {  /* Could not open file */
    return 0;
  }
  if(!(read_n_bytes(file, buf, 4))) {
    fclose(file);
    return 0;
  }
    head = convert_to_header(buf);
  if(head == ('R'<<24)+('I'<<16)+('F'<<8)+'F') { /* Found a riff -- maybe WAVE */
    if(fseek(file, 4, SEEK_CUR) != 0) { /* some error occured */
      fclose(file);
      return 0;
    }
    if(!(read_n_bytes(file, buf, 4))) {
      fclose(file);
      return 0;
    }
    head = convert_to_header(buf);
    if(head == ('W'<<24)+('A'<<16)+('V'<<8)+'E') { /* Found a WAVE */
      seek = 0;
      do {
/* we'll be looking for the fmt-chunk which comes before the data-chunk */
/* A chunk consists of an header identifier (4 bytes), the length of the chunk
(4 bytes), and the chunkdata itself, padded to be an even number of bytes.
We'll skip all chunks until we find the "data"-one which could contain
mpeg-data */
	if(seek != 0) {
	  if(fseek(file, seek, SEEK_CUR) != 0) { /* some error occured */
	    fclose(file);
	    return 0;
	  }
	}
	if(!(read_n_bytes(file, buf, 4))) {
	  fclose(file);
	  return 0;
	}
	head = convert_to_header(buf);
	if(!(read_n_bytes(file, buf, 4))) {
	  fclose(file);
	  return 0;
	}
	seek = convert_to_long(buf);
	seek = seek + (seek % 2);    /* Has to be even (padding) */
	if(seek >= 2 && head == ('f'<<24)+('m'<<16)+('t'<<8)+' ') {
	  if(!(read_n_bytes(file, buf, 2))) {
	    fclose(file);
	    return 0;
	  }
	  wavid = buf[0] + 256*buf[1];
	  seek -= 2;
	  /* we could go on looking for other things, but all we wanted was the wavid */
	  fclose(file);
	  return wavid;
	}
      } while(head != ('d'<<24)+('a'<<16)+('t'<<8)+'a');
      /* it's RIFF WAVE */
    }
    /* it's RIFF */
  }
  /* it's not even RIFF */
  fclose(file);
  return 0;
}

int is_our_file(char *filename) {
  char *ext;
  guint16 wavid;

  if(!strncasecmp(filename,"http://",7)) { /* We assume all http:// are mpeg -- why do we do that? */
    return TRUE;
  }
  ext=strrchr(filename,'.');
  if(ext) {
    if(!strncasecmp(ext, ".mpg", 4) || !strncasecmp(ext, ".mp2", 4) || 
       !strncasecmp(ext, ".mp3", 4) || !strncasecmp(ext, ".mpeg", 5)) {
      return TRUE;
    }
    if(!strncasecmp(ext, ".wav", 4)) {
      wavid = read_wav_id(filename);
      if(wavid == 85 || wavid == 80) {  /* Microsoft says 80, files say 85... */
	return TRUE;
      }
    }
  }
  return FALSE;
}

void play_frame(struct frame *fr)
{
	if (fr->error_protection) 
	{
		getbits(16); /* skip crc */
	}		
	fr->do_layer(fr);
}

/* this is all ID3v1, ID3v2 support "coming soon" ... */
struct id3tag {
	char tag[3]; /* always "TAG": defines ID3v1 tag 128 bytes before EOF */
	char title[30];
	char artist[30];
	char album[30];
	char year[4];
	char comment[30];
	unsigned char genre;
};

/* as defined in WinAmp's Nullsoft Nitrane pllugin preferences
   default is "%1 - %2" (Artist - Title), %% = '%' */
enum id3_format_codes { ID3_ARTIST = '1', ID3_TITLE, ID3_ALBUM, ID3_YEAR,
			ID3_COMMENT, ID3_GENRE, FILE_NAME, FILE_PATH,
			FILE_EXT } ;

static const gchar *
get_id3_genre (unsigned char genre_code)
{
	/* FIXME: there's no guarantee all entries are within 30 characters
	   however id3_genres[148][30] would be wasteful of memory */
	static const gchar *id3_genres[] = {
"Blues","Classic Rock","Country","Dance","Disco","Funk","Grunge","Hip-Hop",
"Jazz","Metal","New Age","Oldies","Other","Pop","R&B","Rap","Reggae","Rock",
"Techno","Industrial","Alternative","Ska","Death Metal","Pranks","Soundtrack",
"Euro-Techno","Ambient","Trip-Hop","Vocal","Jazz+Funk","Fusion","Trance",
"Classical","Instrumental","Acid","House","Game","Sound Clip","Gospel","Noise",
"Alt","Bass","Soul","Punk","Space","Meditative","Instrumental Pop",
"Instrumental Rock","Ethnic","Gothic","Darkwave","Techno-Industrial",
"Electronic","Pop-Folk","Eurodance","Dream","Southern Rock","Comedy","Cult",
"Gangsta Rap","Top 40","Christian Rap","Pop/Funk","Jungle","Native American",
"Cabaret","New Wave","Psychedelic","Rave","Showtunes","Trailer","Lo-Fi",
"Tribal","Acid Punk","Acid Jazz","Polka","Retro","Musical","Rock & Roll",
"Hard Rock","Folk","Folk/Rock","National Folk","Swing","Fast-Fusion","Bebob",
"Latin","Revival","Celtic","Bluegrass","Avantgarde","Gothic Rock",
"Progressive Rock","Psychedelic Rock","Symphonic Rock","Slow Rock","Big Band",
"Chorus","Easy Listening","Acoustic","Humour","Speech","Chanson","Opera",
"Chamber Music","Sonata","Symphony","Booty Bass","Primus","Porn Groove",
"Satire","Slow Jam","Club","Tango","Samba","Folklore","Ballad","Power Ballad",
"Rhythmic Soul","Freestyle","Duet","Punk Rock","Drum Solo","A Cappella",
"Euro-House","Dance Hall","Goa","Drum & Bass","Club-House","Hardcore","Terror",
"Indie","BritPop","Negerpunk","Polsk Punk","Beat","Christian Gangsta Rap",
"Heavy Metal","Black Metal","Crossover","Contemporary Christian",
"Christian Rock","Merengue","Salsa","Thrash Metal","Anime","JPop","Synthpop"
	} ;
	return ( genre_code < sizeof(id3_genres) / sizeof(*id3_genres) )
		? id3_genres[genre_code]
		: "unknown genre" ;
} ;

static guint
strip_spaces(char *src, size_t n)
/* strips trailing spaces from string of length n
   returns length of adjusted string */
{
	gchar *space = NULL , // last space in src
	      *start = src ;
	while (n--)
		switch (*src++) {
		case '\0':
			n = 0 ; // breaks out of while loop
			src-- ;
			break ;
		case ' ':
			if (space == NULL) space = src - 1;
			break ;
		default:
			space = NULL ; // don't terminate intermediate spaces
			break ;
		}
	if ( space != NULL ) {
		src = space ;
		*src = '\0' ;
	}
	return src - start ;
}

static gchar *
extname (const char *filename)
/* pointer within filename to extension, else NULL */
{
	gchar *ext = strrchr (filename, '.') ;
	if (ext != NULL)
		++ext ;
	return ext ;
}

static gchar *
eval_id3_format (const char *id3_format, struct id3tag *id3, 
		 const char *filename )
/* returns ID3 and filename data as specified in format
   as in Nullsoft's Nitrane plugin v1.31b (their MPEG decoder) */
{
	gchar *ans, c, *base, *path, *ext;
	guint length = 0, allocated, baselen, pathlen, extlen, tmp ;
	const size_t alloc_size = 256 ; // size of memory block allocations

	ans = g_malloc (allocated = alloc_size) ;
	pathlen = strlen (path = g_dirname (filename)) ;
	base = g_strdup(g_basename(filename)) ;
	if ( (ext=extname(base)) == NULL ) {
		ext = "" ;
		extlen = 0 ;
	} else {
		*(ext-1) = '\0' ;
		extlen = strlen (ext) ;
	}
	baselen = strlen (base) ;
	while ( (c = *id3_format++) != '\0') {
		tmp = 1 ;
		if (c == '%') {
			switch (*id3_format++) {
			case 0:
				id3_format-- ; //otherwise we'll lose terminator
			case '%':
				ans[length] = '%' ;
				break ;
			case ID3_ARTIST:
				tmp = strip_spaces (id3->artist, 30) ;
				strncpy (&ans[length], id3->artist, tmp ) ;
				break ;
			case ID3_TITLE:
				tmp = strip_spaces (id3->title, 30) ;
				strncpy (&ans[length], id3->title, tmp ) ;
				break ;
			case ID3_ALBUM:
				strncpy (&ans[length], id3->album, tmp =
					 strip_spaces (id3->album, 30) ) ;
				break ;
			case ID3_YEAR:
				strncpy (&ans[length], id3->year, tmp = 4 ) ;
				break ;
			case ID3_COMMENT:
				strncpy (&ans[length], id3->comment, tmp =
					 strip_spaces (id3->comment, 30) ) ;
				break ;
			case ID3_GENRE:
				strncpy (&ans[length],
					 get_id3_genre (id3->genre), 30 ) ;
				tmp = strlen ( &ans[length] ) ;
				break ;
			case FILE_NAME:
				strncpy (&ans[length], base, tmp = baselen ) ;
				break ;
			case FILE_PATH:
				strncpy (&ans[length], path, tmp = pathlen ) ;
				break ;
			case FILE_EXT:
				strncpy (&ans[length], ext, tmp = extlen ) ;
				break ;
			default:
				ans[length] = c ;
				break ;
			}
		} else
			ans[length] = c ;
		ans[length += tmp] = '\0' ;
		if (allocated - length <= 30)
			ans = g_realloc (ans, allocated += alloc_size ) ;
	}
	ans = g_realloc (ans, length+1) ;
	g_free (base) ;
	g_free (path) ;
	return ans ;
}

gchar *
get_song_title(char *filename)
/* returns formatted title of song specified in filename
 * CHECK: needs 'g_free'ing...
 */
{
	FILE *file;
	struct id3tag tag;
	char *ret = NULL ;

	g_assert ( sizeof(tag) == 128 ) ; // true for all ID3v1's
	if(!strncasecmp(filename,"http://",7)) {
		ret = g_strdup(http_get_title(filename));
	} else if ( (file = fopen(filename,"rb")) != 0) {
		fseek(file,-1*sizeof(tag),SEEK_END);
		fread(&tag,sizeof(tag),1,file);
		fclose(file);
		if(!strncmp(tag.tag,"TAG",3)) {
			strip_spaces (tag.title,30) ;
			strip_spaces (tag.artist,30) ;
			strip_spaces (tag.album,30) ;
			strip_spaces (tag.year,4) ;
			strip_spaces (tag.comment,30) ;
			ret = eval_id3_format (
				mpg123_cfg.id3_format,
				&tag, filename) ;
		}
	}
	if (ret==NULL) {
		filename = g_strdup ( g_basename (filename) ) ;
		if ( (ret = extname(filename)) != NULL ) {
			*(ret-1) = '\0' ; // removes period
			ret = g_realloc (filename, ret - filename ) ;
		} else
			ret = filename ;
	}
	return ret ;
}

void get_song_info(char *filename,char **title_real,int *len_real)
{
	FILE *file;
	char *ret=NULL; // *ext;
	unsigned long head;
	unsigned char tmp[4],*buf,toc[100];
	struct frame frm;
	XHEADDATA xing_header;
	double tpf;
	int pos,num_frames,len;
	
	if(strncasecmp(filename,"http://",7))
	{
		if( (file=fopen(filename,"rb")) != NULL )
		{
			if(fread(tmp,1,4,file)!=4)
			{
				fclose(file);
				return;
			}
			head=((unsigned long)tmp[0]<<24)|((unsigned long)tmp[1]<<16)|((unsigned long)tmp[2]<<8)|(unsigned long)tmp[3];
			while(!head_check(head))
			{
				head<<=8;
				if(fread(tmp,1,1,file)!=1)
				{
					fclose(file);
					return;
				}
				head|=tmp[0];
			}
			if(decode_header(&frm,head))
			{
				buf=g_malloc(frm.framesize+4);
				fseek(file,-4,SEEK_CUR);
				fread(buf,1,frm.framesize+4,file);
				xing_header.toc=toc;
				tpf=compute_tpf(&frm);
				if(GetXingHeader(&xing_header,buf))
				{
					(*len_real)=(int)(tpf*(double)xing_header.frames*1000);
				}
				else
				{
					pos=ftell(file);
					fseek(file,0,SEEK_END);
					len=ftell(file)-pos;
					num_frames=(int)((double)len/compute_bpf(&frm));
					(*len_real)=(int)(num_frames*tpf*1000);
				}
				g_free(buf);
			}
			ret=get_song_title(filename);
			fclose(file);
		}
			
	}
	else
		(*len_real)=-1;
	(*title_real)=ret;
}

int real_open(char *filename)
{
	char *title;
	pcm_sample=(unsigned char *)g_malloc0(32768);
	pcm_point=0;

	
	read_frame_init();
	
	open_stream(filename,-1);
	if(info->eof)
	{
		g_free(info);
		info=NULL;
		return 0;
	}
	
	if(!read_frame(&fr))
	{
		stream_close();
		g_free(info);
		info=NULL;
		return 0;
	}
	if(mpg123_cfg.channels==2)
		fr.single=-1;
	else
		fr.single=3;
	
	fr.down_sample=mpg123_cfg.downsample;
	fr.down_sample_sblimit=SBLIMIT>>mpg123_cfg.downsample;
	set_synth_functions(&fr);
	init_layer3(fr.down_sample_sblimit);
	
	bitrate=tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index];
	
	info->tpf=compute_tpf(&fr);
	if(strncasecmp(filename,"http://",7))
	{
		xing_header.toc=xing_toc;
		if(stream_check_for_xing_header(&fr,&xing_header))
		{
			info->num_frames=xing_header.frames;
			have_xing_header=TRUE;
			vbr_set=TRUE;
			bitrate=-1;
			read_frame(&fr);
		}
		else
			info->num_frames=calc_numframes(&fr);
	}
	else
		info->num_frames=-1;
	info->jump_to_time=-1;
	title=get_song_title(filename);
	if(strncasecmp(filename,"http://",7))
		ip.set_info(title,info->num_frames*info->tpf*1000,tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index]*1000,freqs[fr.sampling_frequency],fr.stereo);
	else
		ip.set_info(title,-1,tabsel_123[fr.lsf][fr.lay-1][fr.bitrate_index]*1000,freqs[fr.sampling_frequency],fr.stereo);
	g_free(title);

	return 1;
}

void *decode_loop(void *arg)
{
	int read_ok = 0 ;
	char *filename=arg;

	if(!strncasecmp(filename,"http://",7))
		if(!real_open(filename))
			return NULL ;

	if(!ip.output->open_audio(mpg123_cfg.resolution==16?FMT_S16_NE:FMT_U8,
			          freqs[fr.sampling_frequency]>>mpg123_cfg.downsample,
			          mpg123_cfg.channels==2?fr.stereo:1))
	{
		fprintf(stderr,"Couldn't open audio!\n");
		info->eof=TRUE;
	}
	else
		play_frame(&fr);
	
	/*
	 * We don't want to output the first frame since it will be fucked up if the previous
	 * mp3 file didn't play to finish and I don't have the time to fix it properly
	 */
	
	info->output_audio=TRUE;
	
	while(info->going) {
		if(info->jump_to_time!=-1) {
			if(!have_xing_header)
				stream_jump_to_frame(&fr,(int)(info->jump_to_time/info->tpf));
			else
				stream_jump_to_byte(&fr,SeekPoint(xing_toc,xing_header.bytes,((double)info->jump_to_time*100.0)/((double)info->num_frames*info->tpf)));
			ip.output->flush(info->jump_to_time*1000);
			info->jump_to_time=-1;
			info->output_audio=FALSE;
		}
		if(!info->eof) {
			if( (read_ok=read_frame(&fr)) != 0 ) {
				play_frame(&fr);		
				info->output_audio=TRUE;
			} else
				usleep(10000);
		} else
			usleep(10000);
		if(!ip.output->buffer_playing()&&!read_ok)
			info->eof=1;
	}
	stream_close();
	ip.output->close_audio();
	g_free(pcm_sample);
	pthread_exit(NULL);
}

void play_file(char *filename)
{
	memset(&fr,0,sizeof(struct frame));
	
	
		
	info=g_malloc0(sizeof(PlayerInfo));
	info->going=1;
	
	pos=TRUE;	

	if(strncasecmp(filename,"http://",7))
		if(!real_open(filename))
			return;

	pthread_create(&decode_thread,NULL,decode_loop,filename);
}

void stop(void)
{
	if(info)
	{
		if(info->going)
		{
			info->going=0;
			pthread_join(decode_thread,NULL);
			g_free(info);
			info=NULL;
		}
	}
}

void seek(int time)
{
	info->output_audio=FALSE;
	info->jump_to_time=time;
	while(info->jump_to_time!=-1) usleep(10000);
}

void do_pause(short p)
{
	ip.output->pause(p);
}

int get_time(void)
{
	if(!info)
		return -1;
	if(!info->going||info->eof)
		return -1;
	return ip.output->output_time();
}

InputPlugin ip=
{
	NULL,
	NULL,
	"MPEG Layer 1/2/3 Player",
	init,
	NULL,
	configure,
	is_our_file,
	NULL,
	play_file,
	stop,
	do_pause,
	seek,
	set_eq,
	get_time,
	NULL,NULL,
	NULL,NULL,NULL,NULL,NULL,
	get_song_info,
	NULL
};		

InputPlugin *get_iplugin_info(void)
{
	return &ip;
}
