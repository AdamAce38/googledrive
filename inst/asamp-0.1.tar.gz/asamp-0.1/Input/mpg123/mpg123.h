/*
 * mpg123 defines 
 * used source: musicout.h from mpegaudio package
 */

#include        <stdio.h>
#include        <string.h>
#include        <signal.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<sys/stat.h>
#include 	<unistd.h>

#include        <math.h>

#include <gtk/gtk.h>

#include "x11amp/plugin.h"
#include "dxhead.h"

#ifdef HPUX
#define random rand
#define srandom srand
#endif


#define SKIP_JUNK 1

#ifdef SUNOS
#define memmove(dst,src,size) bcopy(src,dst,size)
#endif

#ifdef REAL_IS_FLOAT
#  define real float
#elif defined(REAL_IS_LONG_DOUBLE)
#  define real long double
#else
#  define real double
#endif

#ifdef __GNUC__
#define INLINE inline
#else
#define INLINE
#endif




#define         MAX_NAME_SIZE           81
#define         SBLIMIT                 32
#define         SCALE_BLOCK             12
#define         SSLIMIT                 18

#define         MPG_MD_STEREO           0
#define         MPG_MD_JOINT_STEREO     1
#define         MPG_MD_DUAL_CHANNEL     2
#define         MPG_MD_MONO             3


/* Pre Shift fo 16 to 8 bit converter table */
#define AUSHIFT (3)


typedef struct
{
	gint	going,num_frames,eof,jump_to_time,eq_active;
	gdouble	tpf;
	gfloat	eq_mul[576];
	gboolean output_audio;
} PlayerInfo;

void set_eq(int on,float preamp,float *band);


extern PlayerInfo *info;
extern InputPlugin ip;

struct al_table 
{
  short bits;
  short d;
};

struct frame {
    struct al_table *alloc;
    int (*synth)(real *,int,unsigned char *,int *);
    int (*synth_mono)(real *,unsigned char *,int *);
    int stereo;
    int jsbound;
    int single;
    int II_sblimit;
    int down_sample_sblimit;
    int lsf;
    int mpeg25;
    int down_sample;
    int header_change;
    int lay;
    int (*do_layer)(struct frame *fr);
    int error_protection;
    int bitrate_index;
    int sampling_frequency;
    int padding;
    int extension;
    int mode;
    int mode_ext;
    int copyright;
    int original;
    int emphasis;
    int framesize; /* computed framesize */
};

struct parameter {
	int equalizer;
	int aggressive; /* renice to max. priority */
	int shuffle;	/* shuffle/random play */
	int remote;	/* remote operation */
	int outmode;	/* where to out the decoded sampels */
	int quiet;	/* shut up! */
	int usebuffer;	/* second level buffer size */
	int tryresync;  /* resync stream after error */
	int verbose;    /* verbose level */
	int force_mono;
	int force_stereo;
	int force_8bit;
	int force_rate;
	int down_sample;
	int checkrange;
	int doublespeed;
	int halfspeed;
	int force_reopen;
};



extern int halfspeed;
extern char *prgName, *prgVersion;

void configure(void);

typedef struct
{
	gint	resolution;
	gint	channels;
	gint	downsample;
	gint	downsample_custom;
	gint	http_buffer_size;
	gint 	http_prebuffer;
	gchar   *id3_format;
} MPG123Config;

extern MPG123Config mpg123_cfg;


/* ------ Declarations from "httpget.c" ------ */

extern int http_open (char *url);
int http_read(gpointer data,gint length);
void http_close(void);
gchar *http_get_title(gchar *url);



/* ------ Declarations from "common.c" ------ */
extern unsigned int   get1bit(void);
extern unsigned int   getbits(int);
extern unsigned int   getbits_fast(int);

extern int head_check(unsigned long);
extern void stream_close(void);

extern void set_pointer(long);

extern unsigned char *pcm_sample;
extern int pcm_point;
extern int audiobufsize;


struct gr_info_s {
      int scfsi;
      unsigned part2_3_length;
      unsigned big_values;
      unsigned scalefac_compress;
      unsigned block_type;
      unsigned mixed_block_flag;
      unsigned table_select[3];
      unsigned subblock_gain[3];
      unsigned maxband[3];
      unsigned maxbandl;
      unsigned maxb;
      unsigned region1start;
      unsigned region2start;
      unsigned preflag;
      unsigned scalefac_scale;
      unsigned count1table_select;
      real *full_gain[3];
      real *pow2gain;
};

struct III_sideinfo
{
  unsigned main_data_begin;
  unsigned private_bits;
  struct {
    struct gr_info_s gr[2];
  } ch[2];
};

extern void open_stream(char *,int fd);
extern void close_stream(void);
extern long tell_stream(void);
extern void read_frame_init (void);
extern int read_frame(struct frame *fr);
extern int back_frame(struct frame *fr,int num);
void stream_jump_to_frame(struct frame *fr,int frame);
void stream_jump_to_byte(struct frame *fr,int byte);
int stream_check_for_xing_header(struct frame *fr,XHEADDATA *xhead);
int calc_numframes(struct frame *fr);


extern int do_layer3(struct frame *fr);
extern int do_layer2(struct frame *fr);
extern int do_layer1(struct frame *fr);

#ifdef PENTIUM_OPT
extern int synth_1to1_pent (real *,int,unsigned char *);
#endif
extern int synth_1to1 (real *,int,unsigned char *,int *);
extern int synth_1to1_8bit (real *,int,unsigned char *,int *);
extern int synth_1to1_mono (real *,unsigned char *,int *);
extern int synth_1to1_mono2stereo (real *,unsigned char *,int *);
extern int synth_1to1_8bit_mono (real *,unsigned char *,int *);
extern int synth_1to1_8bit_mono2stereo (real *,unsigned char *,int *);

extern int synth_2to1 (real *,int,unsigned char *,int *);
extern int synth_2to1_8bit (real *,int,unsigned char *,int *);
extern int synth_2to1_mono (real *,unsigned char *,int *);
extern int synth_2to1_mono2stereo (real *,unsigned char *,int *);
extern int synth_2to1_8bit_mono (real *,unsigned char *,int *);
extern int synth_2to1_8bit_mono2stereo (real *,unsigned char *,int *);

extern int synth_4to1 (real *,int,unsigned char *,int *);
extern int synth_4to1_8bit (real *,int,unsigned char *,int *);
extern int synth_4to1_mono (real *,unsigned char *,int *);
extern int synth_4to1_mono2stereo (real *,unsigned char *,int *);
extern int synth_4to1_8bit_mono (real *,unsigned char *,int *);
extern int synth_4to1_8bit_mono2stereo (real *,unsigned char *,int *);

extern int synth_ntom (real *,int,unsigned char *,int *);
extern int synth_ntom_8bit (real *,int,unsigned char *,int *);
extern int synth_ntom_mono (real *,unsigned char *,int *);
extern int synth_ntom_mono2stereo (real *,unsigned char *,int *);
extern int synth_ntom_8bit_mono (real *,unsigned char *,int *);
extern int synth_ntom_8bit_mono2stereo (real *,unsigned char *,int *);

extern void rewindNbits(int bits);
extern int  hsstell(void);
extern void set_pointer(long);
extern void huffman_decoder(int ,int *);
extern void huffman_count1(int,int *);
extern int get_songlen(struct frame *fr,int no);

extern void init_layer3(int);
extern void init_layer2(void);
extern void make_decode_tables(long scale);
extern void make_conv16to8_table(void);
extern void dct64(real *,real *,real *);

extern void synth_ntom_set_step(long,long);

int decode_header(struct frame *fr,unsigned long newhead);
double compute_bpf(struct frame *fr);

extern unsigned char *conv16to8;
extern long freqs[9];
extern real muls[27][64];
extern real decwin[512+32];
extern real *pnts[5];





