#include <ctype.h>
#include <stdlib.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "config.h"

#ifdef HAVE_MMAP
#include <sys/mman.h>
#ifndef MAP_FAILED
#define MAP_FAILED ( (void *) -1 )
#endif
#endif

#include "mpg123.h"
#include "tables.h"

/* max = 1728 */
#define MAXFRAMESIZE 1792

int tabsel_123[2][3][16] = {
   { {0,32,64,96,128,160,192,224,256,288,320,352,384,416,448,},
     {0,32,48,56, 64, 80, 96,112,128,160,192,224,256,320,384,},
     {0,32,40,48, 56, 64, 80, 96,112,128,160,192,224,256,320,} },

   { {0,32,48,56,64,80,96,112,128,144,160,176,192,224,256,},
     {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,},
     {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,} }
};

long freqs[9] = { 44100, 48000, 32000, 22050, 24000, 16000 , 11025 , 12000 , 8000 };

#ifdef I386_ASSEM
int bitindex;
unsigned char *wordpointer;
#else
static int bitindex;
static unsigned char *wordpointer;
#endif

static int fsizeold=0,ssize;
static unsigned char bsspace[2][MAXFRAMESIZE+512]; /* MAXFRAMESIZE */
static unsigned char *bsbuf=bsspace[1],*bsbufold;
static int bsnum=0;

static unsigned long oldhead = 0;
static unsigned long firsthead=0;

struct ibuf {
	struct ibuf *next;
	struct ibuf *prev;
	unsigned char *buf;
	unsigned char *pnt;
	int len;
	/* skip,time stamp */
};

struct ibuf ibufs[2];
struct ibuf *cibuf;
int ibufnum=0;

unsigned char *pcm_sample;
int pcm_point = 0;

static int filept;
static int filept_opened;

static int get_fileinfo(char *buf);

static void get_II_stuff(struct frame *fr)
{
  static int translate[3][2][16] = 
   { { { 0,2,2,2,2,2,2,0,0,0,1,1,1,1,1,0 } ,
       { 0,2,2,0,0,0,1,1,1,1,1,1,1,1,1,0 } } ,
     { { 0,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0 } ,
       { 0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0 } } ,
     { { 0,3,3,3,3,3,3,0,0,0,1,1,1,1,1,0 } ,
       { 0,3,3,0,0,0,1,1,1,1,1,1,1,1,1,0 } } };

  int table,sblim;
  static struct al_table *tables[5] = 
       { alloc_0, alloc_1, alloc_2, alloc_3 , alloc_4 };
  static int sblims[5] = { 27 , 30 , 8, 12 , 30 };

  if(fr->lsf)
    table = 4;
  else
    table = translate[fr->sampling_frequency][2-fr->stereo][fr->bitrate_index];
  sblim = sblims[table];

  fr->alloc = tables[table];
  fr->II_sblimit = sblim;
}

static int fullread(int fd,unsigned char *buf,int count)
{
  int ret,cnt=0;

  while(cnt < count) {
    if(fd)
    	ret = read(fd,buf+cnt,count-cnt);
    else
	ret=http_read(buf+cnt,count-cnt);
    if(ret < 0)
      return ret;
    if(ret == 0)
      break;
    cnt += ret;
  } 

  return cnt;
}


#define HDRCMPMASK 0xfffffd00

#ifdef HAVE_MMAP

static unsigned char *mapbuf;
static unsigned char *mappnt;
static unsigned char *mapend;

static int stream_init(void) 
{
	long len;
	char buf[128];

	len = get_fileinfo(buf);
	if(len < 0)
		return -1;


        mappnt = mapbuf = 
		mmap(NULL, len, PROT_READ, MAP_SHARED , filept, 0);
	if(!mapbuf || mapbuf == MAP_FAILED)
		return -1;

	mapend = mapbuf + len;
	
	return 0;
}

static void stream_rewind(void)
{
	mappnt = mapbuf;
}

void stream_close(void)
{
      if(filept)
      {
        munmap(mapbuf,mapend-mapbuf);
	close(filept);
      }
      else
	      http_close();
	
}

static int stream_head_read(unsigned long *newhead) 
{
	unsigned long nh;

	if(filept)
	{
	
		if(mappnt + 4 > mapend)
			return FALSE;

		nh = (*mappnt++)  << 24;
		nh |= (*mappnt++) << 16;
		nh |= (*mappnt++) << 8;
		nh |= (*mappnt++) ;

		*newhead = nh;
		
	}
	else
	{
		  unsigned char hbuf[4];

  		  if(fullread(filept,hbuf,4) != 4)
 		    return FALSE;
  
		  *newhead = ((unsigned long) hbuf[0] << 24) |
		    ((unsigned long) hbuf[1] << 16) |
		    ((unsigned long) hbuf[2] << 8)  |
		    (unsigned long) hbuf[3];
	  }
          return TRUE;
 
}

static int stream_head_shift(unsigned long *head)
{
	
  if(filept)
  {
	  if(mappnt + 1 > mapend)
	    return FALSE;
	  *head <<= 8;
	  *head |= *mappnt++;
	  *head &= 0xffffffff;
  }
  else
  {
	  unsigned char hbuf;

	  if(fullread(filept,&hbuf,1) != 1)
	    return 0;
	  *head <<= 8;
	  *head |= hbuf;
	  *head &= 0xffffffff;
  }
  return TRUE;
}

static int stream_skip_bytes(int len)
{
  if(mappnt + len > mapend)
    return FALSE;
  mappnt += len;
  return TRUE;
}

static int stream_read_frame_body(unsigned char *buf,
				  int size)
{
	
 if(filept)
 {
	#if 1
	  if(mappnt + size > mapend)
	    return FALSE;
	#else
	  long l;
	  if(size > (mapend-mappnt)) {
	    l = mapend-mappnt;
	    memcpy(buf,mappnt,l);
	    memset(buf+l,0,size-l);
	  }
	  else
	#endif
	    memcpy(buf,mappnt,size);

	  mappnt += size;
  }
  else
  {
	    long l;

	  if( (l=fullread(filept,buf,size)) != size)
	  {
	    if(l <= 0)
	      return 0;
	    memset(buf+l,0,size-l);
	  }
  }

  return TRUE;
}

static int stream_back_bytes(int bytes)
{
    if( (mappnt - bytes) < mapbuf || (mappnt - bytes + 4) > mapend)
        return -1;
    mappnt -= bytes;
    return 0;
}

static long stream_tell(void)
{
  return mappnt - mapbuf;
}

void stream_jump_to_frame(struct frame *fr,int frame)
{
	if(mapbuf+frame*(fr->framesize+4)<mapend)
	{
		read_frame_init();
		stream_rewind();
		read_frame(fr);
		mappnt=mapbuf+frame*(fr->framesize+4);

		read_frame(fr);
	}
}

void stream_jump_to_byte(struct frame *fr,int byte)
{
	if(mapbuf+byte<mapend)
	{
		mappnt=mapbuf+byte;
		read_frame(fr);
	}
}

int stream_check_for_xing_header(struct frame *fr,XHEADDATA *xhead)
{
	unsigned char *head_data;
	int ret=0;
	stream_back_bytes(fr->framesize+4);

	if(mappnt+(fr->framesize+4)<mapend)
	{
		ret=GetXingHeader(xhead,mappnt);
		mappnt+=fr->framesize+4;
	}
	return ret;
}


#else

static void stream_init(void)
{
}



void stream_close(void)
{
/*    if (flags & READER_FD_OPENED)*/
      if(filept)
        close(filept);
      else
	      http_close();
}

/**************************************** 
 * HACK,HACK,HACK: step back <num> frames 
 * can only work if the 'stream' isn't a real stream but a file
 */
static int stream_back_bytes(int bytes)
{
  if(lseek(filept,-bytes,SEEK_CUR) < 0)
    return -1;
  return 0;
}

static int stream_head_read(unsigned long *newhead)
{
  unsigned char hbuf[4];

  if(fullread(filept,hbuf,4) != 4)
    return FALSE;
  
  *newhead = ((unsigned long) hbuf[0] << 24) |
    ((unsigned long) hbuf[1] << 16) |
    ((unsigned long) hbuf[2] << 8)  |
    (unsigned long) hbuf[3];
  
  return TRUE;
}

static int stream_head_shift(unsigned long *head)
{
  unsigned char hbuf;

  if(fullread(filept,&hbuf,1) != 1)
    return 0;
  *head <<= 8;
  *head |= hbuf;
  *head &= 0xffffffff;
  return 1;
}

static int stream_skip_bytes(int len)
{
  return lseek(filept,len,SEEK_CUR);
}

static int stream_read_frame_body(unsigned char *buf,
				  int size)
{
  long l;

  if( (l=fullread(filept,buf,size)) != size)
  {
    if(l <= 0)
      return 0;
    memset(buf+l,0,size-l);
  }

  return 1;
}

static long stream_tell(void)
{
  return lseek(filept,0,SEEK_CUR);
}

static void stream_rewind(void)
{
  lseek(filept,0,SEEK_SET);
}

/*
 * returns length of a file (if filept points to a file)
 * reads last to 128 bytes information into buffer
 */

void stream_jump_to_frame(struct frame *fr,int frame)
{
	read_frame_init();
	stream_rewind();
	read_frame(fr);
	lseek(filept,frame*(fr->framesize+4),SEEK_CUR);

	read_frame(fr);
}

void stream_jump_to_byte(struct frame *fr,int byte)
{
	lseek(filept,byte,SEEK_SET);
	read_frame(fr);
}

int stream_check_for_xing_header(struct frame *fr,XHEADDATA *xhead)
{
	unsigned char *head_data;
	int ret;
	lseek(filept,-(fr->framesize+4),SEEK_CUR);
	head_data=malloc(fr->framesize+4);
	read(filept,head_data,fr->framesize+4);
	ret=GetXingHeader(xhead,head_data);
	free(head_data);
	return ret;
}
	
#endif	

static int get_fileinfo(char *buf)
{
	int len;

	if(filept == -1) {
                return -1;
        }
        if((len=lseek(filept,0,SEEK_END)) < 0) {
                return -1;
        }
        if(lseek(filept,-128,SEEK_END) < 0)
                return -1;
        if(fullread(filept,(unsigned char *)buf,128) != 128) {
                return -1;
        }
        if(!strncmp(buf,"TAG",3)) {
                len -= 128;
        }
        if(lseek(filept,0,SEEK_SET) < 0)
                return -1;
        if(len <= 0)
                return -1;
	return len;
}

void read_frame_init (void)
{
    oldhead = 0;
    firsthead = 0;
}

int head_check(unsigned long head)
{
    if( (head & 0xffe00000) != 0xffe00000)
	return FALSE;
    if(!((head>>17)&3))
	return FALSE;
    if( ((head>>12)&0xf) == 0xf)
	return FALSE;
    if( ((head>>10)&0x3) == 0x3 )
	return FALSE;
    
    if( ((head>>19)&1)==1 && ((head>>17)&3)==3 && ((head>>19)&1)==1 )
	return FALSE;

    return TRUE;
}



/*****************************************************************
 * read next frame
 */
int read_frame(struct frame *fr)
{
  unsigned long newhead;
  static unsigned char ssave[34];

  fsizeold=fr->framesize;       /* for Layer3 */

  /*if (param.halfspeed) {
    static int halfphase = 0;
    if (halfphase--) {
      bitindex = 0;
      wordpointer = (unsigned char *) bsbuf;
      if (fr->lay == 3)
        memcpy (bsbuf, ssave, ssize);
      return 1;
    }
    else
      halfphase = param.halfspeed - 1;
  }*/

read_again:
  if(!stream_head_read(&newhead))
    return FALSE;

  if(1 || oldhead != newhead || !oldhead)
  {

init_resync:

    fr->header_change = 2;
    if(oldhead) {
      if((oldhead & 0xc00) == (newhead & 0xc00)) {
        if( (oldhead & 0xc0) == 0 && (newhead & 0xc0) == 0)
    	  fr->header_change = 1; 
        else if( (oldhead & 0xc0) > 0 && (newhead & 0xc0) > 0)
	  fr->header_change = 1;
      }
    }


#ifdef SKIP_JUNK
	if(!firsthead && !head_check(newhead) ) {
		int i;

/*		fprintf(stderr,"Junk at the beginning\n");*/

		/* I even saw RIFF headers at the beginning of MPEG streams ;( */
		if(newhead == ('R'<<24)+('I'<<16)+('F'<<8)+'F') {
			if(!stream_head_read(&newhead))
				return 0;
			while(newhead != ('d'<<24)+('a'<<16)+('t'<<8)+'a') {
				if(!stream_head_shift(&newhead))
					return 0;
			}
			if(!stream_head_read(&newhead))
				return 0;
/*			fprintf(stderr,"Skipped RIFF header!\n");*/
			goto read_again;
		}

#if 0
		/* search in 32 bit steps through the first 2K */
		for(i=0;i<512;i++) {
			if(!stream_head_read(&newhead))
				return 0;
			if(head_check(newhead))
				break;
		}
		if(i==512)
#endif
		{
			/* step in byte steps through next 64K */
			for(i=0;i<65536;i++) {
				if(!stream_head_shift(&newhead))
					return 0;
				if(head_check(newhead))
					break;
			}
			if(i == 65536) {
/*				fprintf(stderr,"Giving up searching valid MPEG header\n");*/
				return 0;
			}
		}
		/* 
		 * should we additionaly check, whether a new frame starts at
		 * the next expected position? (some kind of read ahead)
		 * We could implement this easily, at least for files.
		 */
	}
#endif

    if( (newhead & 0xffe00000) != 0xffe00000) {
      /*if (!param.quiet)
        fprintf(stderr,"Illegal Audio-MPEG-Header 0x%08lx at offset 0x%lx.\n",
              newhead,stream_tell(rd)-4);*/
    /* and those ugly ID3 tags */
      if((newhead & 0xffffff00) == ('T'<<24)+('A'<<16)+('G'<<8)) {
           stream_skip_bytes(124);
/*           fprintf(stderr,"Skipped ID3 Tag!\n");*/
           goto read_again;
      }
      if (/*param.tryresync*/ TRUE) {
        int try = 0;
            /* Read more bytes until we find something that looks
               reasonably like a valid header.  This is not a
               perfect strategy, but it should get us back on the
               track within a short time (and hopefully without
               too much distortion in the audio output).  */
        do {
          try++;
          if(!stream_head_shift(&newhead))
		return 0;
          if (!oldhead)
            goto init_resync;       /* "considered harmful", eh? */

        } while ((newhead & HDRCMPMASK) != (oldhead & HDRCMPMASK)
              && (newhead & HDRCMPMASK) != (firsthead & HDRCMPMASK));
       /* if (!param.quiet)
          fprintf (stderr, "Skipped %d bytes in input.\n", try);*/
      }
      else
        return (0);
    }
    if (!firsthead)
      firsthead = newhead;

    if(!decode_header(fr,newhead))
      return 0;

  }
  else
    fr->header_change = 0;

  /* flip/init buffer for Layer 3 */
  bsbufold = bsbuf;
  bsbuf = bsspace[bsnum]+512;
  bsnum = (bsnum + 1) & 1;

  /* read main data into memory */
  if(!stream_read_frame_body(bsbuf,fr->framesize))
    return 0;

  bitindex = 0;
  wordpointer = (unsigned char *) bsbuf;

/*  if (param.halfspeed && fr->lay == 3)
    memcpy (ssave, bsbuf, ssize);*/

  return 1;

}



/*
 * the code a header and write the information
 * into the frame structure
 */
int decode_header(struct frame *fr,unsigned long newhead)
{
    if( newhead & (1<<20) ) {
      fr->lsf = (newhead & (1<<19)) ? 0x0 : 0x1;
      fr->mpeg25 = 0;
    }
    else {
      fr->lsf = 1;
      fr->mpeg25 = 1;
    }
    
    if (/*!param.tryresync*/1 || !oldhead) {
          /* If "tryresync" is true, assume that certain
             parameters do not change within the stream! */
      fr->lay = 4-((newhead>>17)&3);
      if( ((newhead>>10)&0x3) == 0x3) {
/*        fprintf(stderr,"Stream error\n");*/
/*        exit(1);*/
      }
      if(fr->mpeg25) {
        fr->sampling_frequency = 6 + ((newhead>>10)&0x3);
      }
      else
        fr->sampling_frequency = ((newhead>>10)&0x3) + (fr->lsf*3);
      fr->error_protection = ((newhead>>16)&0x1)^0x1;
    }

    if(fr->mpeg25) /* allow Bitrate change for 2.5 ... */
      fr->bitrate_index = ((newhead>>12)&0xf);

    fr->bitrate_index = ((newhead>>12)&0xf);
    fr->padding   = ((newhead>>9)&0x1);
    fr->extension = ((newhead>>8)&0x1);
    fr->mode      = ((newhead>>6)&0x3);
    fr->mode_ext  = ((newhead>>4)&0x3);
    fr->copyright = ((newhead>>3)&0x1);
    fr->original  = ((newhead>>2)&0x1);
    fr->emphasis  = newhead & 0x3;

    fr->stereo    = (fr->mode == MPG_MD_MONO) ? 1 : 2;

    oldhead = newhead;

    if(!fr->bitrate_index)
    {
/*      fprintf(stderr,"Free format not supported.\n");*/
      return (0);
    }

    switch(fr->lay)
    {
      case 1:
	fr->do_layer = do_layer1;
	init_layer2(); /* inits also shared tables with layer1 */
        fr->jsbound = (fr->mode == MPG_MD_JOINT_STEREO) ? 
                         (fr->mode_ext<<2)+4 : 32;
        fr->framesize  = (long) tabsel_123[fr->lsf][0][fr->bitrate_index] * 12000;
        fr->framesize /= freqs[fr->sampling_frequency];
        fr->framesize  = ((fr->framesize+fr->padding)<<2)-4;
        break;
      case 2:
	fr->do_layer = do_layer2;
	init_layer2(); /* inits also shared tables with layer1 */
        get_II_stuff(fr);
        fr->jsbound = (fr->mode == MPG_MD_JOINT_STEREO) ?
                         (fr->mode_ext<<2)+4 : fr->II_sblimit;
        fr->framesize = (long) tabsel_123[fr->lsf][1][fr->bitrate_index] * 144000;
        fr->framesize /= freqs[fr->sampling_frequency];
        fr->framesize += fr->padding - 4;
        break;
      case 3:
        fr->do_layer = do_layer3;
        if(fr->lsf)
          ssize = (fr->stereo == 1) ? 9 : 17;
        else
          ssize = (fr->stereo == 1) ? 17 : 32;
        if(fr->error_protection)
          ssize += 2;
          fr->framesize  = (long) tabsel_123[fr->lsf][2][fr->bitrate_index] * 144000;
          fr->framesize /= freqs[fr->sampling_frequency]<<(fr->lsf);
          fr->framesize = fr->framesize + fr->padding - 4;
        break; 
      default:
/*        fprintf(stderr,"Sorry, unknown layer type.\n"); */
        return (0);
    }
    return 1;
}

void open_stream(char *bs_filenam,int fd)
{
    filept_opened = 1;
    if(!strncasecmp(bs_filenam,"http://",7))
    	filept=http_open(bs_filenam);
    else
    {
    	if((filept=open(bs_filenam, O_RDONLY)) != -1)
	    if(stream_init() == -1) info->eof=1;
    }
    if(filept==-1) info->eof=1;

}


#if !defined(I386_ASSEM) || defined(DEBUG_GETBITS)
#ifdef _gcc_
inline 
#endif
unsigned int getbits(int number_of_bits)
{
  unsigned long rval;

#ifdef DEBUG_GETBITS
fprintf(stderr,"g%d",number_of_bits);
#endif

  if(!number_of_bits)
    return 0;

#if 0
   check_buffer_range(number_of_bits+bitindex);
#endif

  {
    rval = wordpointer[0];
    rval <<= 8;
    rval |= wordpointer[1];
    rval <<= 8;
    rval |= wordpointer[2];
#if 0
    rval = ((unsigned int) wordpointer[0] << 16)+((unsigned int) wordpointer[1]<<8)+
                 (unsigned int) wordpointer[2];
#endif
    rval <<= bitindex;
    rval &= 0xffffff;

    bitindex += number_of_bits;

    rval >>= (24-number_of_bits);

    wordpointer += (bitindex>>3);
    bitindex &= 7;
  }

#ifdef DEBUG_GETBITS
fprintf(stderr,":%x ",rval);
#endif
  return rval;
}

#ifdef _gcc_
inline
#endif
unsigned int getbits_fast(int number_of_bits)
{
  unsigned long rval;

#ifdef DEBUG_GETBITS
fprintf(stderr,"g%d",number_of_bits);
#endif

#if 0
   check_buffer_range(number_of_bits+bitindex);
#endif

  {
    rval = wordpointer[0];
    rval <<= 8;	
    rval |= wordpointer[1];
    rval <<= bitindex;
    rval &= 0xffff;
#if 0
    rval = ((unsigned int) high << (8-bitindex) )+((unsigned int) (unsigned char) wordpointer[1]);
#endif
    bitindex += number_of_bits;

    rval >>= (16-number_of_bits);

    wordpointer += (bitindex>>3);
    bitindex &= 7;
  }


#ifdef DEBUG_GETBITS
fprintf(stderr,":%x ",rval);
#endif


  return rval;
}

#ifdef _gcc_
inline 
#endif
unsigned int get1bit(void)
{
  unsigned char rval;

#ifdef DEBUG_GETBITS
fprintf(stderr,"g%d",1);
#endif

#if 0
   check_buffer_range(1+bitindex);
#endif

  rval = *wordpointer << bitindex;

  bitindex++;
  wordpointer += (bitindex>>3);
  bitindex &= 7;

#ifdef DEBUG_GETBITS
fprintf(stderr,":%d ",rval>>7);
#endif

  return rval>>7;
}
#endif

void set_pointer(long backstep)
{
  wordpointer = bsbuf + ssize - backstep;
  if (backstep)
    memcpy(wordpointer,bsbufold+fsizeold-backstep,backstep);
  bitindex = 0; 
}

double compute_bpf(struct frame *fr)
{
	double bpf;

        switch(fr->lay) {
                case 1:
                        bpf = tabsel_123[fr->lsf][0][fr->bitrate_index];
                        bpf *= 12000.0 * 4.0;
                        bpf /= freqs[fr->sampling_frequency] <<(fr->lsf);
                        break;
                case 2:
                case 3:
                        bpf = tabsel_123[fr->lsf][fr->lay-1][fr->bitrate_index];                        bpf *= 144000;
                        bpf /= freqs[fr->sampling_frequency] << (fr->lsf);
                        break;
                default:
                        bpf = 1.0;
        }

	return bpf;
}

int calc_numframes(struct frame *fr)
{
	int pos,len;
	pos=stream_tell();
	len=lseek(filept,0,SEEK_END);
	lseek(filept,pos,SEEK_SET);
	return (int)((double)len/compute_bpf(fr));
}
