/*      MikMod sound library
   (c) 1998 Miodrag Vallat and others - see file AUTHORS for complete list

   This library is free software; you can redistribute it and/or modify
   it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*==============================================================================

  $Id: drv_nos.c,v 1.2 1999/02/09 00:19:58 x11amp Exp $

  Mikmod driver for no output

==============================================================================*/

/*

   Written by Jean-Paul Mikkers <mikmak@via.nl>

 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <mikmod_internals.h>

/* mapping parameters */
#define ZEROLEN 32768

static SBYTE *zerobuf = NULL;

static BOOL 
NS_IsThere (void)
{
  return 1;
}

static BOOL 
NS_Init (void)
{
  if (!(zerobuf = (SBYTE *) _mm_malloc (ZEROLEN)))
    return 1;
  return VC_Init ();
}

static void 
NS_Exit (void)
{
  VC_Exit ();
  if (zerobuf)
    {
      free (zerobuf);
      zerobuf = NULL;
    }
}

static BOOL 
NS_Reset (void)
{
  NS_Exit ();
  return NS_Init ();
}

static void 
NS_Update (void)
{
  if (zerobuf)
    VC_WriteBytes (zerobuf, ZEROLEN);
}

MDRIVER drv_nos =
{
  NULL,
  "No Sound",
  "Nosound Driver v3.0",
  255, 255,

  NS_IsThere,
  VC_SampleLoad,
  VC_SampleUnload,
  VC_SampleSpace,
  VC_SampleLength,
  NS_Init,
  NS_Exit,
  NS_Reset,
  VC_SetNumVoices,
  VC_PlayStart,
  VC_PlayStop,
  NS_Update,
  VC_VoiceSetVolume,
  VC_VoiceSetFrequency,
  VC_VoiceSetPanning,
  VC_VoicePlay,
  VC_VoiceStop,
  VC_VoiceStopped,
  VC_VoiceGetPosition,
  VC_VoiceRealVolume
};
