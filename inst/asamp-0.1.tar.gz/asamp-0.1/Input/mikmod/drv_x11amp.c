
/*      MikMod sound library
   (c) 1998 Miodrag Vallat and others - see file AUTHORS for complete list

   This library is free software; you can redistribute it and/or modify
   it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   Modified 2/1/99 for x11amp by J. Nick Koston (BlueDraco)
 */

/*==============================================================================

  $Id: drv_x11amp.c,v 1.6 1999/03/15 22:40:37 x11amp Exp $

  Output data to x11amp

==============================================================================*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <stdlib.h>

#include "mikmod-plugin.h"

#include <mikmod_internals.h>

static int buffer_size;

static SBYTE *audiobuffer = NULL;
short *effectbuffer = NULL;
extern MIKMODConfig mikmod_cfg;


static BOOL 
x11amp_IsThere (void)
{
  return 1;
}

static BOOL 
x11amp_Init (void)
{
  buffer_size=512;
  if(!mikmod_cfg.force8bit)
	  buffer_size*=2;
  if(!mikmod_cfg.force_mono)
	  buffer_size*=2;
  if (!(audiobuffer = (SBYTE *) _mm_malloc (buffer_size)))
    return 1;
  
  effectbuffer = malloc(buffer_size*2);
  return VC_Init ();
}

static void 
x11amp_Exit (void)
{
  VC_Exit ();
  if (audiobuffer)
    {
      free (audiobuffer);
      audiobuffer = NULL;
    }
  if (effectbuffer)
    {
      free (effectbuffer);
      effectbuffer = NULL;
    }
}

static void 
x11amp_Update (void)
{
  gint length;
  int fxlength;

  if (mikmod_ip.output->buffer_free ()>=buffer_size)
  {
      length=VC_WriteBytes ((SBYTE *) audiobuffer, buffer_size);
	  mikmod_ip.add_vis_pcm(mikmod_ip.output->written_time(),mikmod_cfg.force8bit?FMT_U8:FMT_S16_NE,mikmod_cfg.force_mono?1:2,length,audiobuffer);
      memcpy(effectbuffer,audiobuffer,length);
	  if (effects_enabled())
	  {
		fxlength=get_current_effect_plugin()->mod_samples(
			(short *)effectbuffer, length,
				mikmod_cfg.force8bit?8:16,
				mikmod_cfg.force_mono?1:2,
				md_mixfreq);
	   }
		mikmod_ip.output->write_audio (effectbuffer, length);
  }
  else
      usleep (10000);
}

static BOOL 
x11amp_Reset (void)
{
  VC_Exit ();
  return VC_Init ();
}

MDRIVER drv_x11amp =
{
  NULL,
  "x11amp",
  "x11amp output driver v1.0",
  0, 255,
  x11amp_IsThere,
  VC_SampleLoad,
  VC_SampleUnload,
  VC_SampleSpace,
  VC_SampleLength,
  x11amp_Init,
  x11amp_Exit,
  x11amp_Reset,
  VC_SetNumVoices,
  VC_PlayStart,
  VC_PlayStop,
  x11amp_Update,
  VC_VoiceSetVolume,
  VC_VoiceSetFrequency,
  VC_VoiceSetPanning,
  VC_VoicePlay,
  VC_VoiceStop,
  VC_VoiceStopped,
  VC_VoiceGetPosition,
  VC_VoiceRealVolume
};
