#include "cdaudio.h"

static GtkWidget *configure_win,*vbox,*notebook;
static GtkWidget *dev_vbox,*dev_frame,*dev_table,*dev_label,*dev_entry;
static GtkWidget *dev_dir_label,*dev_dir_entry;
static GtkWidget *bbox,*ok,*cancel;

static void configurewin_ok_cb(GtkWidget *w,gpointer data)
{
	ConfigFile *cfgfile;
	gchar *tmp,*filename;
	
	g_free(cdda_cfg.device);
	cdda_cfg.device=g_strdup(gtk_entry_get_text(GTK_ENTRY(dev_entry)));
	
	g_free(cdda_cfg.directory);
	tmp=gtk_entry_get_text(GTK_ENTRY(dev_dir_entry));
	
	if(tmp[strlen(tmp)-1]=='/')
		cdda_cfg.directory=g_strdup(tmp);
	else
		cdda_cfg.directory=g_strconcat(tmp,"/",NULL);
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	cfgfile=x11amp_cfg_open_file(filename);
	if(!cfgfile)
		cfgfile=x11amp_cfg_new();
	
	x11amp_cfg_write_string(cfgfile,"CDDA","device",cdda_cfg.device);
	x11amp_cfg_write_string(cfgfile,"CDDA","directory",cdda_cfg.directory);
	x11amp_cfg_write_file(cfgfile,filename);
	x11amp_cfg_free(cfgfile);
	
	g_free(filename);
	
	gtk_widget_destroy(configure_win);
}
	

void configure(void)
{
	if(!configure_win)
	{
		configure_win=gtk_window_new(GTK_WINDOW_DIALOG);
		gtk_signal_connect(GTK_OBJECT(configure_win),"destroy",GTK_SIGNAL_FUNC(gtk_widget_destroyed),&configure_win);
		gtk_window_set_title(GTK_WINDOW(configure_win),"CD Audio Player Configuration");
		gtk_window_set_policy(GTK_WINDOW(configure_win), FALSE,FALSE,FALSE);
		gtk_window_set_position(GTK_WINDOW(configure_win),GTK_WIN_POS_MOUSE);
		gtk_container_border_width(GTK_CONTAINER(configure_win),10);
		
		vbox=gtk_vbox_new(FALSE,10);
		gtk_container_add(GTK_CONTAINER(configure_win),vbox);
		
		notebook=gtk_notebook_new();
		gtk_box_pack_start(GTK_BOX(vbox),notebook,TRUE,TRUE,0);
		
		dev_vbox=gtk_vbox_new(FALSE,5);
		gtk_container_set_border_width(GTK_CONTAINER(dev_vbox),5);
		
		dev_frame=gtk_frame_new("Device:");
		gtk_box_pack_start(GTK_BOX(dev_vbox),dev_frame,FALSE,FALSE,0);
		
		dev_table=gtk_table_new(2,2,FALSE);
		gtk_container_set_border_width(GTK_CONTAINER(dev_table),5);
		gtk_container_add(GTK_CONTAINER(dev_frame),dev_table);
		gtk_table_set_row_spacings(GTK_TABLE(dev_table),5);
		gtk_table_set_col_spacings(GTK_TABLE(dev_table),5);
		
		dev_label=gtk_label_new("Device:");
		gtk_misc_set_alignment(GTK_MISC(dev_label),1.0,0.5);
		gtk_table_attach_defaults(GTK_TABLE(dev_table),dev_label,0,1,0,1);
		gtk_widget_show(dev_label);
		
		dev_entry=gtk_entry_new();
		gtk_entry_set_text(GTK_ENTRY(dev_entry),cdda_cfg.device);
		gtk_table_attach_defaults(GTK_TABLE(dev_table),dev_entry,1,2,0,1);
		gtk_widget_show(dev_entry);
		
		dev_dir_label=gtk_label_new("Directory:");
		gtk_misc_set_alignment(GTK_MISC(dev_dir_label),1.0,0.5);
		gtk_table_attach_defaults(GTK_TABLE(dev_table),dev_dir_label,0,1,1,2);
		gtk_widget_show(dev_dir_label);
		
		dev_dir_entry=gtk_entry_new();
		gtk_entry_set_text(GTK_ENTRY(dev_dir_entry),cdda_cfg.directory);
		gtk_table_attach_defaults(GTK_TABLE(dev_table),dev_dir_entry,1,2,1,2);
		gtk_widget_show(dev_dir_entry);
		
		gtk_widget_show(dev_table);
		gtk_widget_show(dev_frame);
		gtk_widget_show(dev_vbox);
		
		gtk_notebook_append_page(GTK_NOTEBOOK(notebook),dev_vbox,gtk_label_new("Device"));
		
		gtk_widget_show(notebook);
		
		bbox=gtk_hbutton_box_new();
		gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
		gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox),5);
		gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,0);

		ok=gtk_button_new_with_label("Ok");
        	gtk_signal_connect(GTK_OBJECT(ok),"clicked",GTK_SIGNAL_FUNC(configurewin_ok_cb),NULL);
		GTK_WIDGET_SET_FLAGS(ok,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),ok,TRUE,TRUE,0);
		gtk_widget_show(ok);
		gtk_widget_grab_default(ok);

		cancel=gtk_button_new_with_label("Cancel");
        	gtk_signal_connect_object(GTK_OBJECT(cancel),"clicked",GTK_SIGNAL_FUNC(gtk_widget_destroy),GTK_OBJECT(configure_win));
		GTK_WIDGET_SET_FLAGS(cancel,GTK_CAN_DEFAULT);
		gtk_box_pack_start(GTK_BOX(bbox),cancel,TRUE,TRUE,0);
		gtk_widget_show(cancel);

		gtk_widget_show(bbox);
		
		gtk_widget_show(vbox);
		gtk_widget_show(configure_win);
	}
}

		
		
		
