/*  x11amp - graphically mp3 player..
 *  Copyright (C) 1998-1999  Mikael Alm, Olle Hallnas, Thomas Nilsson and 4Front Technologies
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "cdaudio.h"

InputPlugin cdda_ip=
{
	NULL,
	NULL,
	"CD Audio Player 0.9",
	cdda_init,
	NULL,
	configure,
	is_our_file,
	scan_dir,
	play_file,
	stop,
	cdda_pause,
	seek,
	NULL,
	get_time,
	get_volume,
	set_volume,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	get_song_info,
	NULL
};

CDDAConfig cdda_cfg;

static gint cdda_fd=-1;
static gint track,ntrack,start_frame;
static gint length;
static gboolean is_paused;

InputPlugin *get_iplugin_info(void)
{
	return &cdda_ip;
}

static void cdda_init(void)
{
	ConfigFile *cfgfile;
	gchar *filename;
	
	filename=g_strconcat(g_get_home_dir(),"/.x11amp/config",NULL);
	
	cdda_cfg.device=NULL;
	cdda_cfg.directory=NULL;
	
	if(cfgfile=x11amp_cfg_open_file(filename))
	{
		x11amp_cfg_read_string(cfgfile,"CDDA","device",&cdda_cfg.device);
		x11amp_cfg_read_string(cfgfile,"CDDA","directory",&cdda_cfg.directory);
		x11amp_cfg_free(cfgfile);
	}
	g_free(filename);
	if(!cdda_cfg.device)
		cdda_cfg.device=g_strdup("/dev/cdrom");
	if(!cdda_cfg.directory)
		cdda_cfg.directory=g_strdup("/mnt/cdrom/");
}

static int is_our_file(char *filename) 
{
	gchar *ext;
	ext=strrchr(filename,'.');
	if(ext)
		if(!strcasecmp(ext,".cda"))
			return TRUE;
	return FALSE;
}


static gboolean is_mounted(gchar *device_name)
{
	FILE *mounts;
	struct mntent *mnt;
	char devname[256];
	struct stat st;

	if(lstat(device_name, &st) < 0)
		return -1;

	if(S_ISLNK(st.st_mode))
		readlink(device_name, devname, 256);
	else
		strncpy(devname, device_name, 256);

	if((mounts = setmntent(MOUNTED, "r")) == NULL)
		return TRUE;

	while((mnt = getmntent(mounts)) != NULL) 
	{
		if(strcmp(mnt->mnt_fsname, devname) == 0) 
		{
			endmntent(mounts);
			return TRUE;
		}
	}
	endmntent(mounts);
	
	return FALSE;
}

static GList *scan_dir(char *dir)
{
	GList *list=NULL;
	int fd,i;
	struct cdrom_tochdr tochdr;
	struct cdrom_tocentry tocentry;
	
	if(!strcmp(dir,cdda_cfg.directory))
	{
		if(is_mounted(cdda_cfg.device))
			return NULL;
		
		fd=open(cdda_cfg.device,O_RDONLY | O_NONBLOCK);
		if(fd != -1)
		{
			if(!ioctl(fd,CDROMREADTOCHDR,&tochdr))
			{
				for(i=tochdr.cdth_trk0;i<=tochdr.cdth_trk1;i++)
				{
					tocentry.cdte_track=i;
					tocentry.cdte_format=CDROM_MSF;
					if(!ioctl(fd, CDROMREADTOCENTRY, &tocentry))
					{
						if(tocentry.cdte_ctrl != CDROM_DATA_TRACK)
							list=g_list_append(list,g_strdup_printf("Track %02d.cda",i));
					}
				}
			}
			close(fd);
		}
	}
				
	return list;
}

static void play_file(char *filename)
{
	gchar *tmp;
	struct cdrom_ti cdti;
	struct cdrom_tocentry tocentry;
	struct cdrom_tochdr tochdr;
	
	if(is_mounted(cdda_cfg.device))
		return;
	
	tmp=strrchr(filename,'/');
	if(tmp)
		tmp++;
	else
		tmp=filename;
	
	if(!sscanf(tmp,"Track %d.cda",&track))
		return;
	
	cdda_fd=open(cdda_cfg.device,O_RDONLY | O_NONBLOCK);
	if(cdda_fd==-1)
		return ;
	
	ioctl(cdda_fd,CDROMREADTOCHDR,&tochdr);
	if(track<tochdr.cdth_trk0 || track>tochdr.cdth_trk1)
	{
		close(cdda_fd);
		cdda_fd=-1;
		return;
	}
	ntrack=(tochdr.cdth_trk1 == track) ? CDROM_LEADOUT : track+1;
	
	tocentry.cdte_track=ntrack;
	tocentry.cdte_format=CDROM_MSF;
	ioctl(cdda_fd,CDROMREADTOCENTRY,&tocentry);
	length=(tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second)*CD_FRAMES+tocentry.cdte_addr.msf.frame;
	
	tocentry.cdte_track=track;
	tocentry.cdte_format=CDROM_MSF;
	ioctl(cdda_fd,CDROMREADTOCENTRY,&tocentry);
	length-=(tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second)*CD_FRAMES+tocentry.cdte_addr.msf.frame;
	start_frame=(tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second)*CD_FRAMES+tocentry.cdte_addr.msf.frame;
	if(tocentry.cdte_ctrl == CDROM_DATA_TRACK)
	{
		close(cdda_fd);
		cdda_fd=-1;
		return;
	}

	
	tmp=g_strdup_printf("CD Audio Track %02u",track);
	cdda_ip.set_info(tmp,(length*1000)/75,44100*2*2*8,44100,2);
	
	cdti.cdti_trk1 = cdti.cdti_trk0 = track;
	cdti.cdti_ind1 = cdti.cdti_ind0 = 0;

	is_paused=FALSE;
	
	ioctl(cdda_fd,CDROMPLAYTRKIND,&cdti);
	
}

static void stop(void)
{
	ioctl(cdda_fd,CDROMSTOP,0);
	close(cdda_fd);
	cdda_fd=-1;
}

static void cdda_pause(short p)
{
	ioctl(cdda_fd,p ? CDROMPAUSE : CDROMRESUME);
	is_paused=(p?TRUE:FALSE);
}

static void seek(int time)
{
	struct cdrom_tocentry tocentry;
	struct cdrom_msf msf;

	tocentry.cdte_track=track;
	tocentry.cdte_format=CDROM_MSF;
	ioctl(cdda_fd, CDROMREADTOCENTRY, &tocentry);
	time+=tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second;
	msf.cdmsf_min0=time/60;
	msf.cdmsf_sec0=time%60;
	msf.cdmsf_frame0=74;
	tocentry.cdte_track=ntrack;
	ioctl(cdda_fd, CDROMREADTOCENTRY, &tocentry);
	msf.cdmsf_min1=tocentry.cdte_addr.msf.minute;
	msf.cdmsf_sec1=tocentry.cdte_addr.msf.second;
	msf.cdmsf_frame1=tocentry.cdte_addr.msf.frame;
	ioctl(cdda_fd, CDROMPLAYMSF, &msf);
	if(is_paused)
		ioctl(cdda_fd,CDROMPAUSE);
}

static int get_time(void)
{
	struct cdrom_subchnl subchnl;
	gint frame;
	
	if(cdda_fd == -1)
		return -1;
	
	subchnl.cdsc_format=CDROM_MSF;
	ioctl(cdda_fd,CDROMSUBCHNL,&subchnl);
	
	frame=(subchnl.cdsc_absaddr.msf.minute*60+subchnl.cdsc_absaddr.msf.second)*CD_FRAMES+subchnl.cdsc_absaddr.msf.frame;
	
	if(frame-start_frame>=length-20) /* 20 seems to work better */
	{
		stop();
		return -1;
	}
	
	return ((frame-start_frame)*1000)/75;
}
	
static void get_song_info(char *filename, char **title, int *len)
{
	gint t,nt,fd;
	gchar *tmp;
	struct cdrom_tocentry tocentry;
	struct cdrom_tochdr tochdr;
	
	*title=NULL;
	*len=-1;
	
	if(is_mounted(cdda_cfg.device))
		return;
	
	tmp=strrchr(filename,'/');
	if(tmp)
		tmp++;
	else
		tmp=filename;
	
	if(!sscanf(tmp,"Track %d.cda",&t))
		return;
	
	fd=open(cdda_cfg.device,O_RDONLY | O_NONBLOCK);
	if(fd==-1)
		return ;
	
	ioctl(fd,CDROMREADTOCHDR,&tochdr);
	if(t<tochdr.cdth_trk0 || t>tochdr.cdth_trk1)
	{
		close(fd);
		return;
	}
	nt=(tochdr.cdth_trk1 == t) ? CDROM_LEADOUT : t+1;
	
	tocentry.cdte_track=nt;
	tocentry.cdte_format=CDROM_MSF;
	ioctl(fd,CDROMREADTOCENTRY,&tocentry);

	*len=(tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second)*CD_FRAMES+tocentry.cdte_addr.msf.frame;
	
	tocentry.cdte_track=t;
	tocentry.cdte_format=CDROM_MSF;
	ioctl(fd,CDROMREADTOCENTRY,&tocentry);
	if(tocentry.cdte_ctrl == CDROM_DATA_TRACK)
	{
		*len=-1;
		close(fd);
		return;
	}

	(*len)-=(tocentry.cdte_addr.msf.minute*60+tocentry.cdte_addr.msf.second)*CD_FRAMES+tocentry.cdte_addr.msf.frame;
	
	*len=(*len*1000)/75;
	
	
	*title=g_strdup_printf("CD Audio Track %02u",t);
	close(fd);
	
}

static void get_volume(int *l,int *r)
{
	struct cdrom_volctrl vol;
	
	if(cdda_fd != -1)
	{
		ioctl(cdda_fd,CDROMVOLREAD,&vol);
		*l=(100*vol.channel0)/255;
		*r=(100*vol.channel1)/255;
	}
}

static void set_volume(int l,int r)
{
	struct cdrom_volctrl vol;
	
	if(cdda_fd != -1)
	{
		vol.channel0 = vol.channel2 = (l*255)/100;
		vol.channel1 = vol.channel3 = (r*255)/100;
		ioctl(cdda_fd,CDROMVOLCTRL,&vol);
	}
}
				
		
