/*
 * Time-stamp: <Monday, 03 May 1999, 23:00. Eric Raijmakers>
 *
 * Copyright (c) 1999 Eric Raijmakers <eric@win.tue.nl>
 * Copyright (c) 1999 Rafal Wierzbicki <rafal@mcss.mcmaster.ca>
 * Copyright (c) 1997 Guylhem Aznar <guylhem@oeil.qc.ca>
 * Copyright (c) 1994 Mike Finger <mfinger@mermaid.micro.umn.edu>
 *                    or <Mike_Finger@atk.com>
 * Copyright (c) 1994 Robert Nation
 * Copyright (c) 1994 Nobutaka Suzuki
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

//#define IN_MODULE

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/time.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Intrinsic.h>

#include "../../include/aftersteplib.h"
#include "../../include/afterstep.h"
#include "../../include/module.h"
#include "../../include/XImage_utils.h"
#include "List.h"

/* masks for AS pipe */
#define  mask_reg (M_ADD_WINDOW | M_CONFIGURE_WINDOW | M_DESTROY_WINDOW | M_ICONIFY | M_DEICONIFY | M_WINDOW_NAME | M_END_WINDOWLIST)

/*************************************************************************
  Subroutine Prototypes
**************************************************************************/
char *makename(char *string,long flags);
void DeadPipe(int nonsense);
void EndLessLoop(void);
void LinkAction(char *string);
void LoopOnEvents(void);
void MakeMeWindow(void);
void ParseBaseOptions (char *filename);
void ParseOptions(char *file);
void ReadASPipe(void);
void ShutMeDown(int exitstat);
void WaitForExpose(void);

int error_handler (Display *disp, XErrorEvent *event);
int list_add_window (unsigned long *body);
int list_configure (unsigned long *body);
int list_deiconify (unsigned long *body);
int list_destroy_window (unsigned long *body);
int list_end();
int list_icon_name (unsigned long *body);
int list_iconify (unsigned long *body);
int list_window_name  (unsigned long *body);
void process_message (unsigned long type, unsigned long *body);
void send_as_mesg (char *message,unsigned long window);
void set_as_mask (long unsigned mask);

/* app window */
Window window = None;

/* display, needed by AS libs */
Display *dpy;

/* for balloons */
int screen;

/* module name, needed by AS libs */
char *MyName = "Tasks";

/* list of same */
List windows;
