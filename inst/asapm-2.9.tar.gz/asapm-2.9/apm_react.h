#ifndef _apm_react_
#define _apm_react_

/*
 * asapm is the APM (Advanced Power Management) monitor utility for X Windows
 * Copyright (c) 1998  Albert Dorofeev <Albert@mail.dma.be>
 * For the updates see http://bewoner.dma.be/Albert/linux/
 * 
 * This software is distributed under GPL. For details see LICENSE file.
 */

void React();
void ClearReactions();
void AddReaction(int order, char * command);
void AddReactionOnPercent(int ifDownTo, int percent, char * command);

#endif

