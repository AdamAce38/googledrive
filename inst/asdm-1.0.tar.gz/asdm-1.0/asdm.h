XDMDIR = /usr/local/share/asdm
BINDIR = /usr/local/bin
MANDIR = /usr/local/man/man1
SHLIBDIR = /usr/local/lib


#define XPM
#define XPMLIBRARY -L/usr/X11R6/lib -lXpm
