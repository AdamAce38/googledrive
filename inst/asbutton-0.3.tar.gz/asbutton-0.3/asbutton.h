/***********************************************************************
 *   asbutton - AfterStep application launcher               
 *
 ***********************************************************************/

#define CONFIGFILEMAX 256
/* Default # of buttons -- 4 or 9 */
#define BUTTONS 4     

typedef struct _XpmIcon {
	Pixmap pixmap;
	Pixmap mask;
	XpmAttributes attributes;
} XpmIcon;

typedef struct _button_region {
	int x,y;
	int i,j;
} ButtonArea;


/***********************************************************************
 *	  Global variables
 ***********************************************************************/

Display   *display;
int        screen;
Window     rootwin, win, iconwin;
GC         gc;
int        depth;
Pixel      bg_pixel, fg_pixel;
Pixmap     pixmask;

char       configfile[CONFIGFILEMAX]; 
int        numb_of_apps = BUTTONS;
ButtonArea button_region[9];
XpmIcon    template, visible, buttons[9];

int        button = 0;		
int        verbose = 0;
char       geometry_str[64] = "64x64+0+0";
char       display_str[64] = "";
char      *app_name = "asbutton"; 


/***********************************************************************
 *   Function Prototypes
 ***********************************************************************/

void  ASButtonSetup(int argc, char **argv);
void  XSetup(void);
void  CreateWindow(Window *win, Window *rootwin, XSizeHints xsizehints);
void  Redraw(void);
int   WhichButton(int x, int y);
void  RunApp(int app);
char *Parse(int app);
void  GetPixmaps(void);
char *GetButtonFileName(int position);
void  FlushExpose(Window w);
void  ShowUsage(void);
char *ReadLine(FILE *fp);

