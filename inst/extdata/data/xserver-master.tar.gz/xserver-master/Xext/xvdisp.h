extern void XineramifyXv(void);
extern void XvResetProcVector(void);
