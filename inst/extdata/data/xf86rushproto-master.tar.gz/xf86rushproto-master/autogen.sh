#!/bin/sh

echo "This module has been deprecated. Use xorgproto instead:"
echo "git clone git://anongit.freedesktop.org/git/xorg/proto/xorgproto"

exit 1
