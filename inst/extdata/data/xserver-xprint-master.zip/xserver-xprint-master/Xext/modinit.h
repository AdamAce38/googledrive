/* Initialisation of Extension Modules is enabled via modinit.

  This was implemented in the Xorg xserver (xfree86 ddx), 
  see hw/xfree86/dixmods/extmod, but is not implemented for Xprt (xprint ddx)

  This header file, referenced in the Xext extension files, is therefore given
  as a dummy header file for xprint.
*/
