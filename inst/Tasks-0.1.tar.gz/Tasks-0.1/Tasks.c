/*
 * Copyright (c) 1999 Eric Raijmakers <eric@win.tue.nl>
 * Copyright (c) 1998 Rafal Wierzbicki <rafal@mcss.mcmaster.ca>
 * Copyright (c) 1998 Michal Vitecek <M.Vitecek@sh.cvut.cz>
 * Copyright (C) 1998 Sasha Vasko <sashav@sprintmail.com>
 * Copyright (c) 1998 Makoto Kato <m_kato@ga2.so-net.ne.jp>
 * Copyright (c) 1998 Rene Fichter <ceezaer@cyberspace.org>
 * Copyright (c) 1997 Guylhem Aznar <guylhem@oeil.qc.ca>
 * Copyright (c) 1994 Mike Finger <mfinger@mermaid.micro.umn.edu>
 *                    or <Mike_Finger@atk.com>
 * Copyright (c) 1994 Robert Nation
 * Copyright (c) 1994 Nobutaka Suzuki
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * $Id: WinList.c,v 1.31 1999/04/06 06:26:56 rafal Exp $
 */

#include "Tasks.h"
#include <regex.h>
#include "../../include/loadimg.h"
#include <X11/xpm.h> 


/* Window and look related variables */
static char *pixmap_path = NULL;
static char *icon_path = NULL;
static MyStyle *Style = NULL;

static Atom _AS_STYLE;
static Atom _XROOTPMAP_ID;

/* File type information */
static int fd_width;
static int fd[2];
static int x_fd;

static Atom wm_del_win;
//static Atom MwmAtom = None;

/* Module related information */
static int WindowIsUp = 0;

static char *ClickAction[3] = {"Iconify -1, Focus", "Iconify", "Lower"};
int UseSkipList = 0, UseIconNames = 1;

void version(void)
{
  printf("%s version %s\n", MyName, VERSION);
  exit(0);
}

void usage(void)
{
  printf("Usage:\n%s [--version] [--help] [--test] \n\n", MyName);
  printf("--version : display version information");
  printf("--help : display this message");
  printf("--test : test regular expressions in config file");
  printf("         \"(usually ~/GNUstep/Library/AfterStep/tasks\")");
  exit(0);
}

/* Function prototypes */
XImage *GetAssociatedIcon(char *name);
XImage *LoadPixmap(char *name, int w, int h);
int WindowNumber(int x, int y);
void CreateBalloon(int num);
void RedrawWindow ();
void UpdateImage();

/* The graphics context (for drawing images) */
GC gc;

/* NameInfo, exp : regular expression, xpmname : name of pixmap */
typedef struct _name_info {
  regex_t *regex;
  char *xpmname;
  struct _name_info *next;
} NameInfo;

/* Name of background image (memory freed after loading) */
char* background_image_name = NULL;

/* Mapping of regular expressions to pixmap names */
NameInfo *nameInfo;

/* Text balloon (showing icon name) */
Balloon *balloon = NULL;

/* Number in the List associated with the balloon */
int balloon_num = -1;

/* Page currently being viewed (each page contains 9 icons) */
int page = 0;

/* Default icon */
#include "noicon.xpm"
XImage *default_icon = NULL;

/* Backgroudn image */
XImage *background_image = NULL;

/* Image used for drawing to screen */
XImage *tasks_image = NULL;

//#define DEBUG

/************************************************************************
 * Main - Setup the XConnection,request the window list and loop forever
 * Based on main() from Ident:
 * Copyright 1994, Robert Nation and Nobutaka Suzuki.
 ************************************************************************/

int
main (int argc, char **argv)
{
  char configfile[255];
  char *realconfigfile;
  char *buf;
  char *temp;
  int test = 0;
  int i;
  char *global_config_file = NULL;

#ifdef DEBUG
  fprintf(stderr,"main");
#endif

  /* Save program name */
  temp = strrchr (argv[0], '/');
  MyName = temp ? temp + 1 : argv[0];

  for (i = 1 ; i < argc && *argv[i] == '-' ; i++)
    {
      if      (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))   	usage ();
      else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version"))	version ();
      else if (!strcmp(argv[i], "-f") && i + 1 < argc)          	global_config_file = argv[++i];
      else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--test"))    test = 1;
    }


  // TODO : CMDline optie voor het testen van de config file!
  
  /* Dead pipe == dead AfterStep */
  signal (SIGPIPE, DeadPipe);
  signal (SIGQUIT, DeadPipe);
  signal (SIGSEGV, DeadPipe);
  signal (SIGTERM, DeadPipe);

  if ((dpy = XOpenDisplay ("")) == NULL)
    {
      fprintf (stderr, "%s: couldn't open display %s\n",
	       MyName, XDisplayName (""));
      exit (1);
    }
  screen = DefaultScreen (dpy);

  /* connect to AfterStep */
  temp = module_get_socket_property(RootWindow(dpy, screen));
  fd[0] = fd[1] = module_connect (temp);
  XFree (temp);
  if (fd[0] < 0)
    {
      fprintf (stderr, "%s: unable to establish connection to AfterStep\n", MyName);
      exit (1);
    }
  temp = (char*)safemalloc (9 + strlen(MyName) + 1);
  sprintf (temp, "SET_NAME %s", MyName);
  SendInfo (fd, temp, None);
  free (temp);

  x_fd = XConnectionNumber (dpy);
  screen = DefaultScreen (dpy);
  Root = RootWindow (dpy, screen);
  d_depth = DefaultDepth (dpy, screen);

  XSetErrorHandler (error_handler);
  _AS_STYLE = XInternAtom (dpy, "_AS_STYLE", False);
  _XROOTPMAP_ID = XInternAtom (dpy, "_XROOTPMAP_ID", False);

  buf = (char*)safemalloc (1 + strlen (MyName) + 10);
  sprintf (buf, "*%s", MyName);

  /* get MyStyles */
  mystyle_get_property (dpy, Root, _AS_STYLE, XA_INTEGER);

  /* check if *Tasks is in mystyles */
  if ((Style = mystyle_find (buf)) == NULL)
    /* if not create our own */
    {
      Style = mystyle_new_with_name (buf);
    }
  free (buf);

  
  if (global_config_file != NULL)
    {
      // Parse alternative config file
      ParseBaseOptions (global_config_file);
      ParseOptions (global_config_file);
    }
  else
    {
      // Parse base config file
      sprintf (configfile, "%s/base.%dbpp", AFTER_DIR, DefaultDepth (dpy, screen));
      realconfigfile = (char *) PutHome (configfile);
      if (CheckFile (realconfigfile) == -1)
        {
          free (realconfigfile);
          sprintf (configfile, "%s/base.%dbpp", AFTER_SHAREDIR, DefaultDepth (dpy, screen));
          realconfigfile = PutHome (configfile);
        }
      ParseBaseOptions (realconfigfile);
      free (realconfigfile);

      // Parse the config file
      sprintf (configfile, "%s/tasks", AFTER_DIR);
      realconfigfile = PutHome (configfile);
      if ((CheckFile (realconfigfile)) == -1)
	{
	  free (realconfigfile);
	  sprintf (configfile, "%s/tasks", AFTER_SHAREDIR);
	  realconfigfile = PutHome (configfile);
	}
      ParseOptions (realconfigfile);
      free (realconfigfile);
    }

  // Exit if only testing
  if (test == 1) exit(0);

  // Setup balloons
  balloon_setup (dpy);

  mystyle_fix_styles ();

  InitList(&windows);

  fd_width = GetFdWidth ();
  set_as_mask ((long unsigned) mask_reg);

  SendInfo (fd, "Send_WindowList\n", 0);

  EndLessLoop ();
  return 0;
}

/***********************************************************
 * error_handler:
 * catch X errors, display the message and continue running
 ***********************************************************/

int
error_handler (Display *disp, XErrorEvent *event)
{
  fprintf (stderr, "%s: internal error, error code %d, request code %d, minor code %d.\n",
	   MyName, event->error_code, event->request_code, event->minor_code);
  fprintf (stderr, "Please email eric@win.tue.nl with the above information\n");
  return 0;
}

/********************************************
 * EndlessLoop:
 * wait for input on either x_fd  or AS pipe
 ********************************************/

void
EndLessLoop ()
{
  fd_set readset;
  struct timeval tv;
  int retval=0;

#ifdef DEBUG
  fprintf(stderr,"EndLessLoop");
#endif

  while (1)
    {
      FD_ZERO (&readset);
      FD_SET (fd[1], &readset);
      FD_SET (x_fd, &readset);
      tv.tv_sec = 0;
      tv.tv_usec = 0;

#ifdef __hpux
      if (!select (fd_width, (int *) &readset, NULL, NULL, &tv))
	{
	  XPending (dpy);
	  FD_ZERO (&readset);
	  FD_SET (fd[1], &readset);
	  FD_SET (x_fd, &readset);
          if (hidden)
	    {
	      tv.tv_sec = 1;
	      retval = select (fd_width, (int *) &readset, NULL, NULL, &tv);
	    }
	  else
	    retval = select (fd_width, (int *) &readset, NULL, NULL, NULL);
	}
#else
      if (!select (fd_width, &readset, NULL, NULL, &tv))
	{
	  XPending (dpy);
	  FD_ZERO (&readset);
	  FD_SET (fd[1], &readset);
	  FD_SET (x_fd, &readset);
	  retval = select (fd_width, &readset, NULL, NULL, NULL);
	}
#endif

      if (FD_ISSET (x_fd, &readset))
	{
	  LoopOnEvents ();
	}

      if (!FD_ISSET (fd[1], &readset))
	continue;
      if (FD_ISSET(fd[1], &readset))
	ReadASPipe ();
    }
}


/******************************************************************
 * ReadASPipe - Read a single message from the pipe from AfterStep
 * Originally Loop() from Ident:
 * Copyright 1994, Robert Nation and Nobutaka Suzuki
 ******************************************************************/

void
ReadASPipe ()
{
  unsigned long header[3], *body;

#ifdef DEBUG
  fprintf(stderr,"ReadASPipe");
#endif

  if (ReadASPacket (fd[1], header, &body) > 0)
    {
      process_message (header[1], body);
      free (body);
    }
}

/****************************************************
 * Detected a broken pipe - time to exit 
 * Based on DeadPipe() from Ident:
 * Copyright 1994, Robert Nation and Nobutaka Suzuki
 ****************************************************/

void
DeadPipe (int sig)
{
#ifdef DEBUG
  fprintf(stderr,"DeadPipe");
#endif

  switch (sig)
    {
    case SIGSEGV:
      fprintf (stderr, "Segmentation fault in %s, please send a bug report\n",MyName);
      exit (-1);
      break;
    case SIGQUIT:
      fprintf (stderr, "SIGQUITting\n");
      break;
    case SIGTERM:
      break;
    default:
      break;
    }
  ShutMeDown (1);
}

/***************************************************************************
 * WaitForExpose - Used to wait for expose event so we don't draw too early
 ***************************************************************************/

void
WaitForExpose (void)
{
  XEvent Event;

#ifdef DEBUG
  fprintf(stderr,"WaitForExpose");
#endif

  while (1)
    {
      XNextEvent (dpy, &Event);
      if ((Event.type == Expose) && (Event.xexpose.count == 0))
	break;
    }
}

/***************************************************
 * Calculate which window number (in the List) is
 * associated with the position (x,y) in the window
 ***************************************************/

int WindowNumber( int x, int y ) {
  int col, row;
  
#ifdef DEBUG
  fprintf(stderr,"WindowNumber");
#endif

  col = x / 20;
  row = y / 20;
  if (((x%20) < 4) || ((y%20) < 4)) return -1;
  return ((row * 3) + col + (page * 9));
}

/*********************************************
 * CreateBalloon
 * Create the balloon showing the icon's name
 *********************************************/

void CreateBalloon(int num) {
  char *name = ItemName(&windows,num);
  long id = ItemID(&windows,num);
  long flags = ItemFlags(&windows,id);
  char* ptr = (char*)safemalloc (strlen (name) + 3);

#ifdef DEBUG
  fprintf(stderr,"CreateBalloon");
#endif

  if (flags & ICONIFIED) strcpy (ptr, "("); else strcpy (ptr, "");
  strcat (ptr, name);
  if (flags & ICONIFIED) strcat (ptr, ")");
    
  if (balloon) balloon_delete (balloon);

  balloon = balloon_new_with_text (dpy, window, ptr);
  balloon_set_active_rectangle(balloon,
			       4 + (((num % 9) % 3) * 20),
			       4 + (((num % 9) / 3) * 20),
			       15,
			       15);
  balloon_num = num;
  free(ptr);
}

/******************************************************
 * LoadPixmap
 * Load a pixmap from the path (pixmap_path) and scale
 ******************************************************/

XImage* LoadPixmap(char *name, int w, int h) {
  Pixmap image = None;
  XImage *src, *target;
  int dummys;
  unsigned int dummy, rgb_width, rgb_height;
  Window dummywin;
  char* tmp_path = findIconFile(name,pixmap_path,R_OK);

#ifdef DEBUG
  fprintf(stderr,"LoadPixmap");
#endif

  if ((!tmp_path) && (!CheckFile (name))) {
    tmp_path = PutHome (name);
    if (!CheckFile(tmp_path)) { free (tmp_path); return NULL; }
  }
  image = LoadImage (dpy, window, -1, tmp_path);
  if (image == None) return NULL;
  XGetGeometry (dpy, image, &dummywin, &dummys, &dummys,
		&rgb_width, &rgb_height, &dummy, &dummy);
  src = XGetImage (dpy, image, 0, 0, rgb_width, rgb_height, AllPlanes, ZPixmap);
  target = ScaleXImageToSize (src, w, h);
  
  XFreePixmap(dpy,image);
  XDestroyImage(src);
  return target;
}

/***************************************************************
 * GetAssociatedIcon
 * Given a window title bar text, return the corresponding icon
 ***************************************************************/

XImage *GetAssociatedIcon(char *name) {
  NameInfo *ni;
  XImage *icon = NULL;
  
#ifdef DEBUG
  fprintf(stderr,"GetAssociatedIcon");
#endif

  ni = nameInfo;
  while (ni != NULL) {
    if (regexec(ni->regex,name,0,NULL,0) == 0) {
      icon = LoadPixmap(ni->xpmname,15,15);
      if (icon != NULL)
	return icon;
      else
	return default_icon;
    }
    ni = ni->next;
  }
  return default_icon;
}

/***************************************************
 * UpdateImage
 * Update the image that is displayed in the window
 ***************************************************/

void UpdateImage ()
{
  int row,col,x,y;
  XImage* icon;
  unsigned long pixel;
  int i = 0;

#ifdef DEBUG
  fprintf(stderr,"UpdateImage");
#endif

  while ((page * 9) > (ItemCount(&windows)-1)) page--;
  
  // Copy background pixmap
  for (x = 0; x < 64; x++)
    for (y = 0; y < 64; y++)
      XPutPixel(tasks_image,x,y,XGetPixel(background_image,x,y));

  // Copy all icons
  for (i = page * 9; (i < windows.count) && (i < (page * 9 + 9)); i++)
    {
      row = ((i%9)>5) ? 2 : (((i%9)>2) ? 1 : 0);
      col = ((i%9)%3==0) ? 0 : (((i%9)%3==1) ? 1 : 2);
      icon = GetAssociatedIcon(ItemName(&windows,i));
      //icon = default_icon;
      for (x = 0; x < 15; x++)
	for (y = 0; y < 15; y++) {
	  pixel = XGetPixel(icon,x,y);
	  if (pixel != 42091) 
	    XPutPixel(tasks_image,4 + col * 20 + x, 4 + row * 20 + y,pixel);
	  //		    XGetPixel(icon,x,y));
	}      
      if (icon != default_icon) XDestroyImage(icon);
    }

  if (balloon_num != -1) CreateBalloon(balloon_num);
  RedrawWindow();
}

/*****************
 * RedrawWindow
 * Show the image
 *****************/

void RedrawWindow () {
#ifdef DEBUG
  fprintf(stderr,"RedrawWindow");
#endif
  XPutImage(dpy,window,gc,tasks_image,0,0,0,0,64,64);
}

/****************************************************
 * ParseOptions - Parse the configuration file
 * Based on part of main() from Ident:
 * Copyright 1994, Robert Nation and Nobutaka Suzuki
 * Changed by Michal Vitecek, 1998
 * Additions by Rafal Wierzbicki, 1998
 * Changed by Eric Raijmakers, 1999
 ****************************************************/

void
ParseOptions (char *file)
{
  FILE *ptr;
  NameInfo *newNameInfo = NULL, *oldNameInfo = NULL;
  char *line, *tline, *exp = NULL, *xpmname = NULL;
  int len, nNameInfo = 0;

#ifdef DEBUG
  fprintf(stderr,"ParseOptions");
#endif

  if ((ptr = fopen (file, "r")) == NULL)
    {
      fprintf (stderr, "%s: can\'t open config file %s", MyName, file);
      exit (1);
    }

  line = (char *) safemalloc (MAXLINELENGTH);
  len = strlen (MyName);

  exp = (char*)safemalloc(100);
  xpmname = (char*)safemalloc(100);
  nameInfo = NULL;

  while ((tline = fgets (line, MAXLINELENGTH, ptr)) != NULL)
    {
      while (isspace (*tline)) tline++;      
      if ((*tline == '*') && (!mystrncasecmp (tline + 1, MyName, len)))
	{
	  tline += len + 1;
	  balloon_parse(tline,ptr);

	  if (!mystrncasecmp (tline, "Action", 6))             LinkAction (tline + 6);
	  else if (!mystrncasecmp (tline, "UseSkipList", 11))  UseSkipList = 1;
	  else if (!mystrncasecmp (tline, "UseIconNames", 12)) UseIconNames = 1;
	  else if (!mystrncasecmp (tline, "BackgroundImage", 15)) {
	    char *end;
	    tline += 16;
	    while (isspace(*tline)) tline++;
	    end = strchr(tline, '\n');
	    background_image_name = (char*)safemalloc(end-tline+1);
	    strncpy(background_image_name,tline,end-tline+1);
	    background_image_name[end-tline] = '\0';
	  }
	  else if (!mystrncasecmp (tline, "Icon", 4)) {
	    int result = 0;
	    regex_t* regex = (regex_t*)safemalloc(sizeof(regex_t));
	    sscanf(tline, "Icon %s %s", exp, xpmname);

	    result = regcomp(regex,exp,REG_NOSUB | REG_EXTENDED);

	    if (result != 0) {
	      char* errbuf = (char*)safemalloc(100);
	      regerror(result, regex, errbuf, 100);
	      fprintf(stderr,"Tasks: Error in regular expression \"%s\" - %s\n",exp,errbuf);
	      free(errbuf);
	      regfree(regex);
	    } else {
	      newNameInfo = (NameInfo*)safemalloc(sizeof(NameInfo));
	      newNameInfo->regex = regex;
		
	      while (isspace(*xpmname)) xpmname++;
	      newNameInfo->xpmname = (char*)safemalloc(strlen(xpmname)+1);
	      sprintf(newNameInfo->xpmname,"%s",xpmname);

	      newNameInfo->next = NULL;
		
	      nNameInfo++;
		
	      if (nNameInfo == 1)
		nameInfo = newNameInfo;
	      else
		oldNameInfo->next = newNameInfo;
		
	      oldNameInfo = newNameInfo;
	    }
	  }
	}
    }
  free(exp);
  free(xpmname);
  free (line);
  fclose (ptr);
}

/***************************************************
 * ParseBaseOptions
 * parse the appropriate base.xxbpp file
 * sets pixmap and icon paths to appropriate values
 * based on ParseOptions, Rafal Wierzbicki 1998.
 ***************************************************/

void
ParseBaseOptions (char *file)
{
  char line[MAXLINELENGTH];
  char *tline;
  FILE *ptr;

#ifdef DEBUG
  fprintf(stderr,"ParseBaseOptions");
#endif

  if ((ptr = fopen (file, "r")) == NULL)
    {
      fprintf (stderr, "%s: can\'t open config file %s", MyName, file);
      exit (1);
    }

  tline = fgets (line, sizeof (line), ptr);
  while (tline != NULL)
    {
      while (isspace (*tline))
	tline++;
      if (strlen (tline) > 1)
	{
	  if (!mystrncasecmp (tline, "IconPath", 8)) {
	    CopyString (&icon_path, tline + 8);
	  }
	  else if (!mystrncasecmp (tline, "PixmapPath", 10)) {
	    CopyString (&pixmap_path, tline + 10);
	  }
	}
      tline = fgets (line, sizeof (line), ptr);
    }
  fclose (ptr);
}

/**********************************
 * LoopOnEvents
 * Process all the X events we get
 **********************************/

void
LoopOnEvents ()
{
  int num = 0;
  XEvent Event;
  Bool balloon_event = False;

#ifdef DEBUG
  fprintf(stderr,"LoopOnEvents");
#endif

  while (XPending (dpy))
    {
      XNextEvent (dpy, &Event);
      balloon_event = balloon_handle_event (&Event);

      switch (Event.type)
	{
	case ButtonRelease:
	  num = WindowNumber(Event.xbutton.x,Event.xbutton.y);
	  switch (Event.xbutton.button) {
	  case 1:
	    if (num != -1) send_as_mesg (ClickAction[0], ItemID (&windows, num));
	    break;
	  case 2:
	    if (num != -1) send_as_mesg (ClickAction[1], ItemID (&windows, num));
	    break;
	  case 3: // Show next page of icons
	    if (((++page) * 9) > (ItemCount(&windows)-1)) page = 0;
	    balloon_num = -1;
	    UpdateImage();
	    break;
	  }
	  break;

	case Expose: // Redraw
	  RedrawWindow();
	  break;
	  
	case ClientMessage:
	  if ((Event.xclient.format == 32) &&
	      (Event.xclient.data.l[0] == wm_del_win))
	    ShutMeDown (0);
	  
	case MotionNotify: // Show balloon
  	  num = WindowNumber(Event.xbutton.x,Event.xbutton.y);
  	  if ((num != -1) && (num != balloon_num) && (num < ItemCount(&windows)))
	    CreateBalloon(num);
	  break;

	case ButtonPress:  break;
	case KeyPress:  break;
	case EnterNotify:  break;
	case LeaveNotify:  break;
	case PropertyNotify: break;
	}
    }
}

/***********************************
 * LinkAction
 * Link a response to a user action
 ***********************************/

void
LinkAction (char *string)
{
  char *temp = string;
  
#ifdef DEBUG
  fprintf(stderr,"LinkAction");
#endif

  while (isspace (*temp))
    temp++;
  if (mystrncasecmp (temp, "Click1", 6) == 0)
    CopyString (&ClickAction[0], &temp[6]);
  else if (mystrncasecmp (temp, "Click2", 6) == 0)
    CopyString (&ClickAction[1], &temp[6]);
  //else if (mystrncasecmp (temp, "Click3", 6) == 0)
  //CopyString (&ClickAction[2], &temp[6]);
}

/*******************************************
 * MakeMeWindow
 * Create and setup the window we will need
 *******************************************/

void
MakeMeWindow (void)
{
  XGCValues xgcValues;	
  GC fore_gc, back_gc, shadow_gc, relief_gc;
  int dummy = 0;
  XTextProperty name;
  Pixel fore, back;
  XSizeHints size_hints;

#ifdef DEBUG
  fprintf(stderr,"MakeMeWindow");
#endif

  back = Style->colors.back;  
  fore = Style->colors.fore;

  size_hints.width = 64;
  size_hints.height = 64;
  size_hints.flags  = USSize | USPosition;
 
  XWMGeometry(dpy,
	      screen,
	      "64x64",
	      NULL,
	      0,
	      &size_hints,
	      &size_hints.x,
	      &size_hints.y,
	      &size_hints.width,
	      &size_hints.height,
	      &dummy);
  if ( (window =
	XCreateSimpleWindow(dpy,
			    Root,
			    size_hints.x,
			    size_hints.y,
			    size_hints.width,
			    size_hints.height,
			    0,
			    fore,
			    back) ) == 0 ) {
    fprintf(stderr,"Fail:XCreateSimpleWindow\n");    exit(-1);
  }

  // Set Window name
  if (XStringListToTextProperty (&MyName, 1, &name) == 0)
    {
      fprintf (stderr, "%s: cannot allocate window name.\n", MyName);
      exit(-1);
    }

  XSetWMName (dpy, window, &name);
  XSetWMIconName (dpy, window, &name);
  XFree (name.value);

  /*    SetMwmHints (MWM_DECOR_ALL | MWM_DECOR_RESIZEH | MWM_DECOR_MAXIMIZE | */
  /*  	       MWM_DECOR_MINIMIZE, MWM_FUNC_ALL | MWM_FUNC_RESIZE | */
  /*  	       MWM_FUNC_MAXIMIZE | !MWM_FUNC_MINIMIZE, MWM_INPUT_MODELESS); */

  XSetWMNormalHints (dpy, window, &size_hints);

  mystyle_get_global_gcs (Style, &fore_gc, &back_gc, &relief_gc, &shadow_gc);
    
  wm_del_win = XInternAtom (dpy, "WM_DELETE_WINDOW", False);
  XSetWMProtocols (dpy, window, &wm_del_win, 1);

  XGrabButton (dpy, 1, AnyModifier, window, True, GRAB_EVENTS,
	       GrabModeAsync, GrabModeAsync, None, None);
  XGrabButton (dpy, 2, AnyModifier, window, True, GRAB_EVENTS,
	       GrabModeAsync, GrabModeAsync, None, None);
  XGrabButton (dpy, 3, AnyModifier, window, True, GRAB_EVENTS,
	       GrabModeAsync, GrabModeAsync, None, None);

  XSelectInput (dpy, window, (ExposureMask | KeyPressMask |
			      EnterWindowMask | LeaveWindowMask |
			      PointerMotionMask | StructureNotifyMask));  
  XSelectInput (dpy, Root, PropertyChangeMask);

  /* Create Graphic Context */	
  if (( gc = XCreateGC(dpy,window,(GCForeground | GCBackground), &xgcValues)) == NULL ) {
    fprintf(stderr,"Fail: XCreateGC\n");
    exit(-1);
  }

  // Background image:
  if (background_image_name == NULL) background_image_name = "default.xpm";
  background_image = LoadPixmap(background_image_name,64,64);
  if (background_image == NULL) {
    fprintf(stderr,"Could not find %s in pixmap path.\n",background_image_name);
    exit(-1);
  }
  // "Allocate space for new image"
  tasks_image = LoadPixmap(background_image_name,64,64);
  if (tasks_image == NULL) {
    fprintf(stderr,"Could not find %s in pixmap path.\n",background_image_name);
    exit(-1);
  }
  free(background_image_name);

  XpmCreateImageFromData(dpy,noicon_xpm,&default_icon,NULL,NULL);

  XMapRaised (dpy, window);
  WaitForExpose ();
  WindowIsUp = 1;
}

/**********************
 * ShutMeDown
 * Do X client cleanup
 **********************/

void
ShutMeDown (int exitstat)
{
  GC gc1, gc2, gc3, gc4;

#ifdef DEBUG
  fprintf(stderr,"ShutMeDown");
#endif

  FreeList(&windows);
  balloon_init (1);
  if (WindowIsUp) XDestroyWindow (dpy, window);
  XCloseDisplay (dpy);
  /* kill the styles */

  while (mystyle_first != NULL)
    mystyle_delete(mystyle_first);
  mystyle_get_global_gcs (Style, &gc1, &gc2, &gc3, &gc4);
  XFreeGC (dpy, gc1);
  XFreeGC (dpy, gc2);
  XFreeGC (dpy, gc3);
  XFreeGC (dpy, gc4);
  free (pixmap_path);
  free (icon_path);
  if (gc != None) XFreeGC (dpy, gc);

  exit (exitstat);
}

/*****************************************************************
 * Set mwm hints 
 * Now, if we (hopefully) have a MWM compatible window manager ,
 * say, mwm, ncdwm, or else, we will set useful decoration style.
 * Never check for MWM_RUNNING property.May be considered bad.
 *****************************************************************/

/*  void */
/*  SetMwmHints (unsigned int value, unsigned int funcs, unsigned int input) */
/*  { */
/*    PropMwmHints prop; */

/*    if (MwmAtom == None) */
/*      { */
/*        MwmAtom = XInternAtom (dpy, "_MOTIF_WM_HINTS", False); */
/*      } */
/*    if (MwmAtom != None) */
/*      { */
/*        prop.decorations = value; */
/*        prop.functions = funcs; */
/*        prop.inputMode = input; */
/*        prop.flags = MWM_HINTS_DECORATIONS | MWM_HINTS_FUNCTIONS | */
/*  	MWM_HINTS_INPUT_MODE; */

/*        XChangeProperty (dpy, window, */
/*  		       MwmAtom, MwmAtom, */
/*  		       32, PropModeReplace, */
/*  		       (unsigned char *) &prop, */
/*  		       PROP_MWM_HINTS_ELEMENTS); */
/*      } */
/*  } */

/* send_as_mesg:
 * send multiple  message to the pipe, have to be seperated by a ','
 */
 
void send_as_mesg (char *message, unsigned long id)
{
  char *delim;
  char tmp[255];
  char token[50];

#ifdef DEBUG
  fprintf(stderr,"send_as_mesg");
#endif

  sprintf (tmp, message);

  while  ((delim = strchr (tmp, ',')) != NULL )
    {
      strncpy(token, tmp, strlen(tmp) - strlen(delim));
      token[tmp - delim] = '\0';
      memcpy(tmp, delim + 1, strlen(delim + 1) + 1);
      SendInfo (fd, token, id);
    }
  SendInfo (fd, tmp, id);
}

/* set_as_mask:
 * set the mask on the pipe
 */

void set_as_mask (long unsigned mask)
{
  char set_mask_mesg[50];

#ifdef DEBUG
  fprintf(stderr,"set_as_mask");
#endif

  sprintf (set_mask_mesg, "SET_MASK %lu\n", mask);
  SendInfo (fd, set_mask_mesg, 0);
}

/* process_message:
 * process messages from the pipe.
 */

#define NOUPDATE 0
#define UPDATE 1

void
process_message (unsigned long type, unsigned long *body)
{
  int status = 0;

#ifdef DEBUG
  fprintf(stderr,"process_message");
#endif

  switch (type)
    {
    case M_CONFIGURE_WINDOW:
      status = list_configure (body);
      break;
    case M_ADD_WINDOW:
      status = list_add_window (body);
      break;
    case M_DESTROY_WINDOW:
      status = list_destroy_window (body);
      break;
    case M_ICONIFY:
      status = list_iconify (body);
      break;
    case M_DEICONIFY:
      status = list_deiconify (body);
      break;
    case M_WINDOW_NAME:
      status = list_window_name (body);
      break;
    case M_ICON_NAME:
      status = list_icon_name (body);
      break;
    case M_END_WINDOWLIST:
      status = list_end ();
      break;
    default:
      break;
    }

  if ((window == (Window) body[1] || window == (Window) body[0]) && 
      type != M_CONFIGURE_WINDOW ) status = 0 ;
  
  if ((status == UPDATE) && WindowIsUp)
    {
      UpdateImage();
    }
}

/* list_configure:
 * pipe configure events
 */
    
int
list_configure (unsigned long *body)
{
#ifdef DEBUG
  fprintf(stderr,"list_configure");
#endif

  if ((window == (Window) body[1]) || (window == (Window) body[0])
      || ((body[19] != 0) && (window == (Window) body[19]))
      || ((body[19] != 0) && (window == (Window) body[20])))
    return 0;
  else
    return (list_add_window (body));
}

/* list_add_window:
 * pipe add window events
 */

int
list_add_window (unsigned long *body)
{
#ifdef DEBUG
  fprintf(stderr,"list_add_window");
#endif

  if (FindItem (&windows, body[0]) != -1)
    {
      if (UseSkipList && (body[8] & WINDOWLISTSKIP))
	return (list_destroy_window (body));
    }
  else if (!(body[8] & WINDOWLISTSKIP) || !UseSkipList)
    {
      AddItem(&windows, body[0], body[8]);
    }
  return NOUPDATE;
}

/* list_window_name:
 * pipe change of window name events
 */

int
list_window_name (unsigned long *body)
{
#ifdef DEBUG
  fprintf(stderr,"list_window_name");
#endif

  if (UseIconNames) return NOUPDATE;
  if ((UpdateItemName (&windows, body[0], (char*) &body[3])) == -1) return NOUPDATE;
  return UPDATE;
}

/* list_icon_name:
 * pipe change of icon name events
 */

int
list_icon_name (unsigned long *body)
{
#ifdef DEBUG
  fprintf(stderr,"list_icon_name");
#endif

  if (!UseIconNames) return NOUPDATE;
  if ((UpdateItemName (&windows, body[0], (char *) &body[3])) == -1) return NOUPDATE;
  return UPDATE;
}

/* list_destroy_window:
 * pipe destroyed windows event
 */

int
list_destroy_window (unsigned long *body)
{
#ifdef DEBUG
  fprintf(stderr,"list_destroy_window");
#endif

  if ((DeleteItem (&windows, body[0])) == -1) return NOUPDATE;
  return UPDATE;
}

/* list_end
 * end of window list from pipe
 */
 
int
list_end (void)
{
#ifdef DEBUG
  fprintf(stderr,"list_end");
#endif

  MakeMeWindow ();
  set_as_mask ((long unsigned) mask_reg);
  return UPDATE;
}

/* list_deiconify:
 * window deiconified from the pipe
 */

int
list_deiconify (unsigned long *body)
{
  long unsigned flags;

#ifdef DEBUG
  fprintf(stderr,"list_deiconify");
#endif

  if ((FindItem (&windows, body[0])) == -1) return NOUPDATE;
  flags = ItemFlags (&windows, body[0]);
  if (!(flags & ICONIFIED)) return NOUPDATE;
  flags ^= ICONIFIED;
  UpdateItemFlags (&windows, body[0], flags);
  return UPDATE;
}

/* list_iconify:
 * window iconified from the pipe
 */

int
list_iconify (unsigned long *body)
{
  long unsigned flags;

#ifdef DEBUG
  fprintf(stderr,"list_iconify");
#endif

  if ((FindItem (&windows, body[0])) == -1) return NOUPDATE;
  flags = ItemFlags (&windows, body[0]);
  if (flags & ICONIFIED) return NOUPDATE;
  flags ^= ICONIFIED;
  UpdateItemFlags (&windows, body[0], flags);
  return UPDATE;
}
