/* auto-generated config.h for AScd. */
/* do not edit. Run ./configure!       */

/* internal defines, do not change! */
#define PACKAGE "ascd"
#define VERSION 		"0.12.2"

/* user choices */
#define DEFAULT_COLOR "#2FAFAF"
#define DEFAULT_BGCOLOR "#000000"
#define DEFAULTDEVICE "/dev/cdrom"
#define THDIR "/usr/local/share/AScd"
