#define FUSION_XPM

/* The CD player default device:
 * -----------------------------
 * You may change the default device for the CDROM driver. This
 * can also be changed with the '-d' commandline option.
 * 
 * Uncomment "#define NO_D_DEVICE" line if you don't want to use a
 * default CD device. Should be useful with Solaris Volume
 * Manager
 */

#define DEFAULTDEVICE 		"/dev/cdrom"

/*#define NO_D_DEVICE*/

/* The CD player LEDs:
 * -------------------
 * You can change the default colors used in the LEDS by
 * changing those 2 values. They also can be changed at
 * runtime with '-f' and '-b' CL options.
 */

#define DEFAULT_COLOR		"#1FAF9F"
#define DEFAULT_BGCOLOR 	"#000000"

/* The WINGs window:
 * -----------------
 * If you have WindowMaker installed, you should uncomment
 * the following line. AScd will then include a configuration
 * window based on the WINGs toolkit (open this window by
 * clicking on the display)
 */

/*#define WMK*/

#define PACKAGE "ascd"
#define VERSION 		"0.11.2"
