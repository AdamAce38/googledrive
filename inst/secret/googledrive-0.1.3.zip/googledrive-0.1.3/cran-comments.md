## Test environments
* local macOS install, R 3.5.2
* ubuntu 14.04 trusty (on travis-ci), R 3.2 - devel
* Windows Server 2012 R2 (on appveyor), R 3.5.2 Patched (2019-01-14 r76006)

## R CMD check results

0 errors | 0 warnings | 0 notes

This is a minor patch release for compatibility with the imminent submission/release of purrr 0.3.0. Change affects a single line of code.
