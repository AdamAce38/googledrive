#' @param verbose Logical, indicating whether to print informative messages
#'   (default `TRUE`).
