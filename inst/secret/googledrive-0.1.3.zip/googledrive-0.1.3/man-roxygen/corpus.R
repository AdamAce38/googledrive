#' @param corpus Character, specifying the search collection. Only relevant in
#'   the Team Drives context. If specified, must be one of `"user"`, `"all"`, or
#'   `"domain"`. Read more about [Team Drives][team_drives].

