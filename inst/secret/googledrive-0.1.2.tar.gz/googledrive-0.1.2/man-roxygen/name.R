#' @param name Character, new <%= name %> name if not specified as part of
#'   `path`. This will force `path` to be treated as a folder, even if it is
#'   character and lacks a trailing slash. <%= default %>
