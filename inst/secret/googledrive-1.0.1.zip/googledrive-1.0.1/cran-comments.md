## Test environments
* local macOS system
* ubuntu 16.04 (travis-ci), R devel, release, oldrel, 3.4, 3.3, 3.2
* windows server 2008 R2 (r-hub) R devel
* windows server 2012 R2 (appveyor) R release
* win-builder R devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 3 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
