This release is prompted by a request from Kurt Hornik and I am under a deadline of 2023-03-22. That request related to making the signature of a method match the generic.

## revdepcheck results

We checked 16 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages

