# drive_auth_configure works

    Code
      drive_auth_configure(client = gargle::gargle_client(), path = "PATH")
    Condition
      Error in `drive_auth_configure()`:
      ! Must supply exactly one of `client` or `path`, not both

