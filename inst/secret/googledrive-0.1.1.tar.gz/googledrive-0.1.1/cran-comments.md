## Test environments
* local OS X installs, R 3.3.2, 3.4.1
* ubuntu 14.04 trusty (on travis-ci), R 3.2.5, 3.3.3, 3.4.1, devel
* Windows Server 2012 R2 (on appveyor), R 3.4.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.

## Reverse dependencies

This is a new release, so there are no reverse dependencies.
