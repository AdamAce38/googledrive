#' @param corpus Character, specifying the search collection. Only relevant in
#'   the Team Drives context. If specified, must be one of \code{"user"},
#'   \code{"all"}, or \code{"domain"}. Read more about
#'   \link[=team_drives]{Team Drives}.

