#' @param file Something that identifies the file(s) of interest on your Google
#'   Drive. Can be a character vector of names/paths, a character vector of file
#'   ids or URLs marked with \code{\link{as_id}()}, or a \code{\link{dribble}}.
