#' @param media Character, path to the local file to upload.
