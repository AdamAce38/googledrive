#' @param team_drive Anything that identifies one specific Team Drive: its name,
#'   its id or URL marked with [as_id()], or a [`dribble`]. Is pre-processed
#'   with [as_team_drive()].  Read more about [Team Drives][team_drives].
