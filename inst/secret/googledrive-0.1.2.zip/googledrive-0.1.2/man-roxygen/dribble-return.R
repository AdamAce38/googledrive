#' @return An object of class [`dribble`], a tibble with one row per item.
