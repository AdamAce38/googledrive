#' @param file Something that identifies the file of interest on your Google
#'   Drive. Can be a name or path, a file id or URL marked with [as_id()], or a
#'   [`dribble`].
