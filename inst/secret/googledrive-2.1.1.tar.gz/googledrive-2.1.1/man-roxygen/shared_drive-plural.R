#' @param drive Anything that identifies the shared drive(s) of interest. Can
#'   be a character vector of names, a character vector of file ids or URLs
#'   marked with [as_id()], or a [`dribble`] consisting only of shared drives.
