#' @param pattern Character. If provided, only the items whose names match this
#'   regular expression are returned. This is implemented locally on the results
#'   returned by the API.
