#' @param team_drive `r lifecycle::badge("deprecated")` Google Drive and the
#'   Drive API have replaced Team Drives with shared drives.
