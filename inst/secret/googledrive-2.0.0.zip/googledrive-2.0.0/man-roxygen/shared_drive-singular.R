#' @param shared_drive Anything that identifies one specific shared drive: its
#'   name, its id or URL marked with [as_id()], or a [`dribble`]. The value
#'   provided to `shared_drive` is pre-processed with [as_shared_drive()]. Read
#'   more about [shared drives][shared_drives].
