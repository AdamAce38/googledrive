# drive_upload() detects non-existent file

    Code
      drive_upload("no-such-file", "File does not exist")
    Error <rlang_error>
      No file exists at the local `media` path:
      x 'no-such-file'

