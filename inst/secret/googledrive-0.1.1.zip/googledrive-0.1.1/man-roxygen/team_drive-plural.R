#' @param team_drive Anything that identifies the Team Drive(s) of interest. Can
#'   be a character vector of names, a character vector of file ids or URLs
#'   marked with \code{\link{as_id}()}, or a \code{\link{dribble}} consisting
#'   only of Team Drives.
