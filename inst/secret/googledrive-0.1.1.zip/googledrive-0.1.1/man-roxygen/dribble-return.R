#' @return An object of class \code{\link{dribble}}, a tibble with one row per
#'   item.
