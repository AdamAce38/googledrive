#' @param name Character, new <%= name %> name if not specified as part of
#'   \code{path}. This will force \code{path} to be treated as a folder, even if
#'   it is character and lacks a trailing slash. <%= default %>
