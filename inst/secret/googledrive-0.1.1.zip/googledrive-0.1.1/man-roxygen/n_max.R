#' @param n_max Integer. An upper bound on the number of items to return. This
#'   applies to the results requested from the API, which may be further
#'   filtered locally, via the \code{pattern} argument.
