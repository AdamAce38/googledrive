#' @description Note: [Team
#'   Drives](https://gsuite.google.com/learning-center/products/drive/get-started-team-drive/)
#'    are only available to users of certain enhanced Google services, such as G
#'   Suite Enterprise, G Suite Business, or G Suite for Education.
