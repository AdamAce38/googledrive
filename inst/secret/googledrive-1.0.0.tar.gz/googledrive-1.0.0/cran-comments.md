## Test environments

* local OS X install, R 3.6
* Windows 10 Enterprise (local VM), R 3.6
* ubuntu 14.04 trusty (on travis-ci), R 3.2 - devel
* Windows Server 2012 R2 (on appveyor), R 3.6.1
* win-builder (devel and release)
* Windows Server 2008 R2 SP1 (on R-hub), R-devel
* Ubuntu Linux 16.04 LTS + GCD (on R-hub), R-release
* Fedora Linux + clang + gfortran (on R-hub), R-devel

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 3 reverse dependencies, comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
