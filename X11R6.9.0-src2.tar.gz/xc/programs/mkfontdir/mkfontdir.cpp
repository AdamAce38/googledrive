XCOMM!/bin/sh
XCOMM $XFree86: xc/programs/mkfontdir/mkfontdir,v 1.2 2003/07/18 14:51:43 tsi Exp $

exec BINDIR/mkfontscale -b -s -l "$@"
