#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>

extern char *ProgName;

static char *InDir(path,name)
char *path;
char *name;
{
	char *s;

	if ((s = strchr(path,':')) != (char *)0) 
		*s == '\0';	
	if (*path == '\0')
		return (char *)0;
	if ((s = malloc(2 + strlen(path) + strlen(name))) == (char *)0) {
		(void) fprintf(stderr,
			"%s: cannot malloc for %s/%s\n",
			ProgName,path,name
		);
		return (char *)0;
	} 
	(void) sprintf(s,"%s/%s",path,name);
	if (access(s,F_OK) == 0)
		return s;
	(void) free(s);
	return (char *)0;
}

char *scanpath(path,name)
char *path;
char *name;
{
	char *s;

	if (path == (char *)0)
		return (char *)0;

	for (;;) {
		char *where;		

		if (where = InDir(path,name))
			return where;
		if ((s = strchr(path,':')) == (char *)0)
			return (char *)0;
		path = s+1;
	}	
} 
