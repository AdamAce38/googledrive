/* Module Name:	GloDef.H
 *
 * Description:
 *	Definitions for GloTeX data structures
 *
 * Author:	R L Aurbach	CR&DS MIS Group    17-Aug-1986
 *
 * Modification History:
 *
 * Version     Initials	   Date		Description
 * ------------------------------------------------------------------------
 * 1-001	RLA	17-Aug-1986	Original Code
 * 2-001	F.H.	17-May-1991	converted to portable C
 * 2-002        S.I.    30-Mar-1992     added /glossaryname for intern. support
 *
 */      

/* Definitions							*/

#define		TRUE	    1
#define		FALSE	    0
#define		STRDYN	    { 0, DSC$K_DTYPE_T, DSC$K_CLASS_D, 0 }
#define		NONE	    0
#define		ARTICLE	    1
#define		REPORT	    2
#define		linesz	    133	    /* Max size of a line	*/

/* Declarations							*/

typedef struct string
{
  struct string	    *next;
  char *desc;
} STRING, *STRING_PTR;

typedef struct node
{
  struct node		    *next;
  char *spell;
  char *item;
  struct string	    *hdr;
} NODE, *NODE_PTR;
