#define VERSION  "version " PACKAGE_VERSION
#define BUG_ADDRESS  "issue@texjp.org, tex-k@tug.org"
