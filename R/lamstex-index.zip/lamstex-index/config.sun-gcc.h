#define int short
#undef ANSI /* To use old-style K&R functions */
#undef MICROSOFTC
#undef LITTLENDIAN

#ifdef ANSI
/* Other things in ANSI C are good, but this is a crock */
#define READ_BINARY "rb"
#define WRITE_BINARY "wb"
#else
/* The good old simple and logical K&R I/O */
#define READ_BINARY "r"
#define WRITE_BINARY "w"
#endif
