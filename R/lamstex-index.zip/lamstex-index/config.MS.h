/* default environment */
#define MICROSOFTC
#define LITTLENDIAN
#define ANSI
#define READ_BINARY "rb"
#define WRITE_BINARY "wb"
