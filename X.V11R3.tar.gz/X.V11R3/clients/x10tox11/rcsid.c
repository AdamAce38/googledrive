char rcsid[] = "$XConsortium: rcsid.c,v 6.0 88/10/11 18:10:43 jim Exp $";
