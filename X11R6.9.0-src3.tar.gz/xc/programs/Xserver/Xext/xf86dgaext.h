/* $XFree86$ */

#ifdef HAVE_DIX_CONFIG_H
#include <dix-config.h>
#endif

#ifndef _XF86DGAEXT_H_
#define _XF86DGAEXT_H_

extern DISPATCH_PROC(ProcXF86DGADispatch);

#endif /* _XF86DGAEXT_H_ */
