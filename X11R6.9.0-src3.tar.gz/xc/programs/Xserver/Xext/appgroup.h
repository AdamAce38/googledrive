/* $XFree86$ */

void XagClientStateChange(
    CallbackListPtr* pcbl,
    pointer nulldata,
    pointer calldata);
int ProcXagCreate (
    register ClientPtr client);
int ProcXagDestroy(
    register ClientPtr client);
