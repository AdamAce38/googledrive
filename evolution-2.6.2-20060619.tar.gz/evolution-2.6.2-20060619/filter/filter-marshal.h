
#ifndef __filter_marshal_MARSHAL_H__
#define __filter_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* NONE:NONE (filter-marshal.list:1) */
#define filter_marshal_VOID__VOID	g_cclosure_marshal_VOID__VOID
#define filter_marshal_NONE__NONE	filter_marshal_VOID__VOID

/* NONE:POINTER (filter-marshal.list:2) */
#define filter_marshal_VOID__POINTER	g_cclosure_marshal_VOID__POINTER
#define filter_marshal_NONE__POINTER	filter_marshal_VOID__POINTER

G_END_DECLS

#endif /* __filter_marshal_MARSHAL_H__ */

