#include "objcube.h"
#include "objico.h"
#include "objtetra.h"
